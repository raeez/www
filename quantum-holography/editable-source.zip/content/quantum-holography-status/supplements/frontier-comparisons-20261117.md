# Four comparisons of boundary operations

In the current–ghost vacuum complex through order \(\hbar^2\), insert the Cartan ghost \(h_0\) and take the root current \(E_1\) as the second state. At separation \(u\), the homotopy reversing the field order has a term \(\hbar u^{-1}E_1\) on this pair. Now discard states of positive ghost degree. The first input becomes zero, while the displayed output survives in degree zero. A bilinear homotopy on the two quotient inputs would have to vanish on this pair. The fields and their exchange descend to the quotient. Keeping the full inserted input still allows projection in the rooted input and the output. The four comparisons below ask which operations survive a change of domain.

## Bulk fields with current corrections

To see where the surviving term comes from, keep both inputs of the field. Nonnegative ghost modes act on the inserted state and current modes act on the rooted state. Exchanging these two states changes the order of the mode operators. [Ordered fields on algebraic states](#ch17-native-r3-fields).

Let \(R_3=\mathbb C[\hbar]/(\hbar^3)\) and let \(M_3=V^{KB}(\mathfrak{gl}_2)\otimes_{R_3}F_0\) be the complex of current and ghost vacuum states, where \(F_0\) is the polarized ghost state module, the current factor is extended to \(R_3\), and the trace current and trace ghosts are retained. Its current inputs are finite linear combinations of ordered Poincaré–Birkhoff–Witt monomials. Its ghost inputs are finite exterior combinations. The ghost polarization is a left-module quotient. The two fields \(\mathbb Y_\pm\) take values in the pointwise complex
\[
\operatorname{Hom}_{R_3}(M_3\otimes M_3,M_3((u))).
\]
Their construction corrects the tensor product of the reversed current field and the ghost field by
\[
\mathbb Y_-=(\mu_-\otimes Y_{\rm gh})\circ
 e^{-\hbar s^{\ell J}(u+\hbar)},
\qquad \mathbb Y_+=\mathbb Y_-^{\rm op}.
\]
The kernel \(s^{\ell J}\) pairs the nonnegative coadjoint ghost modes on the inserted state with the nonnegative current modes on the rooted state. The shift by \(\hbar\) records their opposite multiplication order; the opposite field includes the sign \((-1)^{|X||Y|}\). Every coefficient is finite; on homogeneous inputs the order-\(\hbar^j\) Laurent floor is \(-\mathrm{wt}(X)-\mathrm{wt}(Y)-j\). Both vacuum laws and both translation laws hold at every numerical level \(K\).

The exchange of the two inputs is denoted by \(S_M\). With the vacuum, translation \(T\) and state differential \(d_M\), the tuple
\[
(M_3,d_M,\mathbb Y_-,T,\mathbf1,S_M)
\]
is a differential graded quantum vertex superalgebra with rational exchange at every numerical \(K\), including \(0\) and \(-2\). The two twist hexagons H1 and H2 reduce at second order, with their prescribed operator orders and shifted arguments, to the positive-jet classical Yang–Baxter equation. A common localized germ proves weak associativity on all algebraic triples; a separate locality argument gives one exponent \(N(X,Y)\) for every final state \(Z\). Pure-pair identities and filtered propagation of the order-\(\hbar^2\) differential defect prove the chain identity on all algebraic pairs. The proof retains the actual \(D_2+E_2\), corrected currents and full classical trace tensor factor with its Koszul sign. The direct all-mode current-column argument proves that column independently of bulk weak associativity.

The finite current column contains 285 coefficients, and the two twist hexagons contain 252. These identities control those coefficients. Since the differential of a mixed field can leave the finite window, the all-state chain law uses propagation of the differential defect, and weak associativity uses the common germ above. First-order classification concerns the four-parameter constant-coefficient current/ghost-kernel ansatz; finite second-order fits and failed exponential substitutions classify no unrestricted correction space.

With \(\delta\) the field differential, an explicit tensor operator \(\Lambda\) and cochain \(\mathbb H=\mathbb Y_-\Lambda\) satisfy
\[
[d_M^{\otimes},\Lambda]=S_M-1,
\qquad \mathbb Y_+=\mathbb Y_-S_M,
\qquad \delta\mathbb H=\mathbb Y_+-\mathbb Y_-.
\]
Thus \(S_M\) is a chain automorphism homotopic to the identity, and \(\mathbb H\) is a homotopy between the two chain fields on all algebraic pairs. The graded tensor calculation retains the minus term in \([d^\otimes,\iota^F\otimes L^F]\). The opposite \(\mathbb Y_+\) is weakly associative; the full quantum vertex axioms for its candidate exchange \(S_M^{-1}\) are not part of this theorem.

The scalar projection gives \(W_\pm\) at every level. Identification with \(E_3(e),\overline E_3(e)\) retains \(K\ne-2\), including \(K=0\), and
\(-\pi_{\rm cor}\mathbb H-H_3(e)=\hbar^2d_QG\) for the prescribed noncritical scalar homotopy and its correction \(G\). Two further exclusions have narrow domains. Ordinary current postcomposition is not a dg endpoint action: \([d_0,J_H(0)]\ne0\). The fixed curved ghost-output arrow is obstructed for \(K\ne0\); at \(K=0\), affine augmentation supplies a ghost-output chain map that discards the nonvacuum currents. Neither exclusion rules out a coherent physical comparison. Even unital chain fields on the full trace complex need not be homotopic: a trace-bilinear \(\hbar^2\)-correction can change the closed pair \(I_1\otimes I_1\) by \(\hbar^2\mathbf1\). This example changes the prescribed trace corner.

Retaining the ghost output gives a more precise bridge to the coefficient source. Let \(V=M_3^0\), let \(\mathcal G\) be the completed ghost algebra, and put \(F_L=\mathcal G/\widehat I_L\), where \(\widehat I_L\) is the closed left ideal generated by ghost modes of index at least \(L\). For \(n\ge0\), the retained kernel space \(\mathcal E^n_{\rm ret}\) consists of \(R_3\)-linear assignments of compatible values \(T_L(w)\in(V\otimes F_L^n)((u))\) to each algebraic current state \(w\in V\); set \(\mathcal E^n_{\rm ret}=0\) for \(n<0\). The Laurent floor may depend on \(L,w\).

Write \(\widehat J_\alpha(m)\) for the corrected current modes, with \(\alpha\) ranging over all four \(\mathfrak{gl}_2\) colours and \(m\in\mathbb Z\). Write \(c^\alpha_n\), \(n\in\mathbb Z\), for the ghost modes and \(*=\ast'_K\) for the completed ghost product. The ghost derivation is \(D\), and the left current–ghost coupling is
\[
Q(w\otimes g)=\sum_{\alpha}\sum_{m\in\mathbb Z}
\widehat J_\alpha(m)w\otimes c^\alpha_{-m-1}*g,
\]
with the ghost acting by left multiplication. For \(T\in\mathcal E^n_{\rm ret}\), set \((QT)(w)=Q(T(w))\) and \((DT)(w)=(1\otimes D)T(w)\). Its combined differential is
\[
\mathscr DT=DT+QT-(-1)^nTQ,
\qquad
(TQ)(w)=\sum_{\alpha}\sum_{m\in\mathbb Z}
T(\widehat J_\alpha(m)w)*c^\alpha_{-m-1}.
\]
Thus the right coupling multiplies the ghost mode after the kernel value. Ghost multiplication and differentiation are evaluated at sufficiently enlarged upper-mode cutoffs before projection. The current Maurer–Cartan relation cancels the ghost curvature, so \(\mathscr D^2=0\); this does not make each \(F_L\) a dg algebra. A retained cochain has the additional state input and degree components
\[
\mathcal Q^{\mathrm{ret},j}
=\prod_{p\ge0}\operatorname{Hom}_{R_3}
\bigl(M_3^p,\mathcal E^{p+j}_{\rm ret}\bigr),
\qquad
\delta_{\rm ret}\Psi=\mathscr D\Psi-(-1)^j\Psi d_M.
\]
The dressed field gives a cocycle \(\mathcal Y_-\in\mathcal Q^{\mathrm{ret},0}\). Let \(\Lambda^V\) be the restriction of the degree-minus-one exchange homotopy to \(M_3\otimes(V\otimes1)\), identifying the rooted ghost-free factor with \(V\). Define
\[
\mathfrak h^\Lambda(x)(w)
=\mathcal Y_-^\otimes\bigl(\Lambda^V(x\otimes w)\bigr),
\qquad
\mathcal Y_-^\otimes(x'\otimes w')=\mathcal Y_-(x')(w').
\]
Then \(\mathcal Y^\sharp=\mathcal Y_-+\delta_{\rm ret}\mathfrak h^\Lambda\) is a retained cocycle with scalar \(W_+\). Its polarization differs from \(\mathbb Y_+\) by a corner-kernel boundary.

Coefficient pairing uses the ordered rooted carrier with \(u\)-independent coefficients, one middle cutoff and finite right PBW support at each right quotient. Write \(A\) for the full smooth current algebra and \(A_R\) for its right quotients. At a right quotient adapted to the fixed current input \(w\), write a middle-degree-\(n\) element as \(y=\sum_iF_i\otimes b_i\), with \(F_i:F_L^n\to A\) and \(b_i\in A_R\), using one common \(L\). For \(\Psi\in\mathcal Q^{\mathrm{ret},j}\) and \(x\in M_3^{n-j}\), define
\[
(y\cap\Psi)(x)(w)
=\sum_{i,t,\gamma}u^t F_i(\gamma)
\,[u^t][\gamma]\,\Psi(x)_L(b_iw).
\]
Here \(t\in\mathbb Z\), \(\gamma\) runs through the ghost-monomial basis of \(F_L^n\), and \([u^t][\gamma]\) extracts its Laurent and ghost coefficients. The left current coefficient \(F_i(\gamma)\) acts on the output vector after this extraction. For the retained cocycles above, homogeneity gives a finite ghost box and a Laurent floor on each fixed input. Their pairings define continuous dg current-bimodule maps to \(Q_3=\operatorname{Hom}_{R_3}(M_3,\operatorname{Hom}_{R_3}(V,V((u))))[-1]\), with the pointwise Laurent topology in the two algebraic inputs. Both endpoint actions and both translations survive. For a retained degree-minus-one cochain \(\kappa\) with the same homogeneity bounds, the homotopy on middle degree \(n\) is \(H_\kappa(y)=(-1)^{n+1}y\cap\kappa\). The bulk field defines these rooted maps at every \(K\), including the critical level.

For \(K\ne-2\), let \(E_3\) be the prescribed pure-root evaluation, with retained cochain \(\Phi\in\mathcal Q^{\mathrm{ret},0}\), let \(\Delta=\Phi-\mathcal Y^\sharp\), and let \(k\) be the translation-compatible state contraction retaining the full trace factor. Write \(\Delta_1=\Delta|_{M_3^1}\), set \(\kappa^{(1)}|_{M_3^2}=\Delta_1k\), and set its other inserted-degree components to zero. Then \(\mathcal Y^{\sharp,1}=\mathcal Y^\sharp+\delta_{\rm ret}\kappa^{(1)}\) agrees with \(\Phi\) on inserted ghost degrees zero and one. Its evaluation agrees with \(E_3\) through middle degree one. The homotopy has zero scalar pairing and both translations; it is not asserted to start at order \(\hbar^2\) or to preserve the strict creation column. The sign and the trace factor in this first-degree calculation determine how to extend it. [The retained construction and its first-root comparison](index.html#ch17-retained-first-root).

On the small state complex, the dressed field \(\mathcal Y_-\) and \(\Phi\) have the same restrictions. Write \(i,p,k\) for inclusion, projection and contraction, with \(d_Mk+kd_M=1-ip\) and \(ki=0\). The small trace-free complex has the vacuum and two generators \(q,\omega\) with \(dq=2T\omega\). On the lifted \(\omega\), invariance of the leading term kills its nonnegative coadjoint action. On \(q\) the mode of index one differentiates the shifted kernel \(s^{\ell J}(u+\hbar)\), supplying the order-two correction. Appending an arbitrary trace-current polynomial and exterior trace monomial preserves the equality. The trace currents act by their translated multiplication field, and the ghost factors enter together in a single finite-cutoff germ. Thus \((\Phi-\mathcal Y_-)i=0\) on the entire small complex. It follows that
\[
\kappa=\Delta k-\mathfrak h^\Lambda ip,\qquad
\delta_{\rm ret}\kappa=\Delta(1-ip)+\Delta ip=\Delta .
\]
This homogeneous cochain commutes with both translations and has zero scalar pairing. Indeed \(\Delta_0=0\), and on small degree-one states the trace contraction pairs with a nonnegative trace current that annihilates the rooted state. The higher primitive for the already aligned representative is \(\kappa-\kappa^{(1)}\). After coefficient pairing, \(H_\kappa(y)=(-1)^{n+1}y\cap\kappa\) gives the homotopy in every middle degree \(n\).

The noncritical comparison extends to every marked degree on the restricted whole-Laurent current source. On each right slice and inserted input one middle ghost cutoff, one Laurent floor and finite right PBW support serve the entire source series. At a given output power these conditions leave only finitely many source powers, and homogeneity bounds the ghost monomials for each. On inserted trace ghosts one composes the rooted homotopy with the corresponding trace contractions, using the sign \((-1)^{a(a+1)/2}\) for trace degree \(a\). On positive traceless inserted inputs both maps use the prescribed state and Casimir corrections \(\mathcal J+\Xi\). This gives a homotopy to \(E_3\) into \(Q_3\) on the whole restricted marked complex. The global Cartan frame carries it to the resolved source. Precomposition by the raw current projection preserves the nested cutoffs, outer word-length direct sum and pointwise Hom placement.

These formulas compare paired coefficients. An independently defined physical operation must produce the positive inserted maps, realize both ordered products, and respect the rooted, inserted and output-unit cones with their prescribed homotopies. Lifting the prescribed endpoint maps coefficient by coefficient to bulk-valued maps has a separate obstruction. For the endpoint current acting by \(J_E(-1)\), a closed lift on the vacuum pair would have to project to \(E_1\), whose classical differential has \(E_1h_0\) coefficient \(2\). The contravariant contraction above is compatible with this obstruction. The independent physical module categories, their adjunction and tensorator, critical physical evaluation and an extension beyond \(R_3\) remain open.

There is a further distinction already on states. For \(K\ne-2\) the cohomology is \((R_3\mathbf1\oplus R_3 b)\otimes_{\mathbb C} L\), where \(b\) denotes the class of the lifted degree-three generator and \(L=\mathbb C[I_1,I_2,\ldots]\otimes\Lambda(\xi^I_j:j\ge0)\) is the full trace factor. Translation kills \(b\), and the product \(b^2\) has trace-free degree six, whose cohomology vanishes. The field is \(Y(x,u)y=(e^{uT}x)y\) on this cohomology. At \(K=-2\) a translation-compatible frame identifies the state complex with its classical differential through \(R_3\). The resulting module is free over \(R_3\) on the classical critical states, including the degree-zero oper jets and their odd forms. At this precision the poles of both ordered fields vanish in cohomology on all nine ordered pairs of the quadratic state, its odd level derivative and the degree-three ghost. Their regular products and translates generate the critical states, giving \(Y(x,u)y=(e^{uT}x)y\) with the independent trace factor. The positive-inserted and mixed marked operations require their own comparisons.

**Counterexample (truncation of both ghost inputs).** Write \(F^pM_3=M_3^{\ge p}\). The fields and their exchange descend to \(M_3/F^pM_3\), but neither \(\Lambda\) nor \(\mathbb H\) descends through both quotient inputs for any \(p\ge1\). With \(\theta_p=\xi^I_0\cdots\xi^I_{p-2}\) and \(\theta_1=1\), the pair consisting of the Cartan ghost \(h_0\theta_p\) and the current state \(E_1\) has a nonzero homotopy coefficient \(\hbar u^{-1}E_1\otimes\theta_p\) below ghost degree \(p\). Projecting only the rooted input and output while retaining the full inserted complex remains valid. [The truncation obstruction](atlas.html#atlas-c-native-r3-ghost-truncation-homotopy).

## Coefficient heat and the quartet map

Normalizing the Gaussian to take value one on the constant observable removes its determinant. To recover the variation of that factor, vary the positive parameter \(x=|\kappa|^2\) and insert the projection to the \(F\)-current component in the reflected heat trace. To turn that scalar into a comparison of states one must identify the integration cycles, source and cap. [The reflected heat operator and based determinant](#ch11-original-coefficient-heat-and-a-based-local-vacuum-line).

On a smooth reflected Ward filling, with \(\partial=\partial_z\), the triangular change of currents
\[
u'=h-\frac\kappa2\partial e,
\qquad w=f+\frac\kappa2\partial h+\kappa Te
              -\frac{\kappa^2}{2}\partial^2e
\]
splits the absolute current complex into a constant quartet and the stress complex. It and its inverse are bounded on each reflected Sobolev scale with offsets \((2,1,0,2,0)\); uniform estimates require the corresponding higher seminorms of the filling. The coefficient heat operator is block triangular, so its weighted trace is independent of the filling \(T\) at fixed source \(\mu\). This independence concerns the trace, not finite action maps or their nonscalar moments.

For the original gapped square-zero heat family at numerical \(\kappa\ne0\), on its common reflected domain, let \(A=da_0+a_0d\), let \(P_F\) project to the \(F\)-current component, and put \(x=|\kappa|^2\). Duhamel differentiation and graded cyclicity give
\[
x\partial_xW^{\rm aff}_\epsilon
 =\operatorname{Str}_X(P_Fe^{-\epsilon A}),
\qquad
c_F:=\operatorname{FP}_{\epsilon\downarrow0}
\operatorname{Str}_X(P_Fe^{-\epsilon A})
 =\frac12R_2[JP_F],
\]
where \(J\) is the parity operator and \(R_2\) the reflected constant heat coefficient. Its normal-reflection factor \(1/2\) is already included in \(R_2\); the displayed factor comes from the positive reflection sector. Level conjugation scales \((\kappa,T)\) together. The variation formula uses decay at the upper time endpoint, and \(P_F\) need not commute with \(d\).

Integrating from \(x=0\) remains conditional. A common domain, uniform sectorial bounds and gap, twice differentiable inserted traces and large-time majorants are needed along \((\kappa_r,T_r)=r(\kappa_*,T_*)\). For \(G_\epsilon(r)=\operatorname{Str}_X(P_Fe^{-\epsilon A_r})\), evenness and the endpoint decomposition would then give \(G_\epsilon(r)=O(r^2)\), making \(G_\epsilon(\sqrt y)/y\) integrable. Passing a finite part through that integral additionally needs uniform short-time and source-derivative bounds. The zero quartet torsions use the vanishing Euler characteristics of the weight-zero and weight-one complexes, not acyclicity alone. This auxiliary zero-level endpoint constructs no physical affine Gaussian. Universal vanishing of \(c_F\) is also open: the special symbol calculations cover only their specified jets and coefficients, and charged densities can integrate to zero while remaining nonzero pointwise.

The physical cotangent map still contains the formal bilinear transpose and response shear,
\[
\mathcal M_\mu(a,\gamma)
 =(R_Ta,R_T^{-t}(\gamma-K_\mu a)).
\]
Bounded current transport does not prove its ordinary relative-domain, cycle or semidensity properties. On a meridian disk, \(\partial_zr=\bar z/(2r)\) is generally nonzero, so the Green flux retains a first normal jet. The required finite-cut pushforward from the cyclic map \(J_R\) and quartet integration \(I_{\mathcal Q}\),
\(\Pi_\epsilon=(\mathrm{id}\otimes I_{\mathcal Q,\epsilon})J_{R,\epsilon}\), its source/cut/scale square and its independently normalized cap remain unconstructed. A coefficient-heat response difference is not yet the transported physical quartet connection: its covariant response term has sign \(-d_UW\), opposite to the logarithmic response. On uncut quadratic observables a normalized pushforward does exist. Insert a stress observable by the inverse Hessian map applied to the stress summand, then evaluate it in the affine Gaussian. The result is a continuous normalized stress BV functional on the ordinary factorial-weighted tests. For a small, smooth sourced Ward family, an interior even quadratic test distinguishes its off-shell mixed covariance from that of the independently gauge-fixed stress Gaussian. Rescaling an amplitude has no effect on this normalized moment. Density, phase, finite subtractions and admissible corrections remain part of the cut comparison. Interaction moments and spatial sewing require additional maps; numerical nonzero \(\hbar\) cannot be substituted for the truncated formal \(\chi\) coefficient.

Does the spatial response admit propagation by a nonnegative self-adjoint Hamiltonian? At a fixed tangential frequency the meridian calculation gives an explicit function of the distance between opposite-side probes. Its values at finitely many distances already bound the norms of any proposed Hilbert-space endpoints. Take the \(q=1/2\) solid torus at zero Ward source. Freeze the principal mixed \(dt\)-to-scalar response at an interior point of its \(r=\sqrt2\) meridian, at positive tangential frequency \(k\) and zero frequency in the second tangential direction. For opposite-side probes at total normal distance \(u>0\), put \(a=|\kappa|^2/8>0\), \(\alpha=\sqrt{1+2a}/(1+a)\) and \(\beta=a/(1+a)\). Fourier inversion gives
\[
 K(u)=(A+Bu)e^{-ku}+Ce^{-(\alpha+i\beta)ku},\qquad B=(1+i)/4,\quad C\ne0.
\]
The double pole gives the term \(u e^{-ku}\). Together with the second exponential this yields an exact three-dimensional transfer with a complex bilinear pairing.

Could one obtain the same measurements as \(K(u)=\langle b,e^{-uH}c\rangle\) for a nonnegative self-adjoint \(H\) and fixed Hilbert vectors \(b,c\)? At \(|\kappa|^2=8,\ k=1,\ \Delta=\log2\), let \(p(x)=x(x-\tfrac12)^2T_{40}(2x-1)=\sum_{j=1}^{43}p_jx^j\), with \(T_{40}\) the Chebyshev polynomial. The spectral theorem bounds \(\left|\sum_jp_jK(j\Delta)\right|\) by \(\|b\|\,\|c\|\max_{0\le x\le1}|p(x)|\). The maximum is \(1/4\), and the sum computed from the meridian kernel has modulus greater than \(6013.277199869516561\). The 43 positive widths therefore force
\[
 \|b\|\,\|c\|>24053.108799478066244.
\]
Increasing the Chebyshev degree eliminates the double-pole contribution by the same double root and amplifies the exponential at the nonreal point \(e^{-(\alpha+i\beta)k\Delta}\). No sequence with uniformly bounded endpoint norm products can converge at every width \(j\log 2\) for \(j=1,2,\ldots\). Each finite grid still admits exact interpolation by a positive diagonal generator with complex endpoint weights. This computation concerns the specified off-shell component at zero source. Reflection positivity of the full state and the source-dependent spatial sewing, including the residual half-density, phase and cap normalization, remain separate questions.

## The genuine Heisenberg action space

Let the rank-one Heisenberg algebra \(H=V_\kappa\) have current \(J\) with \(J_{(1)}J=\kappa\mathbf1\) and \(\kappa\ne0\). An action of the exterior algebra \(B=\Lambda(\epsilon)\) takes two inputs, an exterior state and a Heisenberg state. Its source is \(X=B\otimes H\), where \(|\epsilon|=1\) and \(d\epsilon=T\epsilon=0\). To read the component of such an action, represent it by \(X\xleftarrow{p}S\xrightarrow{f}H\) with \(p\) a surjective state quasi-isomorphism. Choose a closed lift \(e\in S\) of \(\epsilon\otimes1\). Its translate \(Te\) lies in the acyclic kernel of \(p\), so \(du=Te\) for some \(u\) in that kernel. Apply the action map \(f\) to \(u\). The resulting class in \(H/TH\) is \((\mathrm{ch}/\kappa)[J]+\mathrm{ct}[\mathbf1]\). The charge \(\mathrm{ch}\) and constant \(\mathrm{ct}\) distinguish the components. To find the automorphisms within a component we must also retain the path fixing the unit. [The pointed Heisenberg action space](#ch07-genuine-heisenberg-fibre).

Work in the localization of ordinary algebraic dg vertex superalgebras at state quasi-isomorphisms. The comparison \(q_B:N\operatorname{Act}_{\mathrm{roof},H}(B)\to\mathscr F_H(B)\) uses the full original actor-roof category, both legs and every admissible boundary arrow. Its target is
\[
\mathscr F_H(B)=\operatorname{hofib}_{\mathrm{id}_H}
 [\operatorname{Map}(X,H)\longrightarrow\operatorname{Map}(H,H)].
\]
The arrow is restriction along the canonical inclusion \(H\to X\). A connectivity theorem gives
\(\operatorname{Map}(A,C)\simeq\operatorname{Hom}_{\rm VA}(H^0A,Z^0C)_{\rm disc}\)
when \(H^{>0}(A)=0\) and \(C^{<0}=0\). Consequently the unit path in this target has contractible choices. The separate pointing path \(\eta\) of a sphere representative must still be retained through strictification and refinement.

The actual universal-tuple augmentation supplies
\[
\Pi:\mathscr F_H(B)\longrightarrow\mathbb C^2_{\rm disc}\times K(\mathbb C,1),
\qquad \Pi q_B\text{ is a weak equivalence}.
\]
Its component condition is \(F_{(0)}J=0\), equivalently \(F\in\mathbb CJ+\mathbb C1+TH\), rather than an arbitrary closed-pair coordinate. Convolution on full roof diagrams and an explicit scalar simplicial family identify the actual maps and their fibres. Writing \(\Theta=(\operatorname{ch}/\kappa,\operatorname{ct})\), \(\mathscr F^0=\Theta^{-1}(0)\), and \(\alpha_0\) for the trivial action, one obtains
\[
\mathscr F_H(B)\simeq\mathbb C^2_{\rm disc}\times\mathscr F^0,
\]
and the exact criterion
\[
q_B\text{ is an equivalence}\quad\Longleftrightarrow\quad
\pi_0\mathscr F^0=*,\quad
\ker\chi_{\alpha_0}=0,\quad
\pi_n(\mathscr F_H(B),\alpha_0)=0\ (n\ge2).
\]
Here \(\chi\) is the scalar loop detector. Translation by a \(q_B\)-image action preserves this detector and its scalar section. Right convolution by every pointed genuine action is an equivalence carrying the trivial action to it. Hence each fundamental group is abelian and acts trivially on the higher groups of its component. [The pointed action space](#ch07-genuine-heisenberg-fibre). Over an image component, the actual \(q_B\)-fibre has component set \(\ker\chi\) and higher groups shifted by one; it is distinct from the connected scalar-detector fibre on one genuine component.

For the universal tuple stages \(S_{H,a}\), half-interpolation asks, cofinally, for actual maps \(Y\to X\) and \(Y\to S_{H,a}\) over \(X\), with the first a state quasi-isomorphism. It implies the full equivalence. Target-\(H\) tuple surjectivity supplies neither this condition nor the additional map \(S_{H,b}\to Y\) required by full exact interpolation. General tame incoming roofs need not be nonnegative, and their tame ideal need not be the ideal of all negative states.

For a pointed kernel triple \((S,p,D)\) representing a detector-kernel loop or a higher homotopy class, linearization becomes null. Equality with that linearization follows if a frame square lies in an actual acyclic dg ideal
\(\mathcal I'^2\subseteq\mathcal J\subseteq\ker p\cap\ker D\).
This covers the specified split square-zero roofs, charge-graded roofs generated in charges zero and one, the stated acyclic-module extensions, and the canonical-frame case. It concerns kernel loops and higher classes, not classification of arbitrary components. A generated-square or generated-cube version gives another sufficient nullity theorem. A primitive functional can vanish while no suitable acyclic enlargement exists for the chosen frame, even when the genuine class is zero. Its identification with the global nullity functional requires a kernel triple; identifying its domain on an ideal \(\mathcal J_0\) with product cycles requires \(\mathcal J_0\subseteq\mathcal I_S^2\). These ideal conditions give sufficient tests on the chosen resolutions.

The pointed mapping spaces give another formulation of the positive-degree calculation. For \(X_b=H\oplus\epsilon_bH\), \(|\epsilon_b|=b\), it is equivalent to looping inducing equivalences
\[
\operatorname{Map}_{H//H}(X_0,X_b)
 \longrightarrow\operatorname{Map}_{H//H}(X_1,X_{b+1}),
\qquad b\ge0;
\]
the \(b=0\) case suffices. These are genuine section-preserving mapping fibres, not full faithfulness on arbitrary shifted pairs. The relative interval construction keeps the base path fixed; imposing equal endpoints on an arbitrary base path would add an unwanted \(H\,ds\). Finally, scaling \(\epsilon\mapsto t\epsilon\) gives a polynomial family, not a differential-form homotopy, since \(d(t\epsilon)=dt\,\epsilon\), and no weight decomposition or graded representative theorem is available. There is an equivalent test directly in the pointed slice. In the component of \(\alpha_0\), let \(\Phi_0\) be the homotopy fibre of the scalar detector to \(K(\mathbb C,1)\). The space of automorphisms of \(H\oplus\epsilon_1H\) under and over \(H\) which induce the identity on state cohomology is equivalent to \(\Omega\Phi_0\). At nonzero level the two-copy scaling of a square-zero sphere leaves its constant and linear terms. The unit fixes the first. The second gives the scalar parameter for a loop and vanishes for higher spheres. Thus the scalar-detector fibre and the marked identity-on-cohomology automorphism space are contractible.

For a genuine action with zero charge and constant, use the first jet of its scaled family \(f_t\). After refinement on the same incoming resolution the jet gives a degree-minus-one derivation \(E\) over \(f_t\) with \(Ed=\partial_t f_t\). The corrected family \(f_t+dt\,E\) is a path of vertex maps from the projection to the given action with its unit comparison. Translation by a realized action supplies the same conclusion in every sector. Thus \(q_B\) is an equivalence and \(\mathscr F_H(B)\simeq\mathbb C^2_{\rm disc}\times K(\mathbb C,1)\). [The positive-sphere and component calculations](#ch07-genuine-heisenberg-fibre).

There is a restriction on how one may resolve this fibre. In the category of Brown roofs \(X\leftarrow S\to H\) with strict refinements, the full subcategory of sources admitting no strict vertex-algebra map \(H\to S\) is homotopy initial. The subcategory admitting such a map, even without imposing that it lift the marked boundary, fails incoming homotopy initiality already above the trivial action. Restricting to nonnegative cohomological degrees has the same defect. The path above is constructed on an incoming resolution in the full category.

## Nested currents and their completion domains

Fuse the first two currents at separation \(w\) and bring in a third at separation \(z\). Put \(p=w^{-1}\) and \(s=w/z\). For a factorized input \(T_{12}\otimes M_3\), take the pair in a fixed nonzero state \(t\) and choose independent third states \(v_j\), all in degree zero in this example. Completing all three slots in \(p\) admits the sum \(\sum_{j\ge0}p^j(t\otimes v_j)\) as the coefficient of \(s^0\). Now complete the pair first and tensor algebraically with \(M_3\). At any fixed outer order and cohomological degree the inner series must be a finite sum of pair series tensored with spectator states. Our coefficients use infinitely many independent \(v_j\) at the single outer order zero. They therefore lie outside this second space. To compare that order of fusion with a rational expansion in \(s\), take the intersection of the pair-first and rational domains. [Factorized inputs and the common domain](#ch08-factorized-common-domain).

For \(\mathfrak g=\mathfrak{sl}_2\) and \(k\notin\mathbb Q\), assume the specified smooth affine–right-\(Y_k\) realization, its full unbounded tensor–Hom unit, common-cutoff cofree actions, native ideal triangle and bounded-below positive-current torsion theorem. The input \(T\) is an arbitrary ordinary unbounded dg left \(Y_k^{\otimes3}\)-module, including correlated inputs. With inner separation \(w\), outer separation \(z\), \(p=w^{-1}\), \(q=z^{-1}=sp\), put
\[
\mathcal O=\mathbb C[s]_{(s)},\quad
D=\mathcal O((p))[s^{-1}],\quad
K_R=\mathbb C(s)((p)),\quad K_N=\mathbb C((p))((s)).
\]
The coefficient complexes have carriers \(L_D(T)=(T\otimes\mathcal O)((p))[s^{-1}]\), \(L_R(T)=(T\otimes\mathbb C(s))((p))\) and \(L_N(T)=T((p))((s))\). For prescribed double-coefficient expansions and every vector space \(V\),
\[
(V\otimes\mathbb C(s))((p))\cap V((p))((s))
 =(V\otimes\mathcal O)((p))[s^{-1}].
\]
For \(\sum q^nf_n(s)\), the exact condition is \(\inf_n(n+\nu_s(f_n))>-\infty\). This gives algebraic gluing and completion formulas. Maximality concerns these expansions; no field map fixing \(p,s\) exists between the two fields, but abstract common overfields do exist. Compatible common forms are required for general field-defined inputs; some nonconstant tests have them.

The twist preserves quasi-isomorphisms by finite quotients and surjective towers. Its jointly completed intermediate module \(E=S_w^{12}(T)=T((p))\), with the pair differential, has an independently defined binary current recipient and an actual next operation \(S_z(E)=L_N(T)\). The comparisons retain the original unit and evaluation on the full ambient \(D_{\mathcal N}\) of smooth tests with jointly locally nilpotent positive-current cohomology over the named fields, and on constant tests from \(D_{\mathcal N}(A)\) for \(D\). The ground-field bounded-recipient argument gives this constant-test three-point theorem over \(D\); it is not a theorem on arbitrary ring-defined test representatives. The realizations form an enhanced derived span through the \(D\)-object. Full units extend over every commutative complex coefficient algebra, and every left comb has its stagewise binary recipient over successive Laurent fields.

For \(T=T_{12}\otimes M_3\), the separately factorized recipient uses \(E_1=S_w(T_{12})\otimes M_3\). The inclusion \(E_1\to E\) sends a pair series tensored with a spectator state to its joint coefficient array. It is a quasi-isomorphism when \(H^\bullet(M_3)\) is finite-dimensional in total. For an inflated regular third factor it has the nonzero defect \(U((p))/(U\otimes\mathbb C((p)))\), with zero differential. Moreover, \(p^nv\) tends to zero in the declared source topology but has constant outer \(s\)-order: the map to the native outer Laurent topology is not continuous. A coarser coefficient topology is a different construction. Raw cones \(D\to K_R,K_N\) remain nonzero even for the trivial input; the cones that vanish for finite Wilson cohomology are those of the scalar-extended maps. Algebraic base change is not completion.

The full three-pole rational-cluster tensorator includes the extra resolving generators at \(a_1\), and its direct-sum bar roof gives the complete field evaluation for arbitrary constant joint inputs. Under the retained native hypotheses, its joint native application preserves the original affine restriction and outgoing unit. The application to the independently factorized endpoint retains finite total spectator cohomology. The further evaluation \(\Theta\) is not asserted to be a quasi-isomorphism. These field results are distinct from the adapted full-current evaluation on the factorized common domain defined below.

Cluster-infinity expansion has a separate target. If \(P\) is the affine Chevalley resolution and \(F_NP\) is generated by coefficient vectors and exterior factors in the tail \(t^N\mathfrak g[t]\), put \(\widehat P_{K_w}=\varprojlim_N\bigl((P/F_NP)\otimes K_w\bigr)\). The map \(e_\infty:P_c^{(12)}\to\widehat P_{K_w}\) is a rational-current/right-line quasi-isomorphism and gives the Taylor-completed outer evaluation. There is no normalized strict ghost-linear retraction to the finite affine resolution. At a fixed positive pole order \(r\), the coefficient \(\binom{r+H}{H}\) in the Taylor partial sums prevents the stated continuous extension of the affine inner tensorator. The rational-cluster evaluation remains valid. An affine-linear contraction and its first action homotopy do not supply a typed full twisted-bar evaluation lift. [Taylor completion and its limits](atlas.html#atlas-c-horizontal-cluster-taylor-completion).

Outgoing actions preserve \(L_D,L_R,L_N\), not all positive lattices. For the occupied input \(T=M_1\otimes\mathbb C_\varepsilon\otimes M_3\), a jet series \(\sum_{n\ge n_0}q^n\tau_n(t)\), with \(\tau_n\in T[t]\), lies in the common domain exactly when its antidiagonals \(A_P(s)=\sum_ns^n[t^{n-P}]\tau_n(t)\) are rational in \(s\), equivalently lie in \(s^{n_0}(T\otimes\mathcal O)\), and have one common lower \(p\)-bound. Finite normal jets are obtained as quotients. The substitution \(t=p^{-1}\) embeds no nilpotent jet ring. For the regular triple, there is no degree-zero cycle \(\xi\in\mathbf1+pL_A\), with lattice \(L_A=(T\otimes\mathcal O)[[p]]\): the weight-one obstruction is nonzero. This normalization is essential; congruence modulo \(p\) after inverting \(p\) is vacuous.

Normalized-vacuum deletion is an actual current-complex quasi-isomorphism in all three slots, on \(D_{\mathcal N}(A_{K_R})\) and \(D_{\mathcal N}(A_{K_N})\), and on constant tests from \(D_{\mathcal N}(A)\) over \(D\), with the ambient smooth mapping complexes. The map restricts to proper wedges without the occupied block and applies its normalized cofree energy-zero covector. The original evaluation survives. Slot one leaves \((z,0)\), slot two leaves \((z+w,0)\), and slot three leaves the nonanchored pair \((z+w,z)\) with action \(\Delta_w\circ\tau_z\). The third-slot rational-source chart map is taken after extension to the outer scalar field. On the smooth tests it transports the polynomial coordinate at infinity by \(u\mapsto u-z\), including the induced change on the test action. For an original \(K_w=\mathbb C((p))\) test pulled to \(K_N=K_w((s))\), the result is a family of binary cochains with a lower outer bound on each finite polynomial and test stage. Different stages may have different bounds. For the surviving binary output \(E_{\rm bin}=S_w(M_1\otimes M_2)\), the coefficient cone between scalar extension and outer completion has
\[
H^i(E_{\rm bin})((s))\big/\bigl(K_N\otimes_{K_w}H^i(E_{\rm bin})\bigr)
\]
in degree \(i\). It vanishes precisely when every \(H^i(E_{\rm bin})\) is finite-dimensional over \(K_w\). Two inflated horizontal regular inputs give a nonzero class. Integral deletion and opposite insertion on the full occupied domain remain open. This is deletion of the normalized trivial or resolved-vacuum input, not of a regular line input. [Occupied deletion](atlas.html#atlas-c-horizontal-occupied-deletion-all-slots).

For finite-dimensional Wilson modules, let \(\Omega_{ij}\) denote the pairwise Casimir operators. The rational cycle and iterated cycle differ by the unique matrix gauge
\[
sG'=A(s)G-GA(0),\quad
A(s)=k^{-1}\bigl(\Omega_{13}/(1+s)+\Omega_{23}\bigr),\quad G(0)=1.
\]
The cycle maps include the actual resolution augmentations; the chosen resolution of a trivial module is nontrivial before augmentation. Nonresonance proves the all-orders recursion, and \(\Omega_{13}\ne0\) gives nonrationality by monodromy at \(s=-1\). With \(\Omega_{(12),3}=\Omega_{13}+\Omega_{23}\) and residue \(R=-\Omega_{(12),3}/k\), the recurrence is \(n+\operatorname{ad}_R\). After the singular-power and scale normalizations in \(x=w/(w+z)\), continuation on \(0<x<1\) with positive-real logarithms gives the ratio \(F_1^{-1}F_0\) of normalized endpoint solutions, the KZ associator with arguments \(-\Omega_{12}/k,-\Omega_{23}/k\); the raw gauge ratio is not this constant comparison. This controls finite-dimensional cohomology and cycles, not a continuous gauge on the entire intermediate complex. For the outer connection \(\nabla_s=s\partial_s-A(s)\), with \(A_0=A(0)\) and the displayed equation \(sG^{\prime}=A(s)G-GA_0\), the normalized horizontal frame is \(G(s)s^{+A_0}\), using the chosen logarithm.

Finite energy heads must first be extended from \(\mathcal O_0=\mathbb C[s,(1+s)^{-1}]\) to \(\mathcal O\) before claiming the latter limit. Their homogeneous lattice has energy index \(e\ge\max(\omega,0)\) at weight \(\omega\); failure of degreewise surjectivity requires infinitely many energies in one cohomological degree. These heads do not yet give the original integral collision diagrams.

For a factorized constant input \(T=T_{12}\otimes M_3\), the actual pair-first carrier is \(N_1(T)=(T_{12}((p))\otimes M_3)((s))\), with the same spectral differential as \(L_N(T)\). Define
\[
L_D^{\mathrm{fac}}(T)=L_D(T)\cap N_1(T)=L_R(T)\cap N_1(T)
\]
as coefficient arrays. Degree by degree, for each outer exponent \(j\), the whole inner series lies in \(T_{12}((p))\otimes M^{(j)}\) for some finite-dimensional graded \(M^{(j)}\subset M_3\). This is a dg \(Y_D\)-module stable under the outgoing action, factorwise incoming actions and the logarithmic spectral connection. It preserves quasi-isomorphisms and gives an algebraic span from the radial object to the actual independently completed endpoint. A joint endomorphism commuting with all line actions can still destroy finite spectator support. If \(H^\bullet(M_3)\) has finite total dimension, the canonical inclusion \(L_D^{\mathrm{fac}}\to L_D\) is a quasi-isomorphism, and its raw comparison cones agree with the joint ones. At trivial input the raw cones remain \(K_R/D\) and \(K_N/D\). Define the three-point spectral kernel
\[
\mathcal R_{\mathrm{sp}}=r_{12}(w)+r_{13}(z+w)+r_{23}(z),
\]
distinct from the Wilson residue \(R\) above. For the regular input \(T=Y^{\otimes3}\), the vectors \(\mathbf1,\mathcal R_{\mathrm{sp}}\mathbf1\) lie in the common domain. The entire three-pole rational resolution has an evaluation on an adapted incoming bar, including for regular inputs. Resolve \(T_{12},M_3\) by separate augmented free bars before taking the factorized intersection. The three-pole tensorator multiplies the two bar heads and leaves all letters and both terminal inputs in place. Shuffle recovers the radial evaluation. An outer-bar resolution compares it with the independent pair-first evaluation. For each fixed resolved current, the Laurent losses and admissible spectator factors at a fixed outer exponent are independent of both incoming word lengths. The proper-current formula on regular words also takes values in the split complex of restricted proper cochains. Representability on arbitrary common-ring smooth tests still requires the native higher action maps there. [The common-domain construction](index.html#ch08-factorized-common-domain).

**Counterexample (ordinary Hom on an acyclic test).** Let \(W_D\) be the scalar extension of the regular-top affine object. The complex \(E=[D\xrightarrow{p+s}D\to D/(p+s)]\), in degrees \(0,1,2\), is acyclic. Yet the ordinary current formula on the acyclic test \(W_D\otimes_D E\), with trivial incoming coefficient, has \(H^0=D/(p+s)\ne0\). Ordinary \(\operatorname{Hom}_D\) therefore does not define the proposed derived functor on arbitrary \(D\)-test representatives. Explicit bounded finite \(W_D\)-cell models do have the actual comparison: finite cone induction from \(W_D\) preserves it and proves invariance between those models. This includes the parameter-Verma model \(W_D\otimes_D\Lambda^\bullet\mathfrak b_D\otimes_D D_s\), where \(\mathfrak b=\langle H,E\rangle\) and \(D_s\) is the rank-one module with \(H=s\), \(E=0\). The closed field and constant-test results are unaffected. [The counterexample and finite-cell comparison](index.html#ch08-common-ring-tests).

For two independent pairs at \((z+w_1,z,w_2,0)\), put \(p_i=w_i^{-1}\), \(q=z^{-1}\), \(s_i=q/p_i\), and define
\[
\Lambda_{\mathrm{fac}}=\mathbb C((p_1))\otimes\mathbb C((p_2)),\quad
\Lambda_{\mathrm{sym}}=\mathbb C[[p_1,p_2]][(p_1p_2)^{-1}],
\]
\[
F_{12}=\mathbb C((p_1))((p_2)),\qquad
F_{21}=\mathbb C((p_2))((p_1)).
\]
For \(T=T_{12}\otimes T_{34}\), let \(E_{\mathrm{fac}}=S_{w_1}(T_{12})\otimes S_{w_2}(T_{34})\) and \(N_{\mathrm{fac}}=S_z^{\Lambda_{\mathrm{fac}}}(E_{\mathrm{fac}})\). The two ordered outer carriers \(N^{12},N^{21}\) are \(T((p_1))((p_2))((q))\) and \(T((p_2))((p_1))((q))\), with the same four-point spectral differential. Their coefficient intersection is \(N_{\mathrm{sym}}=(T[[p_1,p_2]][(p_1p_2)^{-1}])((q))\); the factorized coefficients agree in both orders. Finite total cohomology of both pairs makes the canonical factorized-to-ordered maps, including scalar extension before versus after the outer completion, quasi-isomorphisms over either named field. Under the retained native hypotheses their independent binary recipients, evaluations and units agree on every smooth \(F((q))\)-test whose positive currents act jointly locally nilpotently on cohomology, for either ordered field \(F\). The two fields and the unextended legs remain distinct.

The conic common domain is defined by
\[
\mathcal O_2=\mathbb C[s_1,s_2]_{(s_1,s_2)},\quad
\mathfrak q=s_1^{-1}\mathcal O_2+s_2^{-1}\mathcal O_2,\quad
D_{\mathrm{con}}=\bigcup_{c\ge0}
\left\{\sum_{n\ge-c}q^n\theta_n:\theta_n\in\mathfrak q^{n+c}\right\}.
\]
Substitution \(s_i=q/p_i\) embeds it into \(\Lambda_{\mathrm{sym}}((q))\). Write \(L_{D_{\mathrm{con}}}(T)\) for the same support condition with \(T\)-valued coefficients and the four-point spectral differential. The factorized intersection has scalar ring and carrier
\[
D_*=D_{\mathrm{con}}\cap\Lambda_{\mathrm{fac}}((q)),\qquad
L_*^{\mathrm{fac}}(T)=L_{D_{\mathrm{con}}}(T)\cap N_{\mathrm{fac}}(T).
\]
It is an algebraic dg \(Y_{D_*}\)-module mapping to the radial and factorized objects. This intersection preserves quasi-isomorphisms in either constant pair. The entire four-pole resolution over \(D_*\) evaluates on the corresponding product of resolved input bars. Each inner tensorator acts on its own head, leaving a finite sum of separated tensors at each outer power. Multiplication into these heads preserves the defining rank condition. The radial shuffle and the bar of the two independently completed pairs compare the actual evaluations. It is generally not a \(D_{\mathrm{con}}\)-module: the conic scalar with symmetric expansion \(\sum_{n\ge0}p_1^np_2^n\) has infinite separated rank at outer order zero. The factorized condition requires finite algebraic tensor rank in the two completed cluster factors at each outer coefficient. [The four-point intersection](atlas.html#atlas-c-horizontal-four-point-factorized-intersection).

The full four-pole rational tensorator is typed over \(B=\Lambda_{\mathrm{fac}}((q))\):
\[
\Delta^{12|34}:P_{c,B}^{(4)}
\longrightarrow(P_c^{(12)}\otimes_{\mathbb C}P_c^{(34)})((q)).
\]
Here \(P_c^{(4)}\) resolves the four-pole current algebra and \(P_c^{(12)},P_c^{(34)}\) resolve the two rational cluster algebras over their respective inner fields. The inner tensorators commute and their composite gives the full four-point evaluation. For a bar over \((Y\otimes Y)_{\Lambda'}\), extend its head to \((P_c^{(12)}\otimes P_c^{(34)})\otimes_{\Lambda_{\mathrm{fac}}}\Lambda'\). The unchanged-copy normalization concerns exterior resolving generators; coefficient currents retain their cross Taylor tails. Fixed-word polynomial bounds apply before PBW reordering. The finite rational-position identities extend separately to \(B\) and \(D_{\mathrm{con}}\); no map from all of \(D_{\mathrm{con}}\) to \(B\), or injectivity under arbitrary nonflat extension, is needed.

For constant inputs at any finite number of positions, the spectral family has an actual flat connection. With \(R_{\mathbf a}=\sum_{i<j}r_{ij}(a_i-a_j)\), let \(L\) be the odd line derivation satisfying \(Lc_{a,n}=k^{-1}\kappa^{ab}B^b_n\), \(LB^a_n=0\) and \([Q,L]=T_Y\), where \(Q\) is the line differential. Then
\[
\nabla_i=\partial_{a_i}+\rho_T(L^{(i)}R_{\mathbf a})
\]
is flat and commutes strictly with \(d_T+\rho_T(R_{\mathbf a})\). Its logarithmic corner form preserves the stated coefficient carriers. The outgoing action is horizontal up to the first homotopies \(L^{(i)}\Delta_{\mathbf a}\). This does not give a connection on an arbitrary shape-field input, a normalized full-complex gauge, or current/native comparisons over polynomial parameter forms.

Normal jets illustrate the distinction between a surviving binary current and an occupied three-point source. After applying the normalized middle vacuum covector, the surviving separation is \(z+t\), where \(t\) is the inner collision coordinate. Substitution \(q\mapsto q/(1+tq)\) acts on every finite jet \(\mathbb C((q))[t]/t^{l+1}\) and transports binary evaluation and the unit on pulled tests. Before projection the same current \(x/(u-z-t)\) has coefficient \(-t^{-1}x_0\) at the occupied slot. This pole acts on the regular horizontal top and disappears under the normalized covector. The opposite insertion and an integral comparison of the full independently formed protected iterates must still account for it.

The remaining native questions concern the original outer topology, a common smooth current recipient on the allowed input and test forms, and the full cone between independent integral iterates, including their occupied units at a nonzero normal jet. A normalized gauge on the whole complex would also need a continuous inverse and action homotopies. The flat spectral connection, the algebraic evaluations on the product of bars, and the moving-chart calculation give prescribed maps against which interchange, associativity and higher tree compatibilities can be tested. [The remaining composition problem](index.html#problem-composition-domains).

The common Laurent domain specifies which expansions one can compare. It still matters which flag of collisions produces a boundary map. A rank-two irregular connection gives a case in which one can take the restrictions explicitly and then dualize them. Put \(x=z_1-z_3,\ y=z_2-z_3,\ r=y/x\), and let \(j:U=\{xy(x-y)\ne0\}\hookrightarrow\mathbb A^2\). Pull back the rank-two connection \(M_a\) with horizontal equation \(dY=\left(\begin{smallmatrix}0&a\\0&-2s^{-3}\end{smallmatrix}\right)Y\,ds\) in \(s=1/r\). Write \(C_a=\operatorname{Cone}(j_!M_a\to j_*M_a)\), and let \(i\) include the origin. For each of the lines \(D\) at \(r=0,1,\infty\), the localization boundary has common target \(i^!C_a[1]\). In covariant de Rham grading \(\mathrm{DR}(\mathcal O_{\mathbb A^2})=\mathbb C[2]\), it is the actual dual of formal restriction,
\[
 \partial_D=R_D^\vee:P_D^\vee\longrightarrow Q^\vee\simeq i^!C_a[1].
\]
Here \(Q=R\Gamma_{\mathrm{dR}}(U,M_a^\vee)\) is unshifted and \(P_D\) is the product of the radial and formal angular de Rham complexes along the punctured line. The boundary for extension by zero from that punctured line fixes the same sign convention on all three sources.

The formal restrictions admit finite logarithmic cochain models. In a normalized horizontal frame at a finite point the projection takes the constant term of a degree-zero Laurent coefficient and the residue of a degree-one form. The resulting maps on representatives determine all three derived morphisms. Take the radial form \(\theta=d\log x\) first in each exterior product. In a frame \(e,f\) of the dual angular connection, use \(b=f\,dr\), \(E_j=e\,d\log(r-j)\), \(F_j=f\,d\log(r-j)\) for \(j=0,1\). The angular complex has degree-zero generator \(e\) with \(de=-2ab\) and closed degree-one generators \(b,E_0,F_0,E_1,F_1\). At \(c=0,1\), write \(\eta=d\log x,\ \sigma=d\log(r-c)\) and take the normalized horizontal frame \(e_c,f_c\). Then
\[
 R_c(e)=e_c,\qquad R_c(b)=0,\qquad
 R_c(E_j,F_j)=\delta_{cj}\,\sigma(e_c,f_c),\qquad R_c(\theta)=\eta .
\]
At infinity take \(\eta=d\log y,\ \sigma=d\log(x/y)\). Projection to the regular summand gives \(e\mapsto1,\ b,F_j\mapsto0,\ E_j\mapsto-\sigma\), and \(\theta\mapsto\eta+\sigma\). The negative residue and the extra radial term thus have different origins. The joint image of the three dual maps in degrees \(0,-1,-2\) has ranks \((1,5,4)\) for \(a=0\) and \((0,4,4)\) for \(a\ne0\). In the fixed graded frames the upper-minus-lower Stokes multiplier is \(2i\sqrt{\pi}\,a\). It is minus the period of the dual extension class \(-2af\,dr\) on the upward rapid-decay contour \(r=\epsilon+i\mathbb R\), \(0<\epsilon<1\).

An independent trivial fourth factor gives a second specialization. Put \(v=z_4-z_3\) and first take the inner triple boundary with \(v\ne0\). The ordinary outer link at \(v=0\) gives \(\mathrm{id}_{\Lambda(dv/v)[1]}\otimes\partial_D\), outer factor first. A coupled fourth input gives a different simultaneous extension. Put \(s=z_2-z_1,\ r=(z_3-z_1)/s,\ t=(z_4-z_1)/s\) on the distinct-point open and tensor \(N_a(r)\) with \(d-J\,d\log(t-r)\) on a two-dimensional \(W\), \(J^2=0\ne J\). The line \(r=t=1\) is the \(234\) collision for \(s\ne0\). Fix the horizontal frame of \(N_a^\vee\) at \(1\), the dual fibre in the positive real chamber and the labelled logarithms \(p=d\log(r-1),\ q=d\log(t-r)\). The flags through \(u=r-1=0\) and \(w=t-r=0\) then have the same marked source. In the \(u/w\) chart, \(\beta=d\log(1+u/w)\) has zero logarithmic residue at \(u/w=0\). In the \(w/u\) chart it is \(d\log(u/w)+d\log(1+w/u)\), and only \(d\log(u/w)=p-q\) survives. Thus the two restrictions already disagree on \(\beta\).

For \(C=\operatorname{Cone}(j_!M\to j_*M)\) of this four-point coefficient on \(\mathbb A^3\), the two shifted dual restriction maps land in \(i^!C[1]\). Naturality of the localization triangle fixes both signs relative to its extension-by-zero boundary. In degrees \(1,0,-1,-2\), their joint image has ranks \((1,5,8,4)\) or \((0,2,6,4)\) according as \(a=0\) or \(a\ne0\). This is the image of the boundary from the punctured \(234\) line. The second map minus the first has ranks \((0,1,3,2)\) or \((0,0,2,2)\), respectively. Even setting \(J=0\) on this four-point configuration leaves the divisor \(t=1\). The independent spectator calculation above uses a different chart and order. The comparison with independent enhanced Stokes operations, and compatibility with further collision flags, remain open.