# Bar constructions and coherent operations

Bring three ordered fields \(a,b,c\) together on a curve. Colliding the first pair gives the bracketing \((ab)c\). Colliding the last pair gives \(a(bc)\). Once both product maps act on the same three-input complex and take values in the same output complex, how can we compare them? The [scalar collision residues](04-factorization.md#ch04-three-residues) distinguish the two orders on the same test function. The order \(12|3\) gives \(1\) and \(1|23\) gives \(0\). Regard these numbers as the values at \(1\) of two maps \(k\to k\), with the ground field \(k\) concentrated in degree zero. Their difference sends \(1\) to \(1\). There is no vector in degree \(-1\) whose differential could give that value.

For a comparison in which a solution exists, keep the source \(k\) and take a two-term complex as target. It has a vector \(u\) in degree \(-1\), a vector \(v\) in degree zero and differential \(du=v\). Thus \(u\) is a primitive of \(v\), a vector whose differential is \(v\). The maps \(1\mapsto v\) and \(1\mapsto0\) differ at \(1\) by \(v\). The map \(h\) given by \(1\mapsto u\) satisfies \(d(h(1))=v\). Since the source differential is zero, \(h\) is a homotopy from the zero map to the first map. For the two field products, such a primitive must depend trilinearly on \(a,b,c\). Its differential must also include the three input differentials.

Write \([a|b|c]\) for the three inputs in order, with a separator where a product can be taken. In an ordinary associative algebra concentrated in degree zero, the signed ways to erase one separator give \([ab|c]-[a|bc]\). Erasing the remaining separator gives \([(ab)c]-[a(bc)]=0\). For multiplication on a complex, the two bracketings can instead differ by a boundary. A three-input operation then supplies its primitive. With four inputs, three changes of bracketing along one path have the same endpoints as two changes along another. A four-input homotopy compares the two sums. On a curve the [consecutive cuts](04-factorization.md#ordered-cut-geometry) divide an ordered list of labels into blocks. At fixed arity \(n\), a word of nonempty blocks has length at most \(n\), since every block takes at least one label.

A square-zero generator gives a test on a second system. Let the probe states form a complex \(V\) with differential \(d\). Assign to a degree-zero letter \(\epsilon\) satisfying \(\epsilon^2=0\) a degree-zero operator \(T\) commuting with \(d\). Acting twice on the probe gives \(T^2\). To respect the relation through length two, assign to \([\epsilon|\epsilon]\) an operator \(H\) of degree \(-1\) with \(dH+Hd=T^2\). This is a primitive for \(T^2\) in the complex of probe operators. Splitting the word gives two copies of \([\epsilon]\), whose operators compose to \(T^2\). The homotopy compares that composite with zero. [A probe with a nonzero square and a chosen primitive](#ch05-twisting-cochain-probe)

## Cycles, boundaries and choices of primitives {#cohomology-and-parameters}

**Definition (cochain complex).** A cochain complex is a sequence of vector spaces and linear maps
\[
\cdots\longrightarrow V^{n-1}\xrightarrow{d}V^n
\xrightarrow{d}V^{n+1}\longrightarrow\cdots,
\qquad d^2=0.
\]
The integer \(n\) is the **cohomological degree**. The differential \(d\) raises it by one. A vector killed by \(d\) is a cycle, also called a closed vector. A boundary has the form \(dw\). Since \(d^2=0\), every boundary is a cycle. Dividing the cycles in degree \(n\) by the boundaries in that degree gives the cohomology group
\[
H^n(V)=\ker(d:V^n\to V^{n+1})/
\operatorname{im}(d:V^{n-1}\to V^n).
\]
In the two-term target above, \(v\) represents zero in cohomology because \(du=v\). More generally, suppose that \(v\in V^n\) and \(dw=v\). Every cycle \(z\in V^{n-1}\) gives another solution \(w+z\), and the difference of any two solutions is such a cycle. The cohomology class of \(v\) alone cannot specify its primitive.

Multiplying two letters of degrees \(|a|,|b|\) preserves their total degree. For erasing the separator in \([a|b]\) to have degree \(+1\), lower the degree of each letter by one. For a complex \(V\) this shift has the convention
\[
V[1]^n=V^{n+1},\qquad d_{V[1]}=-d_V.
\]
Thus a vector of degree \(r\) in \(V\) has degree \(r-1\) in \(V[1]\). Write \(sv\) for that shifted vector, so \(s\) has degree \(-1\). For a homogeneous map \(G\), applying \(1\otimes G\) to \(v\otimes w\) moves \(G\) past \(v\). Their degrees \(|G|\) and \(|v|\) give the Koszul sign \((-1)^{|G||v|}\). The differential on a tensor product acts on each factor in turn. The second action crosses \(v\), giving
\[
d(v\otimes w)=dv\otimes w+(-1)^{|v|}v\otimes dw .
\]

**Definition (cochain homotopy).** Let \(f,g:V\to W\) be degree-zero chain maps, so both commute with the differentials. A homotopy from \(g\) to \(f\) is a degree-minus-one map \(h:V\to W\) satisfying
\[
f-g=d_Wh+hd_V.
\]
For a closed input \(x\), the term \(hd_Vx\) vanishes, so \((f-g)x=d_W(hx)\). Thus homotopic maps induce the same map on cohomology. To keep the choice of \(h\), consider all homogeneous maps from \(V\) to \(W\). For an arbitrary map \(f\) of degree \(r\), the Hom differential \(\partial f\) has degree \(r+1\). Its formula is
\[
\operatorname{Hom}^r(V,W)=\prod_n\operatorname{Hom}(V^n,W^{n+r}),
\qquad
\partial f=d_Wf-(-1)^rfd_V.
\]
The product over \(n\) allows a component on every source degree, with no finite-support restriction. The degree-zero cycles are the chain maps. For \(h\) of degree \(-1\), its boundary is \(d_Wh+hd_V\), so a choice of homotopy specifies a primitive for \(f-g\).

Which replacements of a complex preserve its cohomology? A chain map is a **quasi-isomorphism** if it induces an isomorphism on every cohomology group. The ordinary **derived category** formally makes these maps invertible. For fixed endpoints, two homotopies differ by a cycle of degree \(-1\). A primitive of degree \(-2\), when it exists, compares those homotopies. Resolving the inputs as needed and retaining the resulting derived mapping complexes keeps these higher comparisons. This is the enhancement used in the [equivalence for consecutive cuts](#ch05-theorem-connected-consecutive-cut-duality).

::: example {#ch05-example-two-term-family title="A cohomology jump at zero"}
Let \(t\in\mathbb C\). Take a complex with basis \(u_1,u_2\) in degree zero and basis \(v_1,v_2\) in degree one. When can one remove the first pair without changing cohomology? The differential is
\[
\mathbb C u_1\oplus\mathbb C u_2
\xrightarrow{\ d_t\ }
\mathbb C v_1\oplus\mathbb C v_2,
\qquad d_tu_1=tv_1,\quad d_tu_2=0,
\]
{#eq-cohomology-jump}
For \(t\ne0\) the differential identifies the line spanned by \(u_1\) with the line spanned by \(v_1\). Its inverse from the \(v_1\) line to the \(u_1\) line is \(h(v_1)=t^{-1}u_1\). Extend \(h\) by zero on the other basis vectors. Let \(p\) project onto the remaining \(u_2,v_2\) summand and let \(i\) include it. Writing \(d=d_t\) and \(1\) for the identity of the full complex, we obtain
\[
dh+hd=1-ip.
\]
Indeed \(hd\) fixes \(u_1\), \(dh\) fixes \(v_1\), and both vanish on the retained pair. At \(t=0\) the equation \(dw=v_1\) has no solution. Both vectors in the first pair now represent new classes. The dimensions in degrees zero and one jump from \((1,1)\) to \((2,2)\), while their alternating sum, the Euler characteristic, stays zero. The pole in \(t^{-1}u_1\) prevents the contraction on the nonzero fibres from extending across zero.
:::

The diagram shows the zero fibre initially. There \(u_1\) and \(u_2\) both map to zero. At \(t=-1\) and \(t=1\), the first arrow instead sends \(u_1\) to \(-v_1\) and \(v_1\), respectively.

::: figure fig-cohomology-jump

## Relations can leave a higher operation {#ch05-relations-can-leave-a-higher-operation}

For \(t\ne0\), solving \(dw=v_1\) on the first summand gave \(w=t^{-1}u_1\). In the whole complex one may add any multiple of \(u_2\). What does this freedom to change a primitive do when the vector to be made exact is itself a product? We need a multiplication compatible with the differential.

**Definition (differential graded algebra).** A differential graded (dg) algebra is a graded associative algebra \(A\) with a differential of degree \(+1\) satisfying
\[
d(ab)=(da)b+(-1)^{|a|}a\,db.
\]
Its cohomology is an associative graded algebra. Passing to cohomology nevertheless loses information about how products become boundaries.

Can two zero products in \(H^*(A)\) leave a detectable ternary operation? Over \(k\), take the free associative graded algebra on five generators, with their degrees given by
\[
A=T(a,b,c,x,y),\qquad
|a|=|b|=|c|=|x|=|y|=1,
\]
Define the differential on its generators by
\[
da=db=dc=0,\qquad dx=ab,\qquad dy=bc.
\]
Extend \(d\) by the graded Leibniz rule. Since \(a,b,c\) are closed, \(d(ab)=d(bc)=0\). Thus \(d^2\) vanishes on all five generators and hence on \(A\). Write \([a]\) for the cohomology class of \(a\). The products \([a][b]\) and \([b][c]\) vanish because \(ab\) and \(bc\) have primitives \(x,y\). These choices give
\[
z=ay+xc,
\qquad
dz=-abc+abc=0.
\]
In the free algebra, distinct words of length two are independent. Every boundary in degree two is a linear combination of \(dx=ab\) and \(dy=bc\). Neither contains \(ay\) or \(xc\), so \(z\) represents a nonzero class. Could a different choice of primitives remove that class?

Replacing \(x,y\) by \(x+x_0,y+y_0\), where \(x_0,y_0\) are degree-one cycles, adds \(ay_0+x_0c\) to \(z\). The ambiguity in \([z]\) is the subspace
\([a]H^1(A)+H^1(A)[c]\) of \(H^2(A)\). Here \(H^1(A)\) is spanned by \([a],[b],[c]\), so no element of that subspace can remove the words \(ay\) and \(xc\). The nonzero coset of \([z]\) modulo this subspace is the **triple Massey product**. Its degree is \(1+1+1-1=2\), since each primitive lowers the product degree by one. Give the algebra \(H^*(A)\) itself zero differential. Its two adjacent products are already zero as elements, so choosing both primitives zero gives the zero coset there.

To transfer multiplication from a dg algebra \(A\) to a smaller complex \(H\), we again need a choice of primitive. This time it is a homotopy on all of \(A\). Let \(i:H\to A\) and \(p:A\to H\) be chain maps with \(pi=1\). Put \(P=ip\) and choose \(h:A\to A\) of degree \(-1\) with \(dh+hd=1-P\). For homogeneous \(a,b,c\in H\), write \(a'=ia\), \(b'=ib\), \(c'=ic\). The product on \(H\) is \(m_2(a,b)=p(a'b')\). To multiply this result by \(c\), one first sends it back to \(A\) by \(i\), which gives \(P(a'b')\). Thus the two bracketings in \(H\) are \(p(P(a'b')c')\) and \(p(a'P(b'c'))\).

To subtract the second from the first, write \(P=1-(1-P)\). The terms \(p((a'b')c')\) and \(p(a'(b'c'))\) cancel by associativity in \(A\), leaving
\[
 p\bigl(a'(1-P)(b'c')-(1-P)(a'b')c'\bigr).
\]
In the Hom complex \(\partial h=dh+hd=1-P\). Thus each occurrence of \(1-P\) has a specified primitive. In the first term apply \(1\otimes h\) to \(a'\otimes(b'c')\). Moving \(h\) across \(a'\) contributes \((-1)^{|a|}\). In the second term \(h\) acts on \(a'b'\) before the multiplication by \(c'\). The resulting trilinear map is
\[
 m_3(a,b,c)=p\bigl((-1)^{|a|}a'h(b'c')-h(a'b')c'\bigr).
\]
In \(\operatorname{Hom}(H^{\otimes3},H)\), taking the differential of \(m_3\) replaces \(h\) by \(dh+hd=1-P\) in both terms, since the product of \(A\) and the maps \(i,p\) commute with the differentials. Thus \(\partial m_3\) is the left bracketing minus the right. The [arity-three identity](#eq-ch05-associator-homotopy) expands this equality on all homogeneous inputs.

In the free algebra above, take \(H=H^*(A)\) and choose representatives \(a,b,c\) for the three classes. Choose the contracting homotopy with \(h(ab)=x\) and \(h(bc)=y\). Since \(|a|=1\), the formula for \(m_3\) gives \(-p(ay+xc)\) on those classes. It recovers the Massey coset with the sign fixed by this transfer convention.

## Recording successive products in a word {#ch05-words-and-the-reduced-bar-construction}

The two terms in the transferred \(m_3\) distinguish which pair was multiplied first. To record all such choices, keep the inputs in a word and let multiplying neighbours erase one separator. A word \([a|b]\) should have degree \(|a|+|b|-2\) if the one-letter answer \([ab]\) has degree \(|a|+|b|-1\). Lowering the degree of each letter by one gives exactly this convention. The empty word will carry a copy of the ground field. An augmentation singles out the part of the algebra from which to take the letters of a nonempty word.

**Definition (reduced bar construction).** An augmentation of a unital dg algebra is a dg algebra map \(\epsilon:A\to k\), where \(k\) is the ground field. It splits the underlying complex as
\(A=k\cdot1\oplus\bar A\), with \(\bar A=\ker\epsilon\). The **reduced bar construction**, including its empty word, is
\[
BA=T^c(\bar A[1])
=k\oplus\bigoplus_{n\ge1}(\bar A[1])^{\otimes n}.
\]
For a word of length \(n\), the degree sum runs over \(1\le i\le n\). In terms of the shift map \(s\),
\[
[a_1|\cdots|a_n]=sa_1\otimes\cdots\otimes sa_n,
\qquad
|[a_1|\cdots|a_n]|=\sum_i|a_i|-n.
\]
The superscript \(c\) indicates the tensor **coalgebra**. Its coproduct splits a word at every position, including the two ends.
\[
\Delta[a_1|\cdots|a_n]
=\sum_{i=0}^n[a_1|\cdots|a_i]
\otimes[a_{i+1}|\cdots|a_n].
\]
The empty word is \(1\), and sending the scalar \(1\) to this word gives the coaugmentation. Omitting the two end cuts of a nonempty word gives its reduced coproduct. This deconcatenation is coassociative because splitting at two positions gives the same three consecutive subwords in either order. For instance the reduced coproduct of \([a|b|c]\) has the two terms \([a]\otimes[b|c]\) and \([a|b]\otimes[c]\). It retains both places where the triple can be cut.

On the two-letter word \([a|b]\), the internal differential can act on either letter and the product can merge them into \([ab]\). Each contribution must raise the shifted degree by one. For a single letter the shift changes the sign of its differential. For a merger we use the signed product on the shifted factors. The two components are
\[
b_1(sa)=-s(da),\qquad
b_2(sa\otimes sb)=(-1)^{|a|}s(ab).
\]
Both maps have degree \(+1\) on the shifted letters. Inserting either map after \(sa_1,\ldots,sa_{i-1}\) therefore contributes the sign \((-1)^{\sum_{j<i}(|a_j|-1)}\). Including the signs of \(b_1,b_2\) themselves gives
\[
\begin{aligned}
b[a_1|\cdots|a_n]
={}&\sum_{i=1}^n
(-1)^{1+\sum_{j<i}(|a_j|-1)}
[a_1|\cdots|da_i|\cdots|a_n]\\
&+\sum_{i=1}^{n-1}
(-1)^{|a_i|+\sum_{j<i}(|a_j|-1)}
[a_1|\cdots|a_ia_{i+1}|\cdots|a_n].
\end{aligned}
\]
The equation \(b^2=0\) follows from \(d^2=0\), the Leibniz rule, and associativity. For an ordinary algebra concentrated in degree zero, the internal-differential terms vanish, and
\[
b[a|b]=[ab],\qquad
b[a|b|c]=[ab|c]-[a|bc].
\]
Applying \(b\) again to the three-letter word gives \([(ab)c]-[a(bc)]=0\). The signs on homogeneous inputs can be read from the two routes separately. On the left the signs multiply to \((-1)^{|a|+|ab|}=(-1)^{|b|}\). On the right the first merger, on the last two letters, crosses \(sa\), giving total sign \((-1)^{|a|-1+|b|+|a|}=-(-1)^{|b|}\). Thus the two mergers contribute \((-1)^{|b|}s((ab)c-a(bc))\). Mergers at disjoint pairs occur in opposite orders with opposite signs. Two internal differentials cancel or square to zero, and the mixed terms on a multiplying pair cancel by the Leibniz rule. These exhaust the terms in \(b^2\). [Loday–Vallette, *Algebraic Operads*, §§2.2–2.3](https://www.math.univ-paris13.fr/~vallette/Operads.pdf#page=51)

What happens to the two-letter word on a single degree-zero generator when its square vanishes? For an ordinary augmented algebra \(A\), its free bar resolution of \(k\) has terms \(A\otimes BA\). The differential also multiplies the leading \(A\)-factor by the first letter. Tensoring this resolution over \(A\) with \(k\) leaves \(BA\), since the letters lie in the augmentation ideal. For \(A=k[x]\), augmented by \(x\mapsto0\), there is a shorter free resolution
\[
0\longrightarrow A\xrightarrow{\,x\,}A\longrightarrow k\longrightarrow0
\]
of the same \(A\)-module \(k\). Tensoring over \(A\) with \(k\) kills multiplication by \(x\), so the two resolutions compute
\[
H^*(BA)=k\oplus k\cdot[x],\qquad |[x]|=-1.
\]
This calculation has a visible trace on words. For instance \(b[x|x]=[x^2]\), so the one-letter class represented by \(x^2\) is zero. For \(m\ge2\), \(b[x|x^{m-1}]=[x^m]\) does the same for every higher power. If we impose \(x^2=0\) in the algebra, then \([x|x]\) becomes a cycle. Can a longer word have it as its boundary?

For \(A=k[\epsilon]/(\epsilon^2)\), the augmentation ideal is one-dimensional and its product is zero. Thus the bar differential vanishes in every length.
\[
BA=\bigoplus_{n\ge0}k[\epsilon|\cdots|\epsilon],
\qquad H^{-n}(BA)=k\quad(n\ge0).
\]
The corresponding free resolution has multiplication by \(\epsilon\) at every step. It is exact before tensoring with \(k\), and every differential becomes zero afterwards. Thus the single relation \(\epsilon^2=0\) produces homological information in arbitrarily long words. These groups are traditionally denoted \(\operatorname{Tor}_n^A(k,k)\), with \(n=-\text{cohomological degree}\).

## One differential encodes all associativity homotopies {#ch05-one-differential-encodes-all-associativity-homotopies}

On three inputs the two binary mergers produce the difference of bracketings. To include its primitive \(m_3\) in the same word differential, allow a third component to replace \([a|b|c]\) by a single letter. On \([x|a|b|c]\), cutting after \(x\) before this replacement must leave the same right-hand operation on \([a|b|c]\), with the sign for passing \(sx\). Every cut outside a substituted string imposes such a condition. Deconcatenation expresses this requirement.

**Definition (coderivation).** Let \(V\) be a graded vector space. A degree-one map \(b\) on \(T^c(V[1])\) is a coderivation if
\[
\Delta b=(b\otimes1+1\otimes b)\Delta,
\]
with the graded tensor convention. For a coderivation vanishing on the empty word, project its value on words of length \(n\) to the one-letter summand. The resulting maps are
\[
b_n:(V[1])^{\otimes n}\longrightarrow V[1],
\]
with \(n\ge1\). They determine \(b\) by inserting \(b_n\) at every consecutive string of \(n\) letters, with the sign for passing its prefix. Only finitely many insertions occur on a finite word.

**Definition (uncurved \(A_\infty\)-algebra).** Such a structure on \(V\) is a degree-one coderivation \(b\) vanishing on the empty word and satisfying \(b^2=0\). Vanishing on the empty word is the condition \(m_0=0\) on the zero-input operation. Use \(b_n=-s\,m_n(s^{-1})^{\otimes n}\), with graded tensor products. Thus \(m_n:V^{\otimes n}\to V\) has degree \(2-n\). For \(m_1=d\) and \(ab=m_2(a,b)\) this gives the preceding \(b_1,b_2\), and
\[
 b_3(sa\otimes sb\otimes sc)=(-1)^{|b|}s\,m_3(a,b,c).
\]

In length one, \(b^2=0\) gives \(d^2=0\). In length two it says that \(m_2\) is a chain map. In length three, project \(b^2[a|b|c]\) onto one letter. The two binary mergers contribute \((-1)^{|b|}s((ab)c-a(bc))\). The terms inserting \(b_1\) before or after \(b_3\) contribute \(-(-1)^{|b|}s(\partial m_3)(a,b,c)\), where \(\partial\) is the [Hom differential](#cohomology-and-parameters). Cancelling the common factor gives the associator on homogeneous inputs,
\[
\begin{aligned}
 &(ab)c-a(bc)\\
 &\quad=d\,m_3(a,b,c)+m_3(da,b,c)\\
 &\qquad+(-1)^{|a|}m_3(a,db,c)\\
 &\qquad+(-1)^{|a|+|b|}m_3(a,b,dc).
\end{aligned}
\]
{#eq-ch05-associator-homotopy}
The difference of bracketings has degree zero, so its primitive \(m_3\) has degree \(-1\). If \(a,b,c\) are closed, only \(d\,m_3(a,b,c)\) remains on the right. Consequently the induced product on cohomology is associative. A higher operation can nevertheless carry information there. In the [free dg algebra](#ch05-relations-can-leave-a-higher-operation) the original multiplication is already strictly associative. The nonzero Massey coset measures the effect of choosing primitives for the vanishing products \(ab\) and \(bc\) when the multiplication is transferred.

In length \(n\), count \(r\) letters before an insertion, \(s\ge1\) inputs to the inserted operation and \(t\) letters after it. Here \(s\) counts letters and \(1\) denotes the identity of the shifted space. The one-letter component of \(b^2\) gives
\[
 \sum_{\substack{r+s+t=n\\s\ge1}}
 b_{r+1+t}(1^{\otimes r}\otimes b_s\otimes1^{\otimes t})=0 .
\]
For any summand the inner map crosses \(r\) shifted letters. In length four, the terms with inner and outer arities \(2,3\) or \(3,2\) compare five bracketings of the four inputs. They form the five edges of a pentagon. For closed degree-zero \(a,b,c,e\), the equation takes the form
\[
\begin{aligned}
 &d\,m_4(a,b,c,e)\\
 &\quad=a\,m_3(b,c,e)-m_3(ab,c,e)\\
 &\qquad+m_3(a,bc,e)-m_3(a,b,ce)\\
 &\qquad+m_3(a,b,c)\,e .
\end{aligned}
\]
To read the five signs, start at \(((ab)c)e\) and end at \(a(b(ce))\). One path passes first through \((a(bc))e\) and then through \(a((bc)e)\). Its three homotopies are \(m_3(a,b,c)e\), \(m_3(a,bc,e)\) and \(a\,m_3(b,c,e)\). The other path passes through \((ab)(ce)\) and uses \(m_3(ab,c,e)\) and \(m_3(a,b,ce)\). Each path has the same differential, the difference of the endpoint products. Their difference is a cycle of degree \(-1\), and the displayed equation specifies its primitive \(m_4\) of degree \(-2\). In higher arities the same equation \(b^2=0\) gives the successive comparisons. **Coherence** consists of these operations and identities on the complex.

### Where a scalar output goes in the reduced bar {#ch05-scalar-bar-curvature}

The letters of the reduced bar of an augmented algebra belong to its augmentation ideal. Their product stays in that ideal. What changes if we can project onto the unit line only as a vector space? In \(A=M_2(k)\) over a characteristic-zero field let \(p(a)=\operatorname{tr}(a)/2\). For traceless matrices write \(a*b=ab-p(ab)1\) for the traceless part of their product. Put \(e=E_{12}\), \(f=E_{21}\) and \(h=E_{11}-E_{22}\), where \(E_{ij}\) are the matrix units. Then \(ef=(1+h)/2\), \(fh=f\) and \(h^2=1\). If we use only the traceless products in the bar differential \(\bar b\), its square on three letters is
\[
 \bar b^2[e|f|h]
 =[(e*f)*h]-[e*(f*h)]
 =0-\tfrac12[h].
\]
The missing contribution came from the scalar \(p(ef)=1/2\), which multiplies \(h\) at the next step. Indeed, on any three traceless matrices the projected associator is \(p(bc)a-p(ab)c\).

The scalar part of the matrix product contributes to the next multiplication through the unit. More generally, in a strictly unital uncurved \(A_\infty\)-algebra the unit is closed, \(m_1(1)=0\), acts by the binary unit law, and makes every product of arity greater than two vanish when it occurs as an input. Choose a graded linear map \(p:A\to k\) with \(p(1)=1\), and write \(\bar A=\ker p\). This complement need not be an ideal. On \(T^c(\bar A[1])\), project each \(b_n\) to the shifted complement to obtain the coderivation \(\bar b\). Keep the omitted scalar as the degree-two functional
\[
 \theta([a_1|\cdots|a_n])
   =-p\bigl(s^{-1}b_n(sa_1\otimes\cdots\otimes sa_n)\bigr),
 \qquad \theta(\text{empty word})=0 .
\]
In the one-letter component of \(b^2=0\), an intermediate scalar can return to the complement only by multiplying the remaining letter. A scalar from the left subword gives \((\theta\otimes1)\Delta\) in the projected square, and one from the right gives \(-(1\otimes\theta)\Delta\). The opposite signs come from the two shifted unit products with the sign in the definition of \(\theta\). Projecting onto the scalar line gives \(\theta\bar b=0\). Thus the curved bar identities are
\[
 \bar b^2=(\theta\otimes1-1\otimes\theta)\Delta,
 \qquad \theta\bar b=0 .
\]
{#eq-ch05-reduced-bar-curvature}
Here \(k\otimes T^c(\bar A[1])\) and \(T^c(\bar A[1])\otimes k\) are identified with the word space. In the matrix example \(\theta([e|f])=-1/2\) and \(\theta([f|h])=0\), which gives the computed square. The functional \(\theta\) is the **curvature of the reduced bar coalgebra**. [Burke, Corollary 4.11 and Definition 4.12](https://arxiv.org/pdf/1801.06943#page=17)

For a boundary interaction, the scalar can distinguish two potentials that give the same ordinary multiplication. In one variable, a two-periodic matrix factorisation is a finite free module graded by parity with an odd operator \(Q\) whose square is multiplication by the potential \(W\). Take \(W=x^3\) or \(W=x^4\). The marked minimal boundary algebra has unit \(1\) and an odd class \(\psi\). In both cases \(m_0=0\), \(m_1=0\) and \(m_2(\psi,\psi)=0\). With \(t\) the [boundary coordinate of Chapter 19](19-interacting-theories.md#ch19-boundary-potential), the scalar error in the square of the deformed operator is \(-W(-t)\,1\). Thus the cubic gives \(m_3(\psi,\psi,\psi)=1\) and the quartic gives \(m_4(\psi,\psi,\psi,\psi)=-1\). The remaining products on nonempty words of \(\psi\)'s vanish.

Take \(p(\psi)=0\). Since \(s\psi\) has even parity, the sign in \(b_n=-s\,m_n(s^{-1})^{\otimes n}\) gives \(\theta([\psi|\cdots|\psi])\) equal to the scalar value of \(m_n\). Thus \(\bar b=0\) in both examples. If the coefficient of \(t^n\) records the curvature on the word of length \(n\), the two series are \(t^3\) and \(-t^4\), respectively.

On the generator \(t\) of \(k[t]/(t^4)\), the cubic has nonzero obstruction \(t^3\,1\), while the quartic gives zero. On the generator of \(k[t]/(t^5)\) the quartic gives \(-t^4\,1\ne0\). For an even parameter \(r\) in the maximal ideal of a local Artin base, the two obstructions have values \(r^3\,1\) and \(-r^4\,1\). The marked boundary is flat at a parameter exactly when its scalar obstruction vanishes there. The obstruction records an operation with three or four inputs in the undeformed algebra, whose zero-input operation vanishes. [The boundary deformation with square \(W(x)-W(-t)\)](19-interacting-theories.md#ch19-boundary-potential)

::: example {#ch05-two-marked-artin-parameters title="Two parameters with the same tangent class"}
Take \(S=\mathbb Q[u,v]/(u^3,v^3)\) with maximal ideal \(\mathfrak m=(u,v)\). The parameters \(r=u\) and \(r'=u+v^2\) have the same first-order parameter. Their common class is nonzero in \(\mathfrak m/\mathfrak m^2\). Both fourth powers vanish, but their cubes are
\[
 r^3=0,\qquad (r')^3=3u^2v^2\ne0 .
\]
Indeed the monomials \(u^a v^b\) with \(0\le a,b<3\) form a basis of \(S\). The cubic boundary is flat at \(r\) and has scalar obstruction \(3u^2v^2\,1\) at \(r'\). The quartic boundary is flat at both marked parameters.
:::

## Recovering products by the cobar construction {#ch05-cobar-reverses-the-construction}

Return to an augmented algebra. For closed degree-zero \(a,b\) in the augmentation ideal, the bar differential gives \(b[a|b]=[ab]\). To recover multiplication from this coalgebra, we need a differential whose boundary identifies the formal product of the two one-letter generators with the generator for \(ab\). The old word \([a|b]\) supplies both terms of that boundary. Its bar differential supplies \([ab]\), and cutting it supplies \([a]\otimes[b]\).

Deconcatenation on \([a|b|c]\) produces at most three nonempty factors. More generally, let \(C=k\oplus\bar C\) be a counital coaugmented dg coalgebra. Its coaugmentation \(k\to C\) followed by its counit \(C\to k\) is the identity of \(k\), and its coproduct commutes with the differential \(d_C\) for the tensor differential. Write \(1\) for the image of \(1\in k\) and \(\bar C\) for the kernel of the counit. On \(c\in\bar C\), remove \(1\otimes c+c\otimes1\) from \(\Delta c\) to obtain the reduced coproduct \(\bar\Delta c\). The coalgebra is **conilpotent** if sufficiently many iterated reduced coproducts kill each element. The three-letter bound illustrates this for the tensor coalgebra.

**Definition (cobar construction).** The cobar construction is the tensor algebra
\[
\Omega C=T(\bar C[-1]).
\]
Write \(uc\) for a generator in \(\bar C[-1]\), so \(|uc|=|c|+1\). If \(\bar\Delta c=\sum c'\otimes c''\), its differential is the derivation determined by
\[
d_\Omega(uc)=-u(d_Cc)
+\sum(-1)^{|c'|+1}(uc')(uc'').
\]
Squaring this derivation on a generator gives three types of terms. The internal square vanishes by \(d_C^2=0\). The two orders of making two cuts agree by coassociativity and have opposite signs. The mixed terms cancel because the coproduct commutes with the differential. To see the two signs on one cut, take closed degree-zero elements \(a,b\) of the augmentation ideal. The shifted element \([a]\) has degree \(-1\), so its cut contributes \((-1)^{-1+1}=1\). Closedness kills both internal differential terms in \(b[a|b]\). The cobar differential on the generator \(u[a|b]\) is therefore
\[
d_\Omega u[a|b]=-u[ab]+(u[a])(u[b]).
\]
Sending \(u[a]\) to \(a\) and longer single generators to zero takes the displayed boundary to \(-ab+ab=0\). This is the strict counit \(\Omega BA\to A\) on the first multiplication relation. For a coalgebra \(C\), the same check on every generator \(uc\) determines when an assignment of elements of \(A\) extends to a chain map.

::: example {#ch05-binary-cobar-channels title="Two separated lines and two ways to split them"}
Take two labelled straight Wilson lines, probes of parallel transport for a gauge field. Let both run in the \(s\)-direction in \(\mathbb R_s\times\mathbb R_t\times X\), where \(X\) is a complex curve. Fix distinct spectral positions \(z_1,z_2\in X\). Move the transverse heights \(t_1,t_2\) past one another. Even at equal heights the lines are disjoint. If the inputs are prepared by concatenating consecutive blocks of the word \(12\), their only positive split is \(1|2\). If either labelled subconfiguration can be the first input to disjoint union, there is a second split, \(2|1\), at the very same positions. The [order charts](04-factorization.md#ordered-cut-geometry) agree there. Which difference can the cobar detect?

Suppose a coalgebra \(C\) assigns a complex to each labelled configuration and a coproduct map to each admissible split. On the open \(U=\{(z_1,z_2)\in X^2:z_1\ne z_2\}\), write \(V=C_{\{1,2\}}|_U\) for the coefficient before either cobar shift. Indeed the binary cobar differential uses a map from the uncut coefficient to the sum over the retained splits. Assume that each component identifies \(V\) with the ordered external product of the two singleton coefficients on \(U\). Take the reduced coefficient at the empty configuration to be zero. Normalisation then removes every term with an empty block. One block then contributes a copy of \(V\) in degree one relative to \(V\), and each two-block term contributes a copy in degree two. Three nonempty blocks would require a third label. For a map \(f\) of unshifted coefficients, these two degrees give \(\operatorname{fib}(f)[-1]\), since the homotopy fibre is the mapping cone shifted by \([-1]\). Using the component maps themselves as coordinates, the two possible complexes are
\[
\begin{aligned}
1|2:\quad &\operatorname{fib}\bigl(V\xrightarrow{1}V\bigr)[-1]\simeq0,\\
1|2,\ 2|1:\quad
 &\operatorname{fib}\bigl(V\xrightarrow{(1,1)}V\oplus V\bigr)[-1]
 \simeq V[-2].
\end{aligned}
\]
For example, take \(C=BA\) with these coproduct equivalences, where \(A\) is an augmented algebra for all ordered decompositions and its augmentation identifies the empty coefficient with \(k\). The second line then computes \(\overline A_{\{1,2\}}|_U\), where \(\overline A\) denotes the augmentation ideal. The quotient map is \((a,b)\mapsto b-a\). For \(V=k\) in degree zero, the coefficient \(1\) in the second channel alone reads \(+1\) in this quotient. Putting \(1\) in both channels reads zero. Equivalently, in a common tensor order use the first component to identify the source with the singleton product and write the other component as \(R\). The map is then \(x\mapsto(x,Rx)\). The map \((x,y)\mapsto y-Rx\) identifies its cofibre with \(V\).

Restricting the full cobar to the \(12\) chart retains both summands. Projecting the coproduct to consecutive cuts *before* taking the cobar removes the second summand. Thus restricting \(\Omega_{\rm full}C\) to a chart and forming \(\Omega_{\rm cut}\) of the projected coalgebra give different coefficients whenever \(V\ne0\) in the derived category. This calculation takes place entirely on \(U\). A sphere linking two colliding lines instead varies their relative height and spectral position around the collision. [The two convolution products](12-chiral-quantum-groups.md#ch12-associative-products-on-configurations)
:::

**Definition (twisting cochain).** A degree-one map \(\tau:C\to A\), vanishing on the coaugmentation and landing in \(\bar A\), is a twisting cochain when it satisfies the following equation, with \(\mu_A\) the multiplication of \(A\).
\[
d_A\tau+\tau d_C+\mu_A(\tau\otimes\tau)\bar\Delta=0.
\]
Here \((\tau\otimes\tau)(c'\otimes c'')=(-1)^{|c'|}\tau(c')\otimes\tau(c'')\). This one equation says exactly that \(uc\mapsto\tau(c)\) extends to a dg algebra map \(\Omega C\to A\). For conilpotent \(C\), the one-letter component of the corresponding dg coalgebra map \(C\to BA\) is \(s\tau(c)\) on \(c\in\bar C\). Its longer components apply \(s\tau\) to each factor of the iterated reduced coproduct. Taking algebra maps that preserve the augmentation and counital coalgebra maps that preserve the coaugmentation gives the strict bar–cobar adjunction
\[
\operatorname{Hom}_{\rm dgAlg}(\Omega C,A)
\cong\operatorname{Tw}(C,A)
\cong\operatorname{Hom}_{\rm dgCoalg}(C,BA).
\]
The identities correspond to the strict counit \(\Omega BA\to A\) just tested on \(u[a|b]\), and the strict unit \(C\to B\Omega C\). In the latter map a one-letter component records \(c\) and the longer components record its successive reduced coproducts. Conilpotence makes the word sum finite on each element. An adjunction alone gives no inverse to either comparison.

::: example {#ch05-primitive-and-augmentation title="A primitive generator tests the augmentation"}
Let \(C=k1\oplus kc\) with zero differential and \(c\) of degree \(-1\) with \(\bar\Delta c=0\). An element with this reduced coproduct is called primitive. Then \(X=uc\) has degree zero and \(d_\Omega X=0\). Thus \(\Omega C=k[X]\), with augmentation \(X\mapsto0\). Take \(A=k\) with its identity augmentation. Evaluation at \(X=1\) gives a unital dg algebra map. A reduced twisting cochain takes \(c\) into \(\ker(k\to k)=0\), so its map must send \(X\) to zero. This is the unique augmentation-preserving evaluation. On the coalgebra side \(Bk=k\), and the corresponding map is the counit of \(C\).
:::

### Coupling a square-zero letter to a probe {#ch05-twisting-cochain-probe}

For the square-zero letter \(\epsilon\), take the subcoalgebra \(C\subset B(k[\epsilon]/(\epsilon^2))\) spanned by the empty word, \(e=[\epsilon]\) and \(f=[\epsilon|\epsilon]\). Their degrees are \(0,-1,-2\). The differential is zero and the only nonzero reduced coproduct is \(\bar\Delta f=e\otimes e\). Fix a probe complex \(V\) and let \(D=\operatorname{End}_k(V)\), with composition and the Hom differential \(\partial\). A unital map to \(D\) may give the generators arbitrary images. To express it by a reduced twisting cochain, adjoin a scalar unit to \(D\), obtaining \(k\oplus D\) with augmentation ideal \(D\). A unital map \(F\) from \(\Omega C\) to \(D\) gives the augmented map \(\lambda1+w\mapsto(\lambda,F(w))\) for \(w\) in the augmentation ideal. Conversely \((\lambda,x)\mapsto\lambda1_D+x\) recovers \(F\).

A twisting cochain assigns \(T=\tau(e)\in D^0\) and \(H=\tau(f)\in D^{-1}\). The tensor sign for applying the second \(\tau\) past \(e\) is \((-1)^{-1}=-1\). Its two equations are therefore
\[
 \partial T=0,\qquad \partial H=T^2 .
\]
The cobar algebra has free generators \(X=ue\) and \(Y=uf\), with \(dX=0,\ dY=X^2\). A choice of \(T,H\) extends to a dg algebra map precisely when these two equations hold. Changing the probe operator algebra by a dg algebra map carries both assignments to their images. This is the sense in which \(\Omega C\) represents the coupling problem for this coalgebra. [Loday–Vallette, Theorem 2.2.9](https://www.math.univ-paris13.fr/~vallette/Operads.pdf#page=54) · [Paquette and Williams, §5.2](https://arxiv.org/pdf/2110.10257v4#page=23)

If \(V\) is concentrated in degree zero, the second equation requires \(T^2=0\). On two states the matrix \(E_{12}\) meets this condition and the identity does not. Take instead the complex \(kv\xrightarrow{\,d\,}kw\) in degrees \(-1,0\), with \(dv=w\). Choose \(T=1_V,\ H(w)=v,\ H(v)=0\). Then \((dH+Hd)v=v\) and \((dH+Hd)w=w\). The identity now gives a coupling through length two, with the nonzero composite accounted for by \(H\). A larger coalgebra can impose equations on longer words. For ordered configurations the number of labels bounds every word in each arity.

## Ordered cuts give a finite geometric bar construction {#ch05-ordered-cuts-give-a-finite-geometric-bar-construction}

An ordered word of two positions becomes a word of three by repeating its first position, \((x,y)\mapsto(x,x,y)\). A coefficient on three positions must give back the two-position coefficient when pulled back along that diagonal. Repeating several positions in stages imposes compatibility on these identifications.

**Definition (word coefficient system).** Let \(X\) be a smooth separated finite-type curve over a characteristic-zero field \(k\). Write \(\mathcal D(X^n)\) for the unbounded derived category of right algebraic differential modules with quasi-coherent underlying modules, retaining its higher mapping spaces. Write \([n]=\{1,\ldots,n\}\) with its given order. A word coefficient system consists of complexes \(M_n\in\mathcal D(X^n)\) for \(n\ge1\), together with coherent equivalences
\[
d_\alpha^!M_n\simeq M_m
\qquad
\bigl(\alpha:[n]\twoheadrightarrow[m]\text{ monotone}\bigr),
\]
where \(d_\alpha(x)_i=x_{\alpha(i)}\). Here \(d_\alpha^!\) is extraordinary derived pullback. The equivalences include their compatibilities under composition and all higher homotopies. Add an isolated empty coefficient \(M_0\in D(k)\), the derived category of complexes of \(k\)-vector spaces, with no collision arrow from a nonempty configuration to it. Denote the category of these coefficient systems by \(\mathcal W_X\). The arity \(n\) counts labels.

For \(p+q=n\), let \(U_{p,q}\subset X^n\) be the open set on which every point in the first block is distinct from every point in the second. There is no separation condition within either block. With \(j_{p,q}:U_{p,q}\hookrightarrow X^n\), define consecutive-cut convolution by
\[
(M\star N)_n=
\bigoplus_{p+q=n}Rj_{p,q*}j_{p,q}^*
(M_p\boxtimes^{\mathbf L}N_q).
\]
Here \(\boxtimes^{\mathbf L}\) is the derived external tensor product. Restriction keeps the two blocks apart, and \(Rj_{p,q*}\) extends that coefficient to \(X^n\). For three nonempty blocks, first separating the first from the second and then both from the third inverts every difference between distinct blocks. Separating the last two first inverts the same differences. Each bracketing is therefore the derived direct image of the same threefold external product from that common open. An empty block contributes a complex over \(k\). [The two cut opens for three labels](04-factorization.md#ordered-cut-geometry)

The unit is \(\mathbf1=(k,0,0,\ldots)\). An augmented algebra is **connected in arity** if its augmentation identifies \(A_0\) with \(k\). A counital coaugmented coalgebra has the analogous condition \(C_0\simeq k\). This condition allows arbitrary cohomological degrees. The augmentation ideal \(\bar A\) and the coaugmentation coideal \(\bar C\) (the kernel of the counit) both vanish on the empty word. The convolution of such objects has the bound
\[
(M^1\star\cdots\star M^r)_n=0
\quad\text{if all }M^i_0=0\text{ and }r>n.
\]
Every nonzero term assigns at least one point to each factor. At \(n=3\) the possibilities with two positive factors have arities \((1,2)\) and \((2,1)\). With three they have arities \((1,1,1)\), and with four the sum is empty.

**Theorem: connected consecutive-cut duality.** In \(\mathcal W_X\), bar and cobar for consecutive-cut convolution are inverse equivalences between connected augmented coherent associative algebras and connected counital coaugmented coherent coassociative coalgebras. The equivalence includes their full mapping spaces. It requires no cohomological boundedness or finite-dimensionality of coefficients.

::: proof {#ch05-proof-connected-consecutive-cut-duality}
The bar and cobar functors act on maps and on their higher homotopies. For strict dg inputs their normalised models have the word differentials above. To see what remains in length \(r\), split the augmentation and coaugmentation. In the simplicial bar, quotienting by the images of the unit insertions removes every word containing a unit. In the cosimplicial cobar, taking the common fibre of the projections that apply the counit to one factor retains just the words in the coaugmentation coideal. The resulting layers are
\[
\bar A^{\star r}[r],\qquad \bar C^{\star r}[-r].
\]
In arity \(n\), they vanish for \(r>n\). Thus bar and cobar stabilise after finitely many normalised stages in each coefficient. No interchange of an arbitrary infinite tensor product with an inverse limit is needed.

The underlying filtered associative duality is developed by Matsuoka, [*Koszul duality between \(E_n\)-algebras and coalgebras in a filtered category*, Lemmas 4.13 and 4.17](https://arxiv.org/html/1409.6943v4). For intrinsic bar and cobar see Lurie, [*Higher Algebra*, §5.2.2](https://www.math.ias.edu/~lurie/papers/HA.pdf#page=821).

In the cobar of the bar of \(A\), filter a word of words by the number of original letters from \(\bar A\). The multiplication of adjacent letters lowers that number. In the bar of the cobar of \(C\), use the reverse filtration on the number of original letters from \(\bar C\), since the reduced coproduct increases it. On either associated graded fix the flattened list of \(r\) positive letters. For \(r=2\) there are two copies of the same coefficient. The gap lies inside a word or separates two words. The differential changes that assignment by the identity up to sign, in the reverse direction for the second composite. The two copies therefore form a contractible complex.

With three letters, record the two gap assignments by \(00,10,01,11\). Here \(0\) marks a gap inside a word and \(1\) a separator between words. The four copies form a square. Changing the first gap pairs \(00\) with \(10\) and \(01\) with \(11\). The opposite incidence signs around the square make this contraction compatible with changing the second gap.

For \(r>1\) there are \(r-1\) gaps. Pair each assignment with the one that differs only at the first gap. Every other change belongs to a square of the same kind, so the contraction works on the whole cube. Only the empty coefficient \(k\) and the one-letter coefficient survive. On the associated graded, the unit \(A\to\Omega BA\) sends the weight-one part \(\bar A\) to its surviving one-letter copy. The counit \(B\Omega C\to C\) takes the surviving one-letter copy of \(\bar C\) to \(\bar C\). Both are the identity on the empty summand. In arity \(n\) the filtrations have only finitely many nonzero layers. These comparisons are therefore equivalences on the original coefficients.
:::

For strict dg representatives the twisting-cochain adjunction is \(\Omega_{\rm dg}\dashv B_{\rm dg}\). Its arrows are \(\Omega BA\to A\) and \(C\to B\Omega C\). The intrinsic connected equivalence also has the adjunction \(B\dashv\Omega\), with maps \(A\to\Omega BA\) and \(B\Omega C\to C\). The two presentations give the same equivalences after inverting quasi-isomorphisms. The canonical chain maps just listed run in opposite directions.

In the diagram, \(B\) and \(\Omega\) are the two functors. The contracting square is the square of gap assignments above. The support formula applies when \(C\) *factorises* across a cut, meaning that its coproduct on the separating open identifies its coefficient with the external product of the two blocks, for every cut. Write \(Z_n\) for the locus where all cuts fail and \(R\Gamma_{Z_n}\) for derived sections with support there. In this case the positive cobar coefficient is \(R\Gamma_{Z_n}(C_n)[-1]\), as the [support theorem](#ch05-support-theorem) shows.

::: figure fig-connected-bar-cobar

### Lifting through a square-zero ideal {#ch05-relative-lifting}

Suppose a multiplication is known modulo an ideal \(J\) with \(J^2=0\). Choose lifts of \(a,b\) and of their product. The difference between multiplying the lifts and lifting the product lies in \(J\). Can we remove this difference while keeping a given action on states? The first obstruction can already be calculated for ordinary algebras.

Let \(k\) be a field of arbitrary characteristic. Fix unital algebra maps \(f:A\to B\) and \(\alpha:A\to C\). Let \(q:B'\twoheadrightarrow B\) be a unital algebra surjection with square-zero kernel \(J\). The prescribed action is recorded by a unital algebra map \(\rho:B'\to C\). Assume that there is a unital linear lift \(s:A\to B'\) with \(qs=f\) and \(\rho s=\alpha\). The multiplicative defect \(D(a,b)=s(a)s(b)-s(ab)\) maps to zero under both \(q\) and \(\rho\), so it takes values in \(I=J\cap\ker\rho\).

For \(u\in I\), set \(a\cdot u=s(a)u\) and \(u\cdot a=us(a)\). Both products lie in \(I\). Since \(D(a,b)\) and \(u\) belong to \(J\), we have \(D(a,b)u=uD(a,b)=0\). Thus each action respects multiplication in \(A\), and associativity in \(B^{\prime}\) makes the two actions commute. This gives \(I\) an \(A\)-bimodule structure. Changing \(s(a)\) by an element of \(J\) leaves these actions unchanged.

A normalised Hochschild cochain with values in \(I\) is a multilinear map from copies of \(A\) to \(I\) that vanishes when any input is \(1\). The defect \(D\) is such a cochain on two inputs.

::: proposition {#ch05-square-zero-lift title="A lift preserving a prescribed action"}
The defect \(D\) is a cocycle. A unital algebra lift preserving both prescribed maps exists precisely when its class \([D]\) vanishes in the second Hochschild cohomology \(HH^2(A,I)\).
:::

::: proof {#ch05-proof-square-zero-lift}
Expand \((s(a)s(b))s(c)\) and \(s(a)(s(b)s(c))\), using \(s(a)s(b)=s(ab)+D(a,b)\). The first gives \(s(abc)+D(ab,c)+D(a,b)c\), and the second gives \(s(abc)+D(a,bc)+aD(b,c)\). Their equality is the Hochschild cocycle equation
\[
 aD(b,c)-D(ab,c)+D(a,bc)-D(a,b)c=0.
\]
Adding a linear map \(t:A\to I\) with \(t(1)=0\) preserves both constraints on \(s\), and every other unital linear lift of the two maps arises this way. Its defect changes by \(at(b)-t(ab)+t(a)b\). These changes are exactly the coboundaries in degree two. Thus \(D\) can be cancelled precisely when its class in the quotient of normalised cocycles by coboundaries vanishes.
:::

A linear residue functional on the space of cocycles gives the same value for every choice of lift exactly when it vanishes on every coboundary. This is the condition for the functional to descend to \(HH^2(A,I)\).

For a truncated polynomial algebra a characteristic polynomial tests every change of generator at once.

::: proposition {#ch05-truncated-polynomial-lift title="Lifting a truncated polynomial generator"}
Let \(R=k[h]/(h^n)\), \(n\ge1\), and let \(G(T)\) be monic of degree \(m\ge2\) with \(G(T)\equiv T^m\bmod h\). A unital \(R\)-algebra map
\[
 R[X]/(X^m)\longrightarrow R[x]/(G(x))
\]
reducing to \(X\mapsto x\) exists exactly when \(G(T)=(T-c)^m\) for some \(c\in hR\).
:::

::: proof {#ch05-proof-truncated-polynomial-lift}
For necessity, use \(1,X,\ldots,X^{m-1}\) and \(1,x,\ldots,x^{m-1}\) as bases over \(R\). The matrix of such a map reduces to the identity modulo \(h\), hence is invertible. Multiplication by \(x\) on the target has characteristic polynomial \(G\). Transport \(x\) to the source and call its constant coefficient \(c\), necessarily in \(hR\). On each successive quotient \((X^i)/(X^{i+1})\) it acts by \(c\), giving characteristic polynomial \((T-c)^m\). Conversely, when \(G=(T-c)^m\), the choice \(X\mapsto x-c\) gives a lift.
:::

For instance, take \(m=2\) and \(G(T)=T^2-hT\) over \(\mathbb Q\). The linear coefficient forces \(c=h/2\). The constant term of \((T-c)^2\) is \(h^2/4\), so the lift works modulo \(h^2\) and fails modulo \(h^3\) for *every* possible change of generator.

More generally let \(G(T)=T^m-h^sT^{m-1}\), with \(s\ge1\). Comparing the coefficient of \(T^{m-1}\) gives \(mc=h^s\). If the characteristic divides \(m\), the left side vanishes. Modulo \(h^n\) the right side is zero for \(n\le s\) and first becomes nonzero modulo \(h^{s+1}\). If \(m\) is invertible, let \(e\) be the first \(j\ge2\) with \(\binom mj\ne0\) in \(k\). All the remaining coefficients agree precisely when \(h^{se}=0\). In characteristic zero \(e=2\). In characteristic two with \(m=5,s=1\), the identity \((1+T)^5=1+T+T^4+T^5\) gives a lift modulo \(h^4\) and excludes one modulo \(h^5\).

For the ordered bar differential let \(h\) now be a formal parameter. A coefficient of its deformation can act in several word lengths because it is a coderivation. Write \(b(h)=b^{(0)}+\sum_{i\ge1}h^i b^{(i)}\), with \(|h|=0\) and \(|b^{(i)}|=1\). In the graded commutator \([P,Q]=PQ-(-1)^{|P||Q|}QP\), the equation \(b(h)^2=0\) at order \(N\ge1\) reads
\[
 [b^{(0)},b^{(N)}]=-\sum_{i=1}^{N-1} b^{(i)} b^{(N-i)}.
\]
The obstruction on the right has degree two. If the lower equations hold, it is closed for \([b^{(0)},-]\), since the truncated differential commutes with its square. A lift needs a degree-one primitive satisfying the translation, vacuum, cut, collision and support conditions on the ordered configurations.

For a comparison that must preserve a given module action, distinguish three types of objects in the diagram of operations. They are the source algebra, the target algebra and the state module. The algebra comparison and the action on states are operations with these specified input and output types. Restricting a deformation of the diagram to the observed action gives a map of deformation problems. Holding that action fixed up to a specified homotopy calls for the homotopy fibre over the given action. A point of the fibre includes the path identifying the restricted action with it.

At a compatible lift, a surjective map of deformation dg Lie algebras with the corresponding fibration on filtered layers computes the based fibre by its kernel. In characteristic zero a model can also have higher brackets. If \(\gamma_1\) is the first variation and \(\ell_3\) the ternary bracket, the third-order curvature includes \(\ell_3(\gamma_1,\gamma_1,\gamma_1)/6\). Compatible primitives give a formal comparison provided that the relative complex controls this diagram, its insertions converge and its filtration is complete, separated and pronilpotent.

## Support where every consecutive cut fails {#ch05-the-support-remembers-which-cuts-were-allowed}

At \((x,y,x)\), with \(x\ne y\), the two consecutive cuts of a three-letter word both fail. Wherever a cut is available, does its coproduct recover the full coefficient from the coefficients of the two separated blocks?

::: definition {#ch05-definition-factorization-across-consecutive-cuts title="Factorisation across consecutive cuts"}
A connected coaugmented coalgebra \(C\) factorises across consecutive cuts if, for every \(0<p<n\), its cut coproduct on \(U_{p,n-p}\)
\[
C_n|_{U_{p,n-p}}\longrightarrow
(C_p\boxtimes^{\mathbf L}C_{n-p})|_{U_{p,n-p}}
\]
is an equivalence.
:::

**Definition (associative chiral algebra on words).** This is an augmented \(E_1\)-algebra \(A\) for consecutive-cut convolution, with \(A_0\simeq k\), whose bar coalgebra \(BA\) factorises across consecutive cuts. Here \(E_1\) retains the multiplication with all its associativity homotopies. Its augmentation ideal has zero empty coefficient.

Which positive-arity coefficients can this ideal have? On each cut open the coproduct must split the bar coalgebra into two independent coefficients. Let \(Z_n\) be the locus where *no* consecutive cut is available,
\[
Z_n=X^n\setminus\bigcup_{p=1}^{n-1}U_{p,n-p},
\qquad Z_1=X.
\]
For a complex \(F\), let \(j\) include the complement of a closed set \(Z\). Derived sections supported on \(Z\), denoted \(R\Gamma_ZF\), form the fibre of \(F\to Rj_*j^*F\). In arity two there is just one cut, with open \(U_{1,1}=X^2\setminus\Delta_{12}\) and closed locus \(Z_2=\Delta_{12}\). Over that open the factorising coproduct gives \(j^*C_2\simeq j^*(C_1\boxtimes^{\mathbf L}C_1)\). Applying \(Rj_*\) identifies the two-block cobar term before shifts with \(Rj_*j^*C_2\). The map to it from the one-block coefficient is therefore \(C_2\to Rj_*j^*C_2\).

**Support theorem.** Consecutive-cut duality restricts to an equivalence between connected factorising coalgebras and connected algebras whose positive-arity coefficients vanish on every cut open. For a connected factorising coalgebra \(C\) and \(n\ge1\),
\[
\overline{\Omega C}_n\simeq R\Gamma_{Z_n}(C_n)[-1].
\]

*Proof.* Start with two letters. The one-block cobar term is shifted by \([-1]\) and the two-block term by \([-2]\). Factorisation identifies their arrow before shifts with \(C_2\to Rj_*j^*C_2\). Its fibre shifted by \([-1]\) is the binary reduced cobar coefficient. With \(n\) letters choose a subset of the \(n-1\) gaps. If it has \(r-1\) members it cuts out \(r\) blocks. The cobar shift is \([-r]\), which differs by an additional shift \([-1]\) from \([-(r-1)]\) in the localisation cube. On the intersection of these cut opens the iterated coproduct identifies the coefficient with the external product of the \(r\) block coefficients. Coassociativity makes these identifications commute with adding a cut. The total fibre of the localisation cube computes sections supported off the union of the opens. Comparing the shifts at each vertex gives the cobar coefficient an additional shift \([-1]\).

Conversely, assume the positive algebra coefficients vanish on the cut opens. Fix one cut and restrict the bar to its open. A bar factor straddling the cut has zero coefficient, since that factor itself admits the cut. Every surviving term therefore has a separator at the chosen gap. A multiplication face that removes this separator has zero target. Each remaining face, including a higher multiplication face, acts wholly to its left or wholly to its right. Splitting at the separator identifies the two complexes in the definition above. ∎

The argument also applies to unbounded right differential modules with quasi-coherent underlying modules on a smooth separated finite-type scheme of positive pure dimension over the characteristic-zero field \(k\). For a monotone collision \(d\) and a cut open \(j\), let \(j'\) include its inverse image and \(d'\) be the restriction of \(d\) to that open. Open base change identifies \(d^!Rj_*j^*F\) with \(Rj'_*d'^!j^*F\). A cut inside a repeated block has empty inverse image. Every other cut pulls back to the corresponding cut of the shorter word. This gives compatibility of the support calculation with monotone collisions.

On three *distinct* spectral positions, every division of the labels into two nonempty blocks separates the blocks. A further choice remains even with all positions fixed. Prepare the three lines in order \(123\). Splitting off \(1\) and then splitting \(23\) gives \(1|2|3\). Splitting off \(3\) as the last block and then dividing \(12\) gives the same three singleton blocks. How do these two routes enter the differential if all orders of the preparations are available?

::: example {#ch05-three-point-cut-hexagon title="The six refinements at three distinct points"}
Record a two-block split by its first subset, writing \(12\) for \(\{1,2\}\), for example. Record the three-block refinement \(1|2|3\) by the edge \(1\subset12\). Its endpoints are the cuts \(1|23\) and \(12|3\). With all six two-block cuts and all six singleton orders, the vertices occur in cyclic order
\[
 1,\quad 12,\quad 2,\quad 23,\quad 3,\quad 13,\quad 1 .
\]
Orient each edge from the smaller subset to the larger. Suppose the iterated coproducts identify every coefficient with the same unsuspended complex \(V\), compatibly along both routes to each edge. The scalar part of the cobar has one uncut term in degree one, six vertices in degree two and six edges in degree three. The uncut value \(v\) maps to the constant vertex function with value \(v\). On an edge \(S\subset T\), the coboundary of a scalar vertex function \(f\) is \(f(T)-f(S)\). For instance its value on \(1|2|3\) is \(f(12)-f(1)\).

A vertex function with zero differences is constant, so it comes from the uncut term. On the edges, sum the values along the displayed circuit, changing sign on each step against its orientation. The sum of the differences is zero. Conversely, if the signed sum is zero, start at \(1\) with value zero and add the successive signed edge values. The value on returning to \(1\) is again zero, so this defines a vertex primitive. A cochain equal to one on \(1\subset12\) and zero on the other edges has circuit sum one. Thus the oriented hexagon leaves \(V[-3]\). Keeping the single word \(123\) retains just the edge \(1\subset12\) and its endpoints. Every edge value now has a primitive and the uncut term removes the constant, so the result is zero. Adding precisely the reverse word \(321\) adds the disjoint edge \(3\subset23\). There are now two independent vertex constants and one uncut term. Subtracting the first constant from the second gives \(V[-2]\).
:::

Each edge of this hexagon records a refinement of a split. Agreement of the two routes to that refinement is essential. For scalar coefficients over \(\mathbb Q\), keep all six maps from the uncut term equal to \(1\). Change the minus sign to a plus at one endpoint of one edge. Every individual coefficient map is still invertible, but the composite on that edge sends \(1\) to \(2\). The required compatibility is a property of the diagram.

Let \(I\) be a set of \(n\ge1\) labels. On the open \(U_I=\operatorname{Conf}_I(X)\) where their positions are pairwise distinct, write \(V=C_I|_{U_I}\) before desuspension. An ordered partition \(B_1|\cdots|B_q\) has a **flag** of proper initial subsets
\[
 S_1\subset\cdots\subset S_{q-1},\qquad
 S_j=B_1\sqcup\cdots\sqcup B_j .
\]
The uncut partition has the empty flag. With \(S_0=\varnothing\) and \(S_q=I\), the differences \(S_j\setminus S_{j-1}\) recover the blocks. Splitting a block inserts a subset. Merging neighbours deletes one. Let \(K\) be a family of these flags containing the empty flag and closed under deletions. Its vertices are the retained proper subsets, and its simplices are the retained flags. Denote by \(D_K(C)\) the positive normalised cobar in this arity projected onto those terms. This definition specifies which complete refinements to keep. Iterating a binary assembly law in every arity also requires the unit and compatible maps for all its iterates.

::: theorem {#ch05-separated-flag-cobar title="The cobar of a family of cuts at distinct points"}
Let \(k\) be a commutative ring. Work in complexes over \(k\), or in a stable \(k\)-linear coefficient category with the indicated derived products and finite totalisations. Let the coaugmented counital coalgebra be connected in arity. On \(U_I\) assume that its iterated ordered coproducts give a coherent equivalence from the constant diagram at \(V\) to the diagram of coefficients on the retained flags. Here constancy compares refinements at the same spectral configuration. The complex \(V\) can vary over \(U_I\). Write \(\widetilde C^\bullet(K;k)\) for augmented simplicial cochains, with \(k\) in degree \(-1\) for the empty flag. Then
\[
 D_K(C)\simeq V\otimes_k^{\mathbf L}\widetilde C^\bullet(K;k)[-2].
\]
For an inclusion \(K\subseteq L\) of such families with the coherent comparison on \(L\), the fibre of \(D_L(C)\to D_K(C)\) is \(V\otimes_k^{\mathbf L} C^\bullet(L,K;k)[-2]\), where the relative cochains vanish on \(K\).
:::

::: proof {#ch05-proof-separated-flag-cobar}
A term with \(q\) blocks has \(q\) cobar desuspensions. Its \(q-1\) vertices give cochain degree \(q-2\), including degree \(-1\) for the uncut term. The common shift \([-2]\) gives precisely cobar degree \(q\). Order the vertices by inclusion. Splitting block \(i\) inserts the vertex in position \(i\), counted from one, with incidence sign \((-1)^{i-1}\).

To compare with the [cobar differential](#ch05-cobar-reverses-the-construction), take homogeneous block coefficients \(y_1,\ldots,y_q\) in a strict dg presentation. Move the desuspensions \(u\) off the ordered factors. Send \((uy_1)\cdots(uy_q)\) to the unshifted tensor followed by its flag cochain, with sign
\[
 (-1)^{\,q+\sum_{j=1}^q j|y_j|}.
\]
An internal differential in slot \(i\) changes this exponent by \(i\). This cancels the \(i-1\) preceding desuspensions and the minus sign in \(d_\Omega(uy_i)\). For a summand \(y'\otimes y''\) of the split of \(y_i\), the derivation and the generator differential give exponent \(\sum_{j<i}|y_j|+i+|y'|\). The change of coordinates adds \(1+|y''|+\sum_{j>i}|y_j|\). As \(|y_i|=|y'|+|y''|\), the sum is congruent to \(\sum_j|y_j|+i-1\) modulo two. This leaves the tensor sign for passing the coefficient and the incidence sign for inserting the vertex. The coefficient maps are the ordered coproducts, with their own changes of order.

For coherent coproducts, apply their comparison from \(V\) to the refinement diagram before totalising it. Filtering by the number of blocks gives an equivalence on each layer, hence on the total complex. There are at most \(n\) layers, even for unbounded \(V\). A refinement of a flag outside \(K\) stays outside \(K\), since deleting the new cut recovers the original flag. Projection is consequently a cochain map. On the finite free flag modules its restriction is split surjective in each degree. Its kernel consists of the relative cochains, with the two empty flags cancelling. Derived tensor with \(V\) preserves the fibre sequence. This finite cochain calculation works over any commutative ring. The geometric construction with right algebraic differential modules on the curve retains its characteristic-zero hypotheses.
:::

For instance, project the three-point hexagon onto the two opposite edges \(1\subset12\) and \(3\subset23\). In the relative cochains the two missing vertices are \(2\) and \(13\). Each meets two of the four missing edges. The coboundary at \(2\) has coefficients \(-1,-1\) on its two outgoing edges, and that at \(13\) has coefficients \(+1,+1\) on its two incoming edges. These pairs are disjoint. Quotienting by the two images leaves two free edge classes and no vertex class. Thus the fibre of this projection is \((V\oplus V)[-3]\).

For the full family on \(n\ge2\) labels, a proper nonempty subset is a proper nonempty face of the simplex on \(I\). Its flags give the barycentric subdivision of the boundary, a sphere of dimension \(n-2\) for \(n\ge2\). The orientation line of the label set is \(\det(k^I)=\bigwedge^n k^I\), where \(k^I\) has one basis vector for each label. Write \((-)^\vee\) for the \(k\)-linear dual. Choose an order on \(I\). Sum the maximal flags with the signs of their singleton permutations in that order. Every codimension-one face occurs twice with opposite signs, since exchanging the two labels at the missing step changes the permutation sign. The sum is the oriented fundamental cycle. Evaluation of any one maximal flag cochain on it is \(+1\) or \(-1\), so this normalisation is integral. Changing the label order changes the cycle by the permutation sign. Pairing with the cycle gives the full separated coefficient
\[
 D_{\mathrm{full}}(C)\simeq V\otimes_k\det(k^I)^\vee[-n].
\]
The dual orientation line has the sign action in addition to the action on \(V\). No division by \(n!\) enters the pairing. For \(V=k\) with trivial label action, a strict equivariant section would have to send the orientation generator to a multiple of the alternating sum of all top cochains. Its evaluation is that multiple times \(n!\), so such a section exists precisely when \(n!\) is a unit. The derived equivalence holds over every \(k\). For the ordered-partition proof of the full-family formula and the word contraction, see *Chiral Quantum Groups and Holography*, “Factorizing bars and invertible products”, in “Ordered partitions” and the proof of the factorisation theorem. [Stanley, *Some aspects of groups acting on finite posets*, §4](https://math.mit.edu/~rstan/pubs/pubfiles/50.pdf)

For a word of length \(n>1\), its \(n-1\) proper prefixes form a chain. The flags of consecutive cuts form the whole simplex on those prefixes, which contracts to any one of them. With one label there are no proper prefixes. Only the empty flag remains, so both choices give \(V[-1]\). At arity zero the unit is \(k\), and the augmentation ideal is zero. All these degrees are relative to the unsuspended \(V\). For a residue coalgebra whose separated coefficient is a product of \(n\) suspended degree-zero singleton factors, the term with \(q\) blocks has degree \(q-n\). Permuting those odd suspensions contributes the second sign line. The two signs cancel, and the full separated coefficient in that convention is in degree zero. [The determinant letters of the residue coalgebra](#ch05-rational-exchange-diagram)

There is an intermediate assembly law if some labels must precede others. Give \(I\) a partial order. Permit a first block \(J\) precisely when it is a lower ideal, so that \(b\in J\) and \(a\le b\) imply \(a\in J\). With the induced order on each block, a ternary split in either bracketing is exactly a pair of nested ideals. Indeed, if \(J\subset H\) are ideals, then \(H\setminus J\) is an ideal in \(I\setminus J\), and conversely adding such an ideal to \(J\) gives \(H\). Thus iteration gives the flags of ideals, with the empty block as unit. An antichain allows every flag. If there is even one strict precedence, choose a minimal element \(m\) with a successor \(b\). A proper ideal omitting \(m\) also omits \(b\), so adjoining \(m\) keeps it proper. On the poset of nonempty proper ideals the order-preserving comparisons \(J\subseteq J\cup\{m\}\supseteq\{m\}\) give a homotopy from the identity to a constant. The separated cobar therefore vanishes. The two opposite words of the hexagon, on the other hand, specify two *whole* preparations. Freely reversing the first block of \(12|3\) would also retain \(2|1|3\), absent from both \(123\) and \(321\). To apply either choice to physical lines, the allowed preparations must realise its refinement maps and their compatible composites on the line coefficients.

Let two marks approach one another in the three-letter word \(123\). Which equality puts a repeated mark on both sides of every consecutive cut?

For three labels, write \(\Delta_{ij}=\{x_i=x_j\}\). The cut \(1|23\) fails when \(x_1=x_2\) or \(x_1=x_3\). The cut \(12|3\) fails when \(x_3=x_1\) or \(x_3=x_2\). If both fail and \(x_1\ne x_3\), the first failure forces \(x_1=x_2\) and the second forces \(x_2=x_3\), a contradiction. Conversely \(x_1=x_3\) prevents both cuts. Hence
\[
Z_3=(\Delta_{12}\cup\Delta_{13})
\cap(\Delta_{13}\cup\Delta_{23})=\Delta_{13}.
\]
At \((x,y,x)\) with \(x\ne y\), both cuts fail. Must a cobar coefficient survive there? Let \(i:S\hookrightarrow X^n\) include an equality stratum inside \(Z_n\). Extraordinary restriction to \(S\) kills the direct image \(Rj_*j^*C_n\) from the complementary open. Applying \(i^!\) to the support fibre gives \(i^!\overline{\Omega C}_n\simeq i^!C_n[-1]\). The dualising coalgebra \(J_n=\omega_{X^n}[n]\) on the curve, with \(J_0=k\), attains the whole bound. Its cut coproducts come from external products on the cut opens. At each geometric point of \(Z_n\) its extraordinary fibre is the dualising coefficient of that point and is nonzero.

Keep the first and third labels at \(x\), with the second at \(y\ne x\). The additional split \(13|2\) separates the two \(x\)'s from \(y\). Adjoining its open to the two word-cut opens shrinks their common failure locus from \(\Delta_{13}\) to the triple diagonal \(\Delta_{123}\). To isolate what the support calculation loses, let \(h\) include the complement of \(\Delta_{123}\) in \(X^3\) and take \(F=C_3\). Localisation for the two nested supports gives the triangle
\[
\begin{aligned}
 R\Gamma_{\Delta_{123}}F[-1]&\longrightarrow R\Gamma_{\Delta_{13}}F[-1]\\
 &\longrightarrow Rh_*R\Gamma_{\Delta_{13}\setminus\Delta_{123}}(h^*F)[-1]
 \longrightarrow R\Gamma_{\Delta_{123}}F .
\end{aligned}
\]
The middle arrow restricts the sections with support to the complement of the triple collision. Its source has the word value just computed by extraordinary restriction. The triangle compares two families of separation *opens*. Computing a cobar for a larger family of *ordered decompositions* also counts its distinct refinements, as the hexagon shows.

In the word \(x,y,x\), exchanging the last two distinct marks gives \(x,x\mid y\), preserving the order of the two lines at \(x\). Let \(s\) interchange slots 2 and 3. On the open \(z_1\ne z_2,\ z_3\ne z_2\), the exchanged word admits \(12|3\). If a word coefficient vanishes on the consecutive cut opens, its pullback by \(s\) therefore vanishes on this open, which contains the return \(x,y,x\). Transporting this vanishing back requires an equivalence from the word coefficient itself to its pullback on \(z_2\ne z_3\). Fusing the two equal marks in the new order still requires a collision map. An exchange acting on the tensor product of line states compares those preparations there. It supplies an equivalence on a cobar coefficient only if it also intertwines the retained refinements. In particular \(J\) gives a word coefficient on the return stratum without any choice of a nonlinear interaction. [Ordered configurations and cut opens](04-factorization.md#ordered-cut-geometry) · [Exchange on combined probes](12-chiral-quantum-groups.md#ch12-combined-probe-exchange)

On \(X=\mathbb A^1\), take the square-zero algebra with \(A_0=k\) and \(\bar A_n=\Delta_{n,*}\omega_X\), where \(\Delta_n(x)=(x,\ldots,x)\). For a repetition \(d:X^m\hookrightarrow X^n\) we have \(\Delta_n=d\circ\Delta_m\). Its coefficient is already carried by the image of \(d\), so \(d^!\Delta_{n,*}\omega_X\simeq\Delta_{m,*}\omega_X\) by the [diagonal pullback calculation](04-factorization.md#ordered-cut-geometry). This gives the monotone collision identifications. On a cut open every surviving bar word has a separator at that cut, so \(BA\) factorises. Its reduced ternary cobar coefficient is \(\bar A_3\), supported on the small diagonal.

At four labels, the single equality \(x_1=x_4\) crosses every cut. The two equalities \(x_1=x_3,\ x_2=x_4\) also cross all three cuts, and removing either one loses an end cut. To see that these give all of \(Z_4\), suppose \(x_1\ne x_4\). Failure at the two end cuts requires each end to agree with a middle label. They must agree with different ones. The pairing \(12|34\) alone leaves the middle cut available, so \(x_1=x_3\) and \(x_2=x_4\). Thus the two components of \(Z_4\) are \(\Delta_{14}\) and \(\Delta_{13}\cap\Delta_{24}\). On a curve \(\Delta_{14}\) has codimension one and \(\Delta_{13}\cap\Delta_{24}\) has codimension two. Thus a common failure locus of cuts can already have components of different dimensions.

To count components in general, let \(X\) be a separated geometrically integral variety of dimension \(d>0\). For a partition \(\pi\) of the \(n\) labels into \(|\pi|\) blocks, its diagonal \(D_\pi\) imposes equality within each block. It is isomorphic to \(X^{|\pi|}\) and distinct block values form a dense open in it. The components are therefore indexed by the partitions that cross every cut and lose this property under every proper refinement. If a block contained an interior label as well as its two extreme labels, we could split off that interior label without losing a single cut. Minimality therefore forces each nonsingleton block to be a pair.

The intervals of gaps covered by the pairs \((a_i,b_i)\), listed by left endpoint, must cover every gap, with a private gap for each interval. Successive intervals must overlap in the ordered labels to cover every gap. Since each has a gap of its own, the right endpoints increase, and an interval cannot overlap the one two places later. This forces \(a_1=1,\ b_r=n\), with internal endpoints in the order \(a_2,b_1,a_3,b_2,\ldots,a_r,b_{r-1}\). Conversely each such choice covers every gap and gives every pair a gap covered by that pair alone. Choosing the \(2r-2\) internal endpoints among \(2,\ldots,n-1\) now determines all \(r\) pairs. Thus \(Z_1=X\), and for \(n\ge2\) there are \(\binom{n-2}{2r-2}\) components of codimension \(dr\) for \(1\le r\le\lfloor n/2\rfloor\). The total is one at \(n=2\) and \(2^{n-3}\) at \(n\ge3\).

What replaces the intervals when the cuts come from a tree? For any finite family of cuts, a partition crossing them all is minimal precisely when every bipartition of each block is induced by a cut that leaves all its other blocks intact. Indeed that cut is lost on splitting the block.

For a tree whose vertices are the labels, deleting an edge gives a cut into the two connected components. For any two edges, the sides facing away from each other are disjoint. A block of four or more labels would require cuts inducing both \(12|34\) and \(13|24\) on four of its labels. Each side of the first meets each side of the second. No two tree edges can do this, so every nonsingleton block is a pair or a triple. A pair crosses precisely the edges on its path, and a triple crosses the edges of its spanning subtree. Together these paths and subtrees must cover the tree. Splitting a pair must uncover an edge on its path. Splitting one vertex from a triple must uncover an edge on that vertex’s arm from the common meeting point of the three paths. Thus a pair needs a private edge on its path, and a triple needs a private edge on each arm. The tree with edges \(12,13,14,25\) has one triple \(345\) and five two-pair components, all of codimension \(2d\). The two-pair components are \(13|45,\ 14|35,\ 15|34,\ 23|45,\ 24|35\), with the remaining label a singleton.

On a star with \(m\) leaves there are \(a\) leaf pairs, \(b\) leaf triples and \(e\in\{0,1\}\) centre–leaf pairs. Each type with \(2a+3b+e=m\) gives \(m!/(2^a6^b a!b!)\) components of codimension \(d(a+2b+e)\).

For any cut family, start with the discrete partition. For each cut in turn adjoin one equality across it in every possible way and retain the refinement-minimal results. This recursion distributes intersection with the next failure locus over the preceding component diagonals.

The two components at four labels meet at the small diagonal. For a coefficient complex \(F\), to take sections with support in their union, map the sections supported on their intersection to the direct sum of the two component complexes. If \(\iota_1,\iota_2\) are the support inclusions into the complexes for \(\Delta_{14}\) and \(\Delta_{13}\cap\Delta_{24}\), respectively, this map is \((\iota_1,-\iota_2)\). Mayer–Vietoris identifies the cofibre of this map with \(R\Gamma_{Z_4}F\). For \(F=C_4\), the extra shift \([-1]\) in the support theorem makes the *fibre* of the same map the reduced cobar coefficient.

For any \(n\), assume a stable coefficient theory with coherent support inclusions and Mayer–Vietoris. Intersecting component diagonals imposes all the equalities of their partitions, hence gives the diagonal of their join. Let \(J\) be the set of distinct joins of nonempty sets of component partitions, ordered from coarser to finer. Then
\[
R\Gamma_{Z_n}F\simeq\operatorname*{hocolim}_{\rho\in J}R\Gamma_{D_\rho}F.
\]
Indeed iterated Mayer–Vietoris uses all nonempty subsets of components, ordered by reverse inclusion. For a given join \(\rho\), the subsets whose joins receive an arrow from \(\rho\) are exactly the nonempty subsets of component partitions refining \(\rho\). Under reverse inclusion the set of *all* components refining \(\rho\) has a unique arrow to each such subset. It is therefore initial in the category of subsets over this comparison. This proves cofinality and permits each distinct intersection to be indexed by its partition.

The word \(123\) and its reverse have different proper prefix subsets. On the collision chart, however, their separation opens agree in pairs. For a proper nonempty subset \(S\subset I\), let \(U_S\) require all positions in \(S\) to differ from all positions outside it. Then \(U_S=U_{I\setminus S}\). To compare the two words across collisions, put \(F=C_I\) on a fixed chart. Assume for every retained flag that its unshifted coefficient is the derived direct image of \(F\) restricted to the intersection of its cut opens. The comparisons under refinement must be the actual localisation maps, with coherent open base change and finite derived Čech descent. These assumptions use \(Rj_*j^*\) for an open inclusion \(j\). For example, let \(j_0\) include a punctured complex disc in the disc and take a locally constant Betti coefficient with fibre \(E\) and transport \(T\) around the positively oriented circle. At the origin extension by zero has zero stalk, while the derived direct image has the circle cochains \([E\xrightarrow{T-1}E]\) in degrees zero and one. For \(T=1\) both copies survive. The cut cobar uses the direct image for its actual cut open, which can include collisions within a block. [The normal link calculation](04-factorization.md#ch04-normal-link)

::: proposition {#ch05-opposite-words-at-collision title="Two opposite words on a collision chart"}
Fix a word \(\pi\) on \(n>1\) labels. Keep all its flags and all the flags of its reverse, under the preceding localisation hypotheses. Let \(Z\) be the common failure locus of the consecutive cuts of \(\pi\), and let \(j:X^I\setminus Z\hookrightarrow X^I\). For this ordered pair of words the positive cobar on their union splits as
\[
 D_{\pi\cup\pi^{\rm rev}}(C)\simeq
 R\Gamma_Z F[-1]\ \oplus\ Rj_*j^*F[-2].
\]
:::

::: proof {#ch05-proof-opposite-words-at-collision}
In either word, the nonempty faces of its prefix simplex form the Čech complex of the cut opens. Its augmentation from \(F\) gives the support fibre \(G=R\Gamma_ZF\) with the cobar shift \([-1]\). The two flag families meet only in the empty flag, whose term is \(F[-1]\). Cochains on their union are the fibre of the difference of the two restrictions to that flag. Before the common shift this difference is \(G\oplus G\to F\), given by \((a,b)\mapsto i(a-b)\) for the support inclusion \(i:G\to F\). In coordinates \((b,a-b)\) its fibre is \(G\oplus\operatorname{fib}(i)\). The localisation triangle identifies the second summand with \(Rj_*j^*F[-1]\). Restoring the common shift proves the formula. The coordinates use the order of the pair. For \(n>2\) other orders have further flags.
:::

### From support to fields {#ch05-from-support-to-fields}

::: example {#ch05-scalar-inverse-readings title="A regular coefficient becomes a residue"}
Join two copies of \(R=\mathbb C[[s]]\) by multiplication by \(s\), with the basis vector \(1\) fixed at each end. The formal parameter \(s\) vanishes at the collision. Prescribe the output \(1\), solve for the input over the Laurent series field \(K=\mathbb C((s))\), and read off the negative powers of \(s\). This gives the principal part \([s^{-1}]\) in the quotient \(Q=K/R\). Change the attaching map to multiplication by \(s/(1+s)\). The solution becomes \(s^{-1}+1\), with the same principal part.

Place a second attachment, multiplication by \(s\), before the first, matching the two middle basis vectors. Solving backwards through both maps gives \(s^{-2}\) in the first preparation and \(s^{-2}+s^{-1}\) in the second. The coefficient of \(s^{-1}\) is now \(0\) or \(1\). The second pole makes the previously discarded constant observable.
:::

For the [cup product on supports](04-factorization.md#ch04-supported-transverse-product), the same two principal parts are classes of degree one. The localisation complex \([R\to K]\) in degrees zero and one gives \(H^1_{(s)}(R)=Q\) and \(H^2_{(s)}(R)=0\). Their cup product therefore vanishes. On transverse divisors \(u=0,\ v=0\), taking \(u\) first gives \([1/(uv)]\) with residue \(+1\). Exchanging the degree-one factors while keeping that orientation gives \(-1\). The inverse experiment composes maps over \(K\) before taking their principal part. Its nonzero residue raises a question even for a single attachment. What can all its principal parts determine when the input and output spaces have several components?

Let \(D:E_0\to E_1\) be a map of finite free \(R\)-modules which becomes an isomorphism over \(K\). Fix bases at both ends. We use the differential \(+D\) from degree \(-1\) to degree zero. The quotient \(T_D=E_1/D E_0\) records which integral outputs have no integral preimage. Given \(x\in E_1\), solve \(Du=x\) over \(K\) and evaluate an integral covector \(y\in E_0^\vee=\operatorname{Hom}_R(E_0,R)\) on \(u\). Write \(A_D=D_K^{-1}\) for this inverse and \(D^t b=b\circ D\) for the transpose on covectors.

::: proposition {#ch05-linking-dual-of-an-attachment title="The linking pairing of a framed attachment"}
The readings in the fixed bases give a perfect \(Q\)-valued pairing
\[
 T_D\times(E_0^\vee/D^t E_1^\vee)\longrightarrow Q,
 \qquad ([x],[y])\longmapsto [y(A_Dx)] .
\]
Each module is the \(R\)-linear dual of the other with values in \(Q\). The outputs \(x\) whose readings vanish for every integral \(y\) form the embedded lattice \(DE_0\subset E_1\).
:::

::: proof {#ch05-proof-linking-dual-of-an-attachment}
Replacing \(x\) by \(x+Da\) adds \(y(a)\) to the evaluation. Replacing \(y\) by \(y+D^t b\) adds \(b(x)\). Both additions lie in \(R\). In Smith bases \(D\) has diagonal entries \(s^{a_j}\) with \(a_j\geq0\). On a summand \(R/(s^a)\) the pairing reads \([xy/s^a]\). A covector on this cyclic module with values in \(Q\) can send \(1\) to exactly the elements of \(s^{-a}R/R\), which proves perfection. Changing the differential to \(-D\) changes the sign of this reading in the fixed frames. In the original bases the coordinate covectors read every entry of \(A_Dx\bmod E_0\). All entries vanish precisely when \(A_Dx\in E_0\), or equivalently when \(x\in DE_0\).

The shift in this duality also applies to a perfect complex \(C\) which is acyclic over \(K\). Write \(C^\vee=\mathbf R\operatorname{Hom}_R(C,R)\). Localisation gives \(\mathbf R\operatorname{Hom}_R(C,K)=0\). Applying \(\mathbf R\operatorname{Hom}_R(C,-)\) to \(R\to K\to Q\) identifies its linking dual with \(C^\vee[1]\). Dualising twice returns \(C\) by perfect biduality and cancellation of the two shifts. For \(D=s^a,\ a>0\), reduction of the two-term complex modulo \(s\) gives \(\mathbb C\oplus\mathbb C[1]\) for every \(a\). The pole of the reading on the two marked generators still has order \(a\).
:::

A single trace of the inverse gives \(s^{-1}+s^{-2}\) for both \(\operatorname{diag}(s,s^2)\) and \(\operatorname{diag}(s^2,s)\). The first coordinate covector on the first basis vector distinguishes their image lattices. Even with all these markings the scalar preparations above have identical individual readings. What survives when two attachments are joined?

::: proposition {#ch05-extension-of-two-attachments title="Two attachments with marked end quotients"}
For successive attachments \(E_0\xrightarrow{D_1}E_1\xrightarrow{D_2}E_2\) as above, the individual marked principal parts determine the extension
\[
 0\longrightarrow T_{D_1}\xrightarrow{\,[x]\mapsto[D_2x]\,}
 T_{D_2D_1}\longrightarrow T_{D_2}\longrightarrow0
\]
up to an isomorphism inducing the identity on both end quotients. This is equality of the Yoneda extension classes.
:::

::: proof {#ch05-proof-extension-of-two-attachments}
The last arrow takes a class modulo \(D_2D_1E_0\) to its class modulo \(D_2E_1\). Its kernel is the image of the first arrow, which is injective because \(D_2\) is. For \(D_1=s^a,\ D_2=s^b\) with \(a,b>0\), the middle is \(R/(s^{a+b})\). This extension cannot split since \(s^{\max(a,b)}\) kills both end modules but does not kill the middle.

Suppose another integral attachment \(D'\) gives the same marked readings as \(D\). Then \(A_{D'}=A_D+B\) for an integral map \(B:E_1\to E_0\), and the kernel calculation gives \(D'E_0=DE_0\). Set \(U=1+BD\) and \(W=1+DB\). Their inverses are \(1-BD'\) and \(1-D'B\), respectively, as follows by multiplication. Thus \(D'=DU^{-1}=W^{-1}D\), and \(W\) induces the identity modulo \(DE_0\). Apply this identity at the outer ends of the two attachments. It gives
\[
 D'_2D'_1=W_2^{-1}D_2D_1U_1^{-1}.
\]
The automorphism \(W_2^{-1}\) carries the old middle image onto the new one. It takes \(D_2x\) to \(D'_2x\) and fixes the quotient \(T_{D_2}\). Hence the induced isomorphism of the middle quotients respects both marked ends.
:::

::: example {#ch05-two-and-three-attachments title="An embedded lattice and its Smith exponents"}
In the standard bases of \(R^2\), take \(D_1=D_2=\operatorname{diag}(s,1)\). Let \(E_{12}\) send the second basis vector \(e_2\) to \(e_1\) and kill \(e_1\). Adding \(E_{12}\) to \(D_2^{-1}\) changes the composite image from the span of \(s^2e_1,e_2\) to the span of \(s^2e_1,e_2-se_1\). The latter omits \(e_2\), since cancelling its first coordinate would require a coefficient \(1/s\). The middle quotients are isomorphic with marked ends, yet the inverse of the composite has acquired \(s^{-1}E_{12}\).

With a third attachment even the isomorphism type can change. Take
\[
 D_1=\operatorname{diag}(s^2,1),\qquad D_2=sI,\qquad
 D_3=\operatorname{diag}(1,s^2).
\]
Replace \(D_2\) by \(sI-s^2E_{12}\). Since \(E_{12}^2=0\), its inverse is \(s^{-1}I+E_{12}\). All three individual principal parts, and hence both adjacent extension classes, agree. The composite \(D_3D_2D_1\) changes from \(s^3I\) to \(s^3I-s^2E_{12}\). The least valuation of an entry gives the first Smith exponent. The determinant has valuation six in both cases and gives the sum of the exponents. The pairs are \((3,3)\) and \((2,4)\).
:::

In the scalar experiment one extra constant sufficed because the other inverse had a simple pole. In a longer chain each of the other inverses can lower the degree at which an error first occurs. A [jet of a marked inverse](reference.html#s-jets-of-composite-marked-inverses) modulo \(s^q\) records all Laurent coefficients in degrees strictly below \(q\), in the chosen bases.

::: theorem {#ch05-composing-marked-inverses title="Sharp precision for a composite of marked inverses"}
Let \(D_i:E_{i-1}\to E_i\), \(1\leq i\leq l\), be a nonempty chain of integral maps of finite free lattices over \(R=\mathbb C[[s]]\), with fixed bases. Assume each \(D_i\) is invertible over \(K=\mathbb C((s))\). Put \(A_i=(D_i)_K^{-1}\) and choose integers \(p_i\geq0\) such that \(s^{p_i}A_i\) is integral. To determine \(A_1\cdots A_l:E_l\otimes_R K\to E_0\otimes_R K\) modulo \(s^b\), for an integer \(b\geq0\), it suffices to know \(A_i\) modulo \(s^{q_i}\) for each \(i\), where
\[
 q_i=b+\sum_{j\ne i}p_j .
\]
For the principal part take \(b=0\). In addition to its poles, factor \(i\) then needs its regular coefficients in degrees \(0\) through \(q_i-1\), an empty range for \(q_i=0\). The required regular precision is sharp separately for each factor among all chains with the given pole bounds.
:::

::: proof {#ch05-proof-composing-marked-inverses}
Compare two chains whose inverse coefficients agree to the specified orders. Replace the inverses one at a time, keeping their order. The \(i\)-th difference has the form \(A'_1\cdots A'_{i-1}(A'_i-A_i)A_{i+1}\cdots A_l\). The middle factor is divisible by \(s^{q_i}\). The other factors can lower its valuation by at most \(\sum_{j\ne i}p_j\). Each difference therefore lies in \(s^b\operatorname{Hom}_R(E_l,E_0)\).

For sharpness choose the scalar inverses \(A_j=s^{-p_j}\). If \(t=q_i-1\geq0\), change \(A_i\) by \(c s^t\), with \(c\in\mathbb C^\times\). Choose \(1+c\ne0\) if \(t=p_i=0\). The altered inverse still has an integral attaching map, since its reciprocal is \(s^{p_i}/(1+c s^{t+p_i})\). The composite changes by exactly \(c\,s^{b-1}\). With two simple poles and \(b=0\) this is the [scalar residue](#ch05-scalar-inverse-readings).

If all other factors are fixed, form the two products \(L=A_1\cdots A_{i-1}\) and \(H=A_{i+1}\cdots A_l\). Use their actual pole orders \(p_L,p_H\), taking an empty product to have order zero. The difference \(L(A'_i-A_i)H\) shows that precision \(q=b+p_L+p_H\) suffices. For the sharpness witness assume the common rank is positive and \(q>0\). Reduce \(s^{p_L}L\) and \(s^{p_H}H\) modulo \(s\). Both reductions are nonzero. Choose a rank-one integral map \(B:E_i\to E_{i-1}\) whose reduction sends a vector in the image of the second to one detected by the first. Adding \(c s^{q-1}B\) to \(A_i\) then changes the composite in degree \(b-1\). For generic nonzero \(c\in\mathbb C\) the matrix \(1+c s^{q-1}BD_i\) is an integral automorphism, since its determinant modulo \(s\) is a polynomial in \(c\) with constant term one. The perturbed inverse again comes from an integral attachment. This proves sharpness for those fixed neighbours.
:::

::: example {#ch05-split-and-nonsplit-collision title="Two extensions of the residue field"}
Take \(T_1=R/(s)\) at both ends of a short exact sequence, with the generator \(1\) marked at each end. Write \(T_i=R/(s^i)\) for \(i\geq1\) and \(T_0=0\). In the split extension choose a lift \(y\) of the quotient generator in \(T_1\oplus T_1\). Then \(sy=0\). With middle module \(T_2\), include the kernel by \(1\mapsto s\) and project the quotient by reduction modulo \(s\). Now \(sy=s\) for every lift of \(1\), so no lift defines a section. The two sequences give connecting maps \(T_1\to T_1[1]\), zero in the first case and the class of \(1\) in \(\operatorname{Ext}^1_R(T_1,T_1)\) in the second. The positive differential \(s\) in the free resolution fixes this choice of generator.

Both connecting maps induce zero on cohomology, since the source is concentrated in degree zero and the target in degree \(-1\). What if one pairs the output with every scalar principal part? The module \(Q=K/R\) is divisible and hence injective over the discrete valuation ring \(R\). A covector \(T_1[1]\to Q[j]\) can be nonzero only for \(j=1\), and its composite with either connecting map lies in \(\operatorname{Ext}^1_R(T_1,Q)=0\). Applying the [linking dual](#ch05-linking-dual-of-an-attachment) to the connecting map itself preserves the distinction. Both ends are perfect and generically zero, so dualising this derived morphism a second time recovers the original map.
:::

A preparation can also be made at the source. Give it a [cyclic probe](reference.html#s-cyclic-probes-at-every-thickness) \(T_i\) of thickness \(i\), so its marked generator survives multiplication by \(s^{i-1}\) and is killed by \(s^i\). For a source complex \(C\), a preparation in cohomological degree \(a\) is a morphism \(p:T_i[-a]\to C\). Given an operation \(f:C\to D\), its reading on \(p\) is the composite \(fp\) in the derived category.

::: theorem {#ch05-cyclic-probes-at-every-thickness title="Cyclic probes for maps from a bounded collision complex"}
Work in the derived category \(D(R)\) of \(R=\mathbb C[[s]]\). Suppose \(C\) is bounded, its cohomology modules have finite length, and \(s^L H^a(C)=0\) for all \(a\), for a fixed integer \(L\geq1\). Let \(D\) be any object of \(D(R)\). Two maps \(f,g:C\to D\) are equal if and only if \(fp=gp\) for every \(p:T_i[-a]\to C\) with \(1\leq i\leq L\) and \(H^a(C)\ne0\). Every thickness in this range can be necessary, even if one allows all shifts of the other cyclic modules and of \(R\).
:::

::: proof {#ch05-proof-cyclic-probes-at-every-thickness}
A finite module over \(R\) has a free resolution of length at most one, since the kernel of a surjection from a finite free module is free. Thus its Ext groups in degrees at least two vanish. Truncate \(C\) successively at its nonzero cohomological degrees. If the lower truncation has split into its summands \(H^b(C)[-b]\) for \(b<a\), the next connecting map has components in
\[
 \operatorname{Hom}_{D(R)}\bigl(H^a(C)[-a],H^b(C)[1-b]\bigr)
 =\operatorname{Ext}^{\,a-b+1}_R\bigl(H^a(C),H^b(C)\bigr)=0 .
\]
The triangle splits. Starting at the lowest degree gives a noncanonical splitting into the shifted cohomology modules. Each is a finite sum of \(T_i[-a]\) by the structure theorem over a discrete valuation ring, and the annihilator bound gives \(i\leq L\). The inclusions of these summands detect \(f-g\). Testing all \(p\) makes the criterion independent of the splitting (Stacks Project, *Derived Categories*, §13.27).

To see what a missing thickness can hide, fix \(1\leq i\leq L\). Resolve \(T_i\) by \(R\xrightarrow{+s^i}R\) in degrees \(-1,0\). This gives \(\operatorname{Ext}^1_R(T_i,T_i)=T_i\). Let \(e_i:T_i\to T_i[1]\) be the nonzero class \(s^{i-1}\). A map \(T_j\to T_i\) lifts to multipliers \(b_0,b_{-1}\) on the two free resolutions with \(b_0s^j=s^i b_{-1}\). For \(b\in R\) the possibilities on the modules have lifts
\[
 \begin{aligned}
 j<i:&\qquad (b_0,b_{-1})=(s^{i-j}b,b),\\
 j>i:&\qquad (b_0,b_{-1})=(b,s^{j-i}b).
 \end{aligned}
\]
Precomposition multiplies the Ext representative by \(b_{-1}\) and takes its class in \(T_i/s^j T_i\). For \(j<i\), \(bs^{i-1}\in s^jT_i\) after reduction in \(T_i\). For \(j>i\), \(bs^{j-1}=0\) in \(T_i\). The only other shift from which a map to \(T_i\) can be nonzero is \(T_j[-1]\). Its composite with \(e_i\) lies in \(\operatorname{Ext}^2_R(T_j,T_i)=0\). Free probes and their shifts also give zero because \(\operatorname{Ext}^1_R(R,T_i)=0\) and \(R\) is projective. The identity of \(T_i\) reads \(e_i\) itself. The same arrow vanishes on cohomology and after every scalar covector \(T_i[1]\to Q[j]\), since \(\operatorname{Ext}^1_R(T_i,Q)=0\). Its full derived dual is nonzero by biduality.

Let \(k\) generate the kernel of the extension represented by \(e_i\), and let \(y\) lift the generator of the quotient. Its relations are \(s^ik=0\) and \(s^iy=s^{i-1}k\). The relation matrix has determinant \(s^{2i}\), and the ideal of its entries is \((s^{i-1})\). Its middle module is therefore \(T_{i-1}\oplus T_{i+1}\). For \(i=1\) this returns the nonsplit middle \(T_2\). For \(i=L\) the middle has a summand of thickness \(L+1\). The bound is on the cohomology of the source of the tested arrow. All resolutions in the proof are over \(R\).
:::

For an ordinary multilinear operation between finite free marked algebras, one can instead prepare input basis words and pair the output with a further word using its trace. The [mixed readings in an integral word basis](17-holographic-reconstruction.md#ch17-mixed-marked-operations) require integral word generation and a generically nondegenerate tracial pairing. To use either test on physical fields one must realise the indicated preparations and compare their operations with the field maps. Higher collision homotopies and the amplitude of an independently prepared filling require further comparisons.

An inverse along a one-parameter family requires an additional choice when several positions coincide. To see what restriction to such a family can lose, take two equations \(x=y=0\) for the total diagonal in a formal three-parameter model with ring \(A=\mathbb C[[x,y,h]]\). Fix the ray
\[
 A\longrightarrow S=\mathbb C[[s]],\qquad x,y\longmapsto0,\qquad h\longmapsto s^m,\quad m\geq1 .
\]
Let \(G\subset L\) be free \(A\)-lattices of the same finite rank \(r\). Require their inclusion to be injective over \(\mathbb C((s))\) **on this ray**. An inclusion given by multiplication by \(x\), for instance, becomes zero there. Write \(a_1,\ldots,a_r\) for the Smith exponents of the resulting inclusion over \(S\), including zero exponents. The quotient \(L/G\) on the ray has length \(\sum_j a_j\). Can this number detect a change at the closed point?

::: proposition {#ch05-total-diagonal-ray title="The lattice and its quotient on a total-diagonal ray"}
Write \(\mathfrak m=(x,y,h)\). Replace \(G\) by \(G_t=\mathfrak m^tG\), \(t\geq1\), and put \(C_t=L/G_t\). Away from the closed point this replacement leaves the inclusion unchanged. Put \(Q_m=S/(s^m)\), \(u_t=t(t+3)/2\) and \(v_t=t(t+1)/2\). In homological degrees the derived restriction of the lattice has groups
\[
 \begin{aligned}
 G_t\otimes_A S&\simeq S^r\oplus Q_m^{\,r u_t},\\
 \operatorname{Tor}_1^A(G_t,S)&\simeq Q_m^{\,r v_t}.
 \end{aligned}
\]
The splitting in degree zero is a choice of \(S\)-modules. The image in \(G\otimes_A S\) is \(s^{mt}(G\otimes_A S)\). For the quotient the groups are
\[
 \begin{aligned}
 C_t\otimes_A S&\simeq\bigoplus_{j=1}^r S/(s^{a_j+mt}),\\
 \operatorname{Tor}_1^A(C_t,S)&\simeq Q_m^{\,r u_t},\\
 \operatorname{Tor}_2^A(C_t,S)&\simeq Q_m^{\,r v_t}.
 \end{aligned}
\]
Higher groups vanish in each display. The alternating sum of the lengths for \(C_t\) is \(\sum_j a_j\), the same as for \(L/G\).
:::

::: proof {#ch05-proof-total-diagonal-ray}
First set \(x=y=0\), which gives \(B=A/(x,y)=\mathbb C[[h]]\). Resolve \(B\) by the Koszul complex on \(x,y\). Over \(P=\mathbb C[[x,y]]\), the quotient \(A/\mathfrak m^t\) is the sum of \(h^jP_{t-j}\) for \(0\leq j<t\), where \(P_d=P/(x,y)^d\). Give each Koszul generator internal degree one. For \(P_d\) its first Koszul homology is \((x,y)^d/(x,y)^{d+1}\), by the exact sequence of the ideal \((x,y)^d\). It has dimension \(d+1\) in degree \(d\). The second homology consists of the monomials of degree \(d-1\) times the top Koszul generator, so has dimension \(d\) in degree \(d+1\). Multiplication by \(h\) passes from \(P_d\) to \(P_{d-1}\) by the degree-preserving quotient and kills the last summand. In each positive homological degree the source and target are concentrated in different internal degrees. Thus \(h\) kills this homology. Summing over \(1\leq d\leq t\) gives \(u_t\) and \(v_t\) copies of \(B/(h)\), respectively. Degree zero gives \(B/(h^t)\).

Now \(S\) is free over \(B\) on \(1,s,\ldots,s^{m-1}\). Under this flat base change a copy of \(B/(h)\) becomes \(Q_m\). The degree-zero quotient becomes \(S/(s^{mt})\). Apply the long exact Tor sequence to \(G_t\subset G\) with quotient \((A/\mathfrak m^t)^r\). In degree zero the extension by \(Q_m^{r u_t}\) splits over the free image \(s^{mt}(G\otimes_A S)\). Apply the sequence again to \(G_t\subset L\). Its torsion maps to zero in \(L\otimes_A S\), and the free image injects there by the hypothesis on the ray. Multiplication by \(s^{mt}\) adds \(mt\) to each original Smith exponent. This gives the displayed groups. Since \(u_t-v_t=t\) and \(Q_m\) has length \(m\), the higher groups cancel the extra \(rmt\) in the alternating sum.
:::

For \(t=1\) the modified lattice on the ray already has \(2r\) torsion summands in degree zero and \(r\) in degree one, each of length \(m\). Specialising directly to the closed point \(k=A/\mathfrak m\) gives a different reading. The exact sequence \(\mathfrak m\subset A\) and the Koszul resolution of \(k\) on \(x,y,h\) give dimensions \(3r,3r,r\) in homological degrees \(0,1,2\) of \(\mathfrak mG\otimes_A^{\mathbf L}k\).

To use an inverse reading in field theory one must supply the state spaces with their integral preparations and covectors, the attaching maps in those frames, and the collision prescription that gives their ordered contraction. A comparison with a filling also requires its independently prepared state and the map carrying the contraction to its amplitude.

The support theorem identifies the complexes on which a product can take values. To express cobar multiplication on these supported coefficients, concatenate two words and use the inverse factorisation maps to join their coefficients on the separating open. The unit lies at the empty configuration. To insert a vacuum at an occupied point on the curve requires additional data. A **vacuum marking** identifies the singleton coefficient \(A_{\{1\}}\) with \(\omega_X\otimes_{\mathcal O_X}G\), where \(\omega_X\) is the canonical line of the curve and \(G\) is a left differential module, and specifies a horizontal map \(\mathcal O_X\to G\). A **vacuum framing** also compares the configuration operations with simultaneous field products, preserving substitutions, translation and the vacuum.

On the [full ordered collision atlas](04-factorization.md#ordered-cut-geometry), the symmetric convolution sums over all ordered decompositions. An associative chiral algebra for this convolution again requires factorisation of its bar. Now *each* specified coproduct component must be an equivalence. For \(C=BA\) on the two-point distinct locus \(U\), the first coproduct identifies \(C_{\{1,2\}}|_U\) with \(V=(C_{\{1\}}\boxtimes C_{\{2\}})|_U\), the external product of the singleton at \(z_1\) with the singleton at \(z_2\). The [two-channel cobar](#ch05-binary-cobar-channels) then computes the restriction of the augmentation ideal of \(A\). In higher arity the [flag calculation](#ch05-separated-flag-cobar) applies when the iterated identifications agree over every refinement.

Small-diagonal support on this atlas has a different criterion. On the fully distinct locus, take *all* iterated singleton coproducts together as one map from \(C_I\) to the direct sum of the ordered external products of its singleton coefficients, one summand for every order of the labels in \(I\). Joint word factorisation requires this map to be an equivalence for every nonempty \(I\).

To compute the cobar of physical probes from their flags, one needs a complex of states or observables for each prepared set of lines, the maps for the allowed assemblies and the homotopies comparing their iterates. On distinct points the maps from the uncut preparation must give the coherent identifications in the theorem. At a collision one must also specify the extension, its contact terms and the comparison of each cut with the corresponding localisation. A crossing of two lines gives a scalar with its own normalisation.

In flat rational abelian four-dimensional Chern–Simons theory on \(\mathbb R^2\times\mathbb C\), take the trivial background, the one-form \(dz\), unit invariant pairing, decaying propagator and fixed framing. Trivialise the field at spectral infinity and fix the external end frames, with gauge variations vanishing there. Orient the plane by \(ds\wedge dt\). Take the complete \(s\)- and \(t\)-axes, oriented in the increasing directions. Place the first line at \(z_1\) with ordinary scalar charge \(p\) and the second at \(z_2\) with charge \(q\). Divide their joint expectation by the individual line expectations at the same regulator. For a positive perpendicular crossing at nonzero spectral separation \(w=z_1-z_2\), the mixed contraction in plane coordinates \(s,t\) is
\[
 \hbar pq\int_{\mathbb R^2}
    \frac{\bar w\,ds\,dt}{\pi(s^2+t^2+|w|^2)^2}
 =\frac{\hbar pq}{w}.
\]
Indeed the radial integral of \(2r/(r^2+|w|^2)^2\) is \(1/|w|^2\). The gauge field is Gaussian, so Wick contraction gives the normalised expectation \(\exp(\hbar pq/w)\) as a formal series in \(\hbar\). If the two oriented lines are instead parallel, the plane area form vanishes on their two tangents. Their mixed contraction is zero and their normalised expectation is one. Can the crossed reading itself supply a collision extension? Suppose that the two order charts have fixed holomorphic line frames \(e_1,e_2\) at their collision origins, with \(e_2=S e_1\) on the overlap for \(S=\exp(\hbar pq/w)\). Write \(\nabla e_i=A_i e_i\) for connection one-forms in those frames. Then
\[
 A_2-A_1=d\log S=-\frac{\hbar pq}{w^2}\,dw .
\]
If \(pq\ne0\), the double pole already at first order rules out two regular connection forms in these fixed frames. The crossing thus gives a test of a proposed extension. To identify a physical cobar one still needs the actual collision coefficients and their compatible maps for every retained refinement. [Costello, Witten and Yamazaki, *Gauge Theory And Integrability, I*, §4, equations (4.4)–(4.14)](https://arxiv.org/pdf/1709.09993#page=32) · [The marked boundary cap](11-states-and-lines.md#ch11-boundary-insertions-and-the-physical-cap)

Two different units occur already on these coefficients. For convolution the coaugmentation is a map from \(k\) at the empty configuration. For the coefficientwise extraordinary tensor the unit has \(n\)-point coefficient \(\omega_{X^n}[n]\) on a curve. A map from this second system to a coalgebra, with its compatible insertions, specifies what happens when a vacuum occupies a position. For the current \(J\) at scalar level \(k_0\ne0\), the mode with index one satisfies \(J_{(1)}J=k_0\mathbf1\). A unital map of field algebras to the scalar field algebra would preserve this mode. Scalar fields have no double pole, so it would send the left side to zero and its right side to \(k_0\). Projection to the vacuum coefficient is a linear functional. Preservation of field products is a stronger condition that fails on this pair.

To recognise fields from configuration coefficients, an occupied vacuum must be available even when labels change order or coincide. Work over a characteristic-zero field \(k\) on \(X=\mathbb A^1_k\), with coordinate \(z\). Take an \(E_1\)-coalgebra for the chiral tensor on the full Ran space, with one \(X^I\) for each nonempty finite label set \(I\). Its coefficients \(C_I=L_I[|I|]\) are shifts of ordinary right differential modules. Every surjection carries a coherent extraordinary collision isomorphism. For each ordered bipartition, the coproduct is an equivalence on the open where its blocks are disjoint.

On distinct points, iterating the coproduct in the standard label order identifies the coefficient with the external product of the one-point modules. The collision isomorphisms put the extraordinary restriction of \(L_I\) to a proper diagonal in strictly positive cohomological degree. Thus no section of \(L_I\) is supported there. Restriction embeds \(L_I\) in the direct image of the separated coefficient from the distinct locus. A nonzero occupied vacuum has insertion maps for every subset. They compose, respect relabelling and factorisation, and retract to the identity under any collision that retains one label in each fibre.

The translation data include an operator \(D\) on the global one-point sections \(\Gamma(L_1)\). It obeys \(D(fa)=f'a+fD(a)\) for scalar polynomials \(f\), commutes with the constant vector-field action, is locally nilpotent and kills the vacuum. In the separated frame just described, simultaneous translation must preserve the image of every \(L_n\).

::: theorem {#ch05-field-recognition title="Field recognition on the affine line"}
The coalgebras with these collision, vacuum and translation data are equivalent to quantum vertex algebras with nonzero vacuum whose exchange \(\mathcal S(u)\) and its inverse have finite Laurent expressions on each state tensor. Here \(u\) is the difference of two field positions.
:::

To recover the states of a coalgebra, take the sections constant for \(D\). A global one-point section \(v\) has constant part
\[
 P(v)=\sum_{j\ge0}\frac{(-z)^j}{j!}\,D^jv .
\]
For a horizontal section \(a\), so \(Da=0\), the formula gives \(P(za)=za-zD(za)=0\) and \(P(a)=a\). Thus it selects the constant coefficient of a linear polynomial in \(z\). For a general section the sum is finite by local nilpotence. Differentiating \((-z)^j/j!\) in the \(j\)-th summand cancels the term obtained by differentiating \(D^{j-1}v\) in the preceding summand. Hence \(P(v)\) belongs to \(V=\ker D\).

To reconstruct \(v\), form \(\sum_{j\ge0} z^jP(D^jv)/j!\). After inserting the definition of \(P\), the coefficient of \(z^mD^mv\) is \(\sum_{j=0}^m(-1)^{m-j}/(j!(m-j)!)\). This is one at \(m=0\) and zero for \(m>0\), by the binomial theorem. Conversely, differentiating a polynomial relation among horizontal sections sufficiently many times gives its top coefficient times a nonzero factorial. These two calculations identify \(\Gamma(L_1)=k[z]\otimes V\). The right action of the constant vector field gives the state translation \(Ta=-a\partial_z\) on \(V\).

The two-point coefficient \(L_2\) specifies which sections over separated points extend across their diagonal. Write \(u=z_1-z_2\), let \(\Delta\) include the diagonal and let \(j\) include its complement. In the localisation triangle the collision isomorphism \(\Delta^!C_{\{1,2\}}\simeq C_{\{1\}}\) identifies the supported term. Since the unshifted \(L_I\) are ordinary modules, the binary boundary gives a surjection \(\alpha:j_*j^*(L_1\boxtimes L_1)\to\Delta_*L_1\) with kernel \(L_2\). Thus \(\alpha\) takes the full principal part on the diagonal.

In the density frame \(dz\), \([u^{-1}]\) extracts the simple pole. For states \(a,b\), the formula \(a_{(m)}b=[u^{-1}]\alpha(u^m;a,b)\) recovers every mode. For \(m=-1\), multiplying the field by \(u^{-1}\) makes its regular constant coefficient a simple pole. Multiplication by \(u^m\) extracts the coefficient of \(u^{-m-1}\) in the same way. Comparing the two ordered binary coproducts gives \(\mathcal S_{21}(-u)=\mathcal S(u)^{-1}\). Agreement of successive adjacent collisions gives weak associativity. The three collision channels give locality with a clearing power independent of the spectator, and passing a field across a collision gives the exchange hexagon.

Conversely, start with the fields and their exchange. On \(n\) distinct points take the external state coefficient. To test extension across a pair diagonal, bring the pair together in the chosen order by adjacent exchanges and take the full principal part of its field product with the given multiplier. The intersection of the kernels of these pair residues gives the lattice of extending sections. On a disjoint bipartition the cross-pair conditions disappear, giving the separation maps. Skew-symmetry identifies the two orders within a colliding pair. The hexagon gives compatibility with a spectator, and the vacuum identities give the insertion retractions. These are the collision and vacuum maps in the reverse construction. Between existing such objects, a unary isomorphism preserving translation, vacuum, binary lattice, boundary and exchange therefore extends uniquely.

The equivalence also holds over a commutative local Artinian \(k\)-algebra with residue field \(k\), with flat \(L_I\) on the geometric side, a flat state module and a vacuum spanning a free direct summand on the field side. In the residue construction the terms and successive kernels are flat, so the lattice construction commutes with scalar extension. For compatible systems over \(k[\hbar]/(\hbar^N)\), the Laurent bounds may depend on \(N\) and on the input.

For formal recognition, begin at each precision with a fixed free even state frame, its vacuum, its translation \(T\) and a *contact* on that frame. The contact is a translation-invariant map of right differential modules taking a two-point input to its full principal part. Write \(\mu(f;a,b)\) for its value on a Laurent multiplier \(f\) and states \(a,b\), and \(\operatorname{pp}_u\) for the polar part in \(u\). For the vacuum \(\mathbf1\) its two prescribed values are \(\operatorname{pp}_u(fa)\) on \((\mathbf1,a)\) and \(\operatorname{pp}_u(fe^{uT}a)\) on \((a,\mathbf1)\). The finite-Laurent exchange and its inverse fix the vacuum slots. The exchange is the identity modulo \(\hbar\) and satisfies the shift, unitarity and Yang–Baxter identities. The contact hexagon holds on two independent output states, with the inner separation expanded at zero while the outer separation is invertible. The signed three-channel identity holds with all normal derivatives.

For a fixed pair of states, clear the pole of their field product and the finitely many poles of their exchange coefficients. The first collision channel then has zero principal part. The other two channels give the two orders of the fields on any spectator, with the same clearing power. The moments \([u^{-1}]\mu(u^m;a,b)\) therefore satisfy locality uniformly in the spectator. Taking moments of the contact hexagon gives the field hexagon. With compatible reductions these moments recover an exact Etingof–Kazhdan quantum vertex algebra. In the other direction, taking \(\operatorname{pp}_u(fY(a,u)b)\) recovers the given contact.

Can the two-point field alone supply the exchange? At the word \((x,y,x)\), with \(y\ne x\), neither consecutive cut is available. The following family varies the extension along the outer collision while keeping the binary field fixed.

::: example {#ch05-outer-pair-exchange title="A binary field with different outer collisions"}
For \(c\in k^\times\), take the cut coalgebra with state algebra \(B=k[\epsilon]/(\epsilon^2)\), zero translation and constant binary field \(Y(a,u)b=ab\). Its coefficients are rational sections with poles along pair diagonals. At each pair the allowed polar coefficients lie in the kernel of the map identifying that pair. On a basis tensor of \(1\)'s and \(\epsilon\)'s this map moves the right endpoint to the left and drops the right slot. If both endpoints carry \(\epsilon\) it gives zero. If only the right endpoint carries \(\epsilon\), each intervening \(\epsilon\) contributes a factor \(c\). If the right endpoint carries \(1\), the other slots retain their values. On a cut open the cross-pair differences are invertible, leaving the same conditions within each block.

In particular, when \(z_1=z_3\) and the middle point stays away, the simple-pole numerators lie in \(\ker q^c_{13}\), where \(q^c_{13}:B^{\otimes3}\to B^{\otimes2}\) leaves the fused slot first and the spectator second. Put the vacuum \(1\) in one outside slot and then in the other. The two evaluations are
\[
\begin{aligned}
 q^c_{13}(\epsilon\otimes\epsilon\otimes1)&=\epsilon\otimes\epsilon,\\
 q^c_{13}(1\otimes\epsilon\otimes\epsilon)&=c\,\epsilon\otimes\epsilon .
\end{aligned}
\]
In the binary coefficient \(1\otimes\epsilon-\epsilon\otimes1\) is an allowed pole numerator because its product is zero. Move the middle \(\epsilon\) past the first input of this binary relation. The crossing fixes the vacuum slot. Write \(v\in B^{\otimes2}\) for its value on \(\epsilon\otimes\epsilon\). The crossed numerator is \(1\otimes\epsilon\otimes\epsilon-v\otimes1\). The second evaluation above gives \(c\,\epsilon\otimes\epsilon\) on the first term, while \(q^c_{13}(v\otimes1)=v\). Thus the numerator lies in \(\ker q^c_{13}\) exactly when \(v=c\,\epsilon\otimes\epsilon\). Reversing this crossing uses its inverse and gives \(c^{-1}\) on the same tensor. Unitarity of a full exchange would force \(c=c^{-1}\). Thus \(c=2\) gives a cut coalgebra with the same binary field as \(c=1\) and no such full exchange. For \(c=1\) the crossing fixes every state tensor. For \(c=-1\) it contributes a minus sign for each pair of \(\epsilon\)'s crossed. Both rules extend in every arity, giving exactly the intervening factors in the pair maps.
:::

More general cut lattices can agree with the constant-exchange field object through any prescribed arity and first fail at a later collision. In the same pair test, one may replace the power of \(c\) by a weight depending on the number of intervening \(\epsilon\)'s. If the weight is \(1\) except at a count \(r\ge2\), where it is \(2\), the first changed pair can occur only on \(r+2\) labels. Its outer-pair condition then distinguishes the two lattices.

There are two ways to dualise the geometric bar. For bounded holonomic coefficients, Verdier duality sends the cut coproduct with \(j_*\)-extension to multiplication with \(j_!\)-extension. It sends extraordinary collision pullbacks to ordinary ones, giving an algebra for the dual transition maps. Pointwise cochain duality paired with the occupied vacuum instead gives multiplication formed with \(j_*\). The comparison between the two open extensions has the normal links calculated in [Chapter 4](04-factorization.md#ch04-normal-link) when the open and coefficients agree with that fully distinct Betti problem. A word cut allows collisions inside each block. Its comparison requires the link for that open.

## Rational exchange on all finite collision diagrams {#ch05-rational-exchange-diagram}

To identify labels \(1,3\) while \(2\) remains separate, one must bring the outside fields past the middle one. The cut example shows why this exchange has to be supplied. Work over a commutative \(k\)-algebra \(R\), with \(k\) a characteristic-zero field, and on the affine line \(U\) with finitely many \(k\)-rational points removed. Take an ordinary flat \(R\)-module of states \(V\), a vacuum spanning a free direct summand and a translation \(T\). Write \(Y(a,u)b\) for the lower-truncated field obtained by inserting \(a\) at displacement \(u\) from \(b\). Assume the vacuum, translation and weak associativity identities.

Suppose the exchange \(\mathcal S(z)\) and its inverse have finite Laurent expressions on each state tensor and fix the vacuum slots. Let \(T_1,T_2\) act by translation on the first and second inputs. The shift identities are \([T_1,\mathcal S(z)]=-\partial_z\mathcal S(z)\) and \([T_2,\mathcal S(z)]=\partial_z\mathcal S(z)\). Unitarity identifies the reverse exchange at opposite separation with the inverse. The Yang–Baxter identity identifies the two ways to reverse three slots. Assume field locality and the exchange hexagon. The latter identifies moving a spectator past a product with crossing its two factors successively. These identities hold over \(R\) itself, including on coefficients that vanish after passage to residue fields.

Assign a coordinate \(z_B\) to every block \(B\) of a partition of a finite label set \(I\). On the distinct-block locus take the external tensor product of the state modules over the ring of regular functions there. This ring inverts all differences \(z_B-z_{B'}\) between distinct blocks. Push the resulting coefficient forward along the partition diagonal. This retains every finite derivative of the delta section in the normal directions. These are the **Cousin coefficients**. For instance the summand indexed by \(13|2\) has two distinct block positions, the first representing both labels 1 and 3. A spectator can cross one of those labels before they coincide.

In the associative cobar a word groups the blocks into successive nonempty factors. Its differential splits a factor or merges two blocks inside it. Label two blocks \(a<b\) and keep the position of \(b\) in their merger, denoting the merged block by \(m\). Put \(X_{ab}=\mathcal S_{ba}(z_b-z_a)\) for exchange on the fixed labelled slots. Write \(r^\circ_{ab}\) for the map taking the full principal part of the multiplier times the product of the two fields, expanded at the surviving position. For an unsplit two-block factor with coefficient \(x\), the boundary has two word terms and a term on the merged support,
\[
 x[a][b]-(X_{ab}x)[b][a]-(r^\circ_{ab}x)[m] .
\]
The first two terms are the two orders of the separated blocks. In the last term the product on state inputs \(a,b\) is \(Y(a,z_a-z_b)b\), with the letters here also denoting the states in those slots. A multiplier depending on a spectator must itself be expanded at the surviving position before taking the polar part. For example, let \(u\) be the collision coordinate and \(d\) a nonzero spectator difference. Multiplying a double pole by \(1/(d+u)\) gives
\[
 \frac{1}{u^2(d+u)}=\frac{1}{d\,u^2}-\frac{1}{d^2u}+O(1).
\]
Here \(O(1)\) is regular in \(u\). The leading coefficient \(1/d\) multiplies the double pole. The first derivative of the spectator multiplier contributes \(-1/d^2\) to the simple pole. Dropping the spectator before forming the principal part would miss this term. Moving the surviving position transfers the entire normal distribution with its orientation.

::: example {#ch05-chamber-graph-and-contact title="The incoming colour at an exchange wall"}
Keep two distinct spectral marks \(z_i,z_j\) fixed, in that incoming order, and prepare a colour in \(W\otimes W\), where \(W=\mathbb C^N\) with \(N\geq2\). Write \(u=z_i-z_j\), so the opposite separation is \(-u\). Let \(h\) be the deformation parameter and \(P\) the interchange of colours in fixed labelled slots. Choose the scalar of the rational exchange to fix symmetric tensors. In the convention with a pole at \(u=h\) the fixed-label operator is
\[
 R_-(u,h)=\frac{uI-hP}{u-h}=R_+(-u,h),
 \qquad R_+(u,h)=\frac{uI+hP}{u+h}.
\]
This is the fixed-label sign in Rimányi, Tarasov and Varchenko, *Partial flag varieties, stable envelopes and weight functions*, §2.8, equation (2.7). Writing the result in the outgoing tensor order adds the slot flip. At fixed \(u\ne0\) there is a formal expansion in \(h/u\). To test regularity on a wall, keep \(u,h\) as independent variables and use the displayed rational maps.

Let \(L=\mathbb C[u,h]\otimes W^{\otimes2}\) and \(L_\pm=(1\pm P)L/2\). An integral input belongs to the common graph, viewed in its incoming frame, when its exchanged output is integral too. The eigenvalues of \(R_-\) are \(1\) and \((u+h)/(u-h)\). Since \(u+h\) and \(u-h\) have no common irreducible factor, the incoming lattice is \(L_+\oplus(u-h)L_-\). Multiply the exchange by the rational scalar \((u-h)/(u+h)\), whose value at \(-u\) is its inverse. The alternating eigenvalue becomes one and the symmetric eigenvalue acquires the denominator \(u+h\). The incoming lattice in the same bases is now \((u+h)L_+\oplus L_-\).

With a spectator the pair \(13\) must first be made adjacent. In the incoming order \(123\), take the standard two-dimensional permutation representation, written as triples modulo constant triples. Use the differences \(d=v_1-v_2,\ e=v_2-v_3\) as colour coordinates and \(x=z_1-z_2,\ y=z_2-z_3\) as spectral coordinates. Cross \(12\) first by \(R_-(x,h)\). In order \(213\) the outside labels are adjacent. The cut \(2|13\) separates the spectator when \(z_2\) differs from both their marks. The resulting difference between components 1 and 3, multiplied by \(x-h\), is \(xd+(x-h)e\). The wall of this next exchange is \(x+y=h\), whereas the field merger is supported at \(x+y=0\). Take \(h=1,\ x=3,\ y=-2\) on the exchange wall. The input \((d,e)=(2,-3)\) has \(d+e=-1\) in the incoming frame, but its transported numerator \(3d+2e\) vanishes. This tests a polynomial divisibility condition at the wall. Evaluating the rational crossing itself there would divide by zero.
:::

For the normalisation \(R_-\), let \(L\) now be the free lattice of polynomial pairs \((d,e)\). The inputs that remain integral in every order form a free sublattice \(G\subset L\). In coordinates \(d,e\), its two columns are \((x-h,y-h)^t\) and \(((x-h)(x+y-h),0)^t\). The [integral chamber graph](12-chiral-quantum-groups.md#ch12-integral-exchange-lattice) gives their derivation. On the [total-diagonal ray](#ch05-total-diagonal-ray) with \(x=y=0,\ h=s^m,\ m\geq1\), the least entry valuation is \(m\) and the determinant has valuation \(3m\). The inclusion remains generically injective and its Smith exponents are \(m,2m\). Work in the completed relative ring \(\mathbb C[[x,y,h]]\) and replace \(G\) by \((x,y,h)G\). The lattices agree away from the closed point, hence give the same separated exchange. For the quotient by the modified lattice the ray calculation at \(t=1,\ r=2\) gives
\[
 H^0\simeq S/(s^{2m})\oplus S/(s^{3m}),\qquad
 H^{-1}\simeq Q_m^4,\qquad H^{-2}\simeq Q_m^2 ,
\]
where \(S=\mathbb C[[s]]\) and \(Q_m=S/(s^m)\). Its alternating length is still \(3m\). On the different ray \(x=3h,\ y=-2h,\ h=s^m\), the second column of the original inclusion is identically zero and its first is \((2h,-3h)^t\). Here \([G\to L]\) on the ray has \(H^{-1}=S\) and \(H^0\simeq S\oplus S/(s^m)\). In both cases the integral inclusion is formed before its derived restriction to the ray.

The signed boundary above uses the exchanged word and a distribution supported at the merger, with the position of \(b\) retained. The chamber graph constrains the exchange on fixed-label tensors. Its shifted pole leaves the finite Laurent and field locality hypotheses above to be established for any proposed field model. The two lattices with identical separated exchange give different supported quotients, and the [composition of marked inverses](#ch05-composing-marked-inverses) can detect even a regular coefficient discarded from an individual reading in \(\mathbb C((s))/\mathbb C[[s]]\). To identify the merger in a continuum theory one needs its renormalised contact distribution, with a specified scalar line, incoming and outgoing frames, and a comparison respecting the cut and the change of survivor.

The **Spencer complex** adjoins an exterior tangent vector \(e_i\) of degree \(-1\) at each label. Its differential contracts each tangent factor and applies the corresponding covariant derivative. On block \(B\), write \(T_B\) for state translation there, so the derivative is \(\nabla_B=\partial_{z_B}+T_B\). Denote by \(K(I)\) the total complex including the word differential. A surjection \(\alpha:I\twoheadrightarrow J\) gives a map \(K(J)\to K(I)\). It inserts the supported coefficient on the repeated labels and sends
\[
 e_j\longmapsto\sum_{\alpha(i)=j}e_i .
\]
For example repeating a block \(13\) sends its tangent to \(e_1+e_3\), the derivative for moving both labels together. Ordering the quotient labels by their largest preimages determines which adjacent exchanges to apply **inside each word factor**. Taking a maximum in two stages agrees with taking it once. Unitarity and Yang–Baxter identify different presentations of the same order change. If a pair changes order, its normal coordinate reverses and its surviving position changes. Transport its entire principal part, including the Taylor expansion of the spectators, to that new position. This change of survivor and the exchange hexagon make the transitions chain maps. For two disjoint sets of labels, concatenate a word from each complex and localise at all differences between their blocks. This gives an associative external multiplication compatible with the support maps. The empty set carries its own scalar \(R\). [Change of survivor and word order](13-geometric-reconstruction.md#ref-ch13-gr6)

For the interlaced partition \(13|24\), first multiply at the two block positions and then repeat each position. On the exterior tangent \(e_a\wedge e_b\) this gives
\[
 (e_1+e_3)\wedge(e_2+e_4).
\]
Doing the two repetitions first and then multiplying gives the same wedge. In either order the term \(e_3\wedge e_2\) has a minus sign when written with increasing indices. The two normal directions also interact in the coefficient of a pole. Put \(u=z_1-z_3,\ h=z_2-z_4,\ d=z_3-z_4\). The multiplier \(1/(z_1-z_2)\) becomes \(1/(d+u-h)\). The two block positions are separate, so \(d\) is invertible. In either normal coordinate principal parts are Laurent polynomials modulo regular terms. Thus both \(u^2\) and \(h^2\) annihilate \([u^{-2}][h^{-2}]\). The quadratic Taylor term \((u-h)^2/d^3\) contributes only \(-2uh/d^3\), and all higher terms vanish on this input. We can also expand first in \(u\). Its linear coefficient is \(-1/(d-h)^2\), whose term linear in \(h\) is \(-2h/d^3\). Both orders therefore give \(-2d^{-3}[u^{-1}][h^{-1}]\) as the mixed contribution. At any fixed normal order only finitely many Taylor terms survive.

Can passage to a residue field erase an exchange? Take the polynomial current \(J\) with Wick contraction \(P(d)=\kappa d^{-2}+\lambda d^{-1}\) over \(k[\kappa,\lambda]\), where \(d=z_a-z_b\). The difference of the contractions in opposite orders is \(P(d)-P(-d)=2\lambda/d\). On primary oscillator polynomials, \(\partial_J\) is differentiation in \(J\). The order change is the finite exponential of \((2\lambda/d)\partial_J\otimes\partial_J\). On \(J^2\otimes J^2\) the first derivatives give \(2J\) in each slot and the second derivatives give \(2\) in each slot, with exponential coefficient \(1/2!\). Thus
\[
 X_{ab}(J^2\otimes J^2)=J^2\otimes J^2+
 \frac{8\lambda}{d}J\otimes J+
 \frac{8\lambda^2}{d^2}\mathbf1\otimes\mathbf1 .
\]
Identifying labels 1 and 3 while 2 stays separate changes the root order on the two-block factor. Crossing before the identification or using the induced order afterwards gives this same operator, together with the orientation sign on the factor. Specialise to the dual numbers \(k[\epsilon]/(\epsilon^2)\) at \(\kappa=0,\lambda=\epsilon\), \(\epsilon^2=0\). The first correction survives. Passing to the residue field sets this coefficient of \(J\otimes J\) to zero. Thus exchange has to be checked over \(R\) itself.

After one identifies configurations along all surjections, which degree-zero operations on an open curve remain? Start with rational multipoint field coefficients. Multiply coefficients on disjoint label sets by concatenating the ordered inputs and retaining the poles allowed between them. The intrinsic all-arity mode algebra \(\mathsf M_U(V)\) is the quotient by translation derivatives and by the relations \(x-\sigma_i x-\rho_i x\) for neighbouring inputs in every arity, with arbitrary spectators. Here \(\sigma_i\) exchanges and relabels the pair, and \(\rho_i\) takes its supported simple residue after the full Taylor transfer to the surviving position.

Use chains of nonidentity surjections of nonempty finite label sets, including nonidentity bijections, with \(R\) on the empty set adjoined separately. For the single arrow \(J\xleftarrow{\alpha} I\), a coefficient \(y\in K(J)\) appears one degree lower. Its two faces give \(K(\alpha)y\) at \(I\) minus \(y\) at \(J\), and the internal differential on this shifted summand is \(-d_K\). In length \(p\), the first face transports the coefficient, an interior face composes two successive surjections and the last face drops the last arrow in the direction of transport. Take the alternating sum of faces starting with sign \(+\) for transport. The internal differential is \((-1)^p d_K\).

**Theorem (the algebraic collision integral).** Form \(G_U(V)\) by taking an algebraic direct sum over chains of surjections, placing a chain of length \(p\) in simplicial degree \(-p\), with the usual alternating face maps on the \(K(I)\). Shuffling two chains with their permutation and graded tensor signs and concatenating their coefficient words makes \(G_U(V)\) a unital dg algebra over \(R\). Its degree-zero cohomology is the intrinsic all-arity mode algebra \(\mathsf M_U(V)\).

::: proof {#ch05-proof-algebraic-collision-integral}
Let \(\mathcal D_n\) be the complex of rational coefficients on \(n\) distinct inputs with their Spencer tangents. The map \(\phi:\bigoplus_n\mathcal D_n\to G_U(V)\) inserts them in standard order as a word of singleton factors. Write \(\widehat\sigma_i,\widehat\rho_i\) for the exchange and the supported residue on these complexes, acting also on the tangents. For each adjacent pair there is a degree-minus-one homotopy
\[
 dh_i+h_id=\phi(1-\widehat\sigma_i-\widehat\rho_i).
\]
The boundary of the unsplit double factor gives an ordered product, its exchanged product, and the full principal part on the common support. In a normal coordinate \(u\), differentiation gives \(\partial_u[u^{-j}]=-j[u^{-j-1}]\) for \(j\ge1\). Thus every pole of order greater than one is a normal Spencer boundary. The contraction leaves the pushed-forward simple residue. The transposition and collision edges in the surjection diagram supply the changes of representative, giving the displayed homotopy on the whole Spencer complex. This argument uses the Taylor expansion of every spectator multiplier, including the \(-d^{-2}\) term just computed.

Conversely a boundary reaching degree zero starts in degree minus one. It can come from one tangent, one double factor or one diagram edge. These impose, respectively, a translation relation, an exchange with residue, or identification of a coefficient with its image under a surjection. After taking the quotient by the Spencer derivatives, only the simple normal residue remains in each normal direction. For a singleton word with \(r\) blocks, send each original label to the number of its block in word order. Under this surjection onto \([r]\), the given word is the support image of the standard word. Listing the blocks this way therefore induces a map back to \(\mathsf M_U(V)\), inverse to the map from the mode quotient.
:::

How much of the complex is visible before taking degree-zero cohomology? Filter \(G_U(V)\) by the number of labels. For \(r\) labels write \(\operatorname{Conf}_r U\) for the configurations of \(r\) distinct ordered points of \(U\). Their complex of coefficients is
\[
 \mathcal D_r=\mathcal O(\operatorname{Conf}_r U)\otimes_k
 V^{\otimes_R r}\otimes_R\Lambda^\bullet R^r
\]
with its Spencer differential. The group \(\Sigma_r\) permutes positions and tangents and transports states by exchange. In the cardinality-\(r\) layer a partition \(\pi\) that identifies any two labels already occurs on the smaller quotient by its blocks. This quotient is initial among the contributing proper quotients for \(\pi\), and their support maps induce quasi-isomorphisms on its Spencer coefficients. Thus only the discrete partition contributes to the layer. Its orders are the vertices of a permutohedron and their ordered groupings are its faces. For two labels the two orders are the endpoints of one interval. The polytope is contractible, so the augmentation of its cellular complex is a quasi-isomorphism to \(k\). The remaining layer is \((\mathcal D_r)_{\Sigma_r}\), the coinvariants for the exchange action just described.

The separate cardinality layers do not yet give a splitting of the complex. Consider two singleton blocks on \(U=\mathbb G_m\). Over \(R=k=\mathbb Q\) take the constant field algebra \(k\mathbf1\oplus ka\) with \(a^2=0\), \(T=0\), and \(a\) in cohomological degree zero. The exchange fixes vacuum slots and sends \(a\otimes a\) to \(-a\otimes a\). For \(x=(z_1z_2)^{-1}a\otimes a\) the merged field vanishes. The unsplit double factor therefore has boundary \(x[1][2]+x[2][1]\) in the original word coordinates. Express the second coefficient in the order \(1,2\). The exchange sends it to \(-x\), so a single field coefficient \(x\) now multiplies the scalar commutator \([1][2]-[2][1]\).

In the two-slot calculation, writing the coefficients in the same order left just the order of the scalar letters to vary. For the given \(U,R,V\), fix a partition \(\pi\) and retain all the poles between its blocks in the common coefficient. To compare words, order its blocks by their largest labels and call this order \(\omega\). A word \(w=(J_1,\ldots,J_q)\) groups those blocks into successive factors. Read each \(J_l\) internally in the order \(\omega\) and concatenate the lists to obtain \(\gamma_w\). Write \(\tau_{\nu,\gamma}\) for transport from order \(\gamma\) to order \(\nu\) by adjacent exchanges. On the coefficient of \(w\) apply \(P_w=\tau_{\omega,\gamma_w}\), leaving its determinant lines fixed.

In this common order the summand at \(\pi\) has the form \(C_\pi\otimes_k E_\pi\). Here \(C_\pi\) is the entire supported Cousin coefficient with its Spencer tangents. It includes poles between distinct blocks in different word factors and all finite normal derivatives. The scalar complex \(E_\pi\) has one word line for each ordered grouping. A group \(J\) contributes the letter \(t\det J\), its top exterior line \(\bigwedge^{|J|}k^J\) placed in degree \(1-|J|\). Each block occurs once in the word.

Give the scalar tensor algebra on these letters the unshuffle coproduct. It sends a letter \(\ell\) to \(1\otimes\ell+\ell\otimes1\) and extends multiplicatively with the graded tensor sign. An element with this two-term coproduct is called primitive. In particular the mixed terms cancel on the graded commutator of two primitive letters. After transport, splitting a group leaves \(C_\pi\) fixed. The two orders of each split combine to give precisely such a commutator in \(E_\pi\).

A merger also acts on the field coefficient. For example, put the three singleton blocks in the word \((\{1,3\},\{2\})\). In order \(1,2,3\), bringing \(1\) to \(3\) crosses the spectator \(2\) before taking the full principal part. In order \(1,3,2\) the merging pair is adjacent, but the merged field must then cross \(2\) to reach the output order \(2,3\). The exchange hexagon identifies the two calculations, including the Taylor transfer of the spectator multiplier. In general, merging \(i<j\) within a factor keeps \(j\) and deletes \(i\) from both orders. Write \(w'\) for the resulting word. The map \(r^{\mathrm{raw}}_{ij,w}\) takes the principal part in the grouped order from the coefficient of \(w\) to the merged support for \(w'\). Write \(r^\omega_{ij}\) for the same merger between the common coefficient orders on those two supports. The hexagon gives
\[
 P_{w'}\,r^{\mathrm{raw}}_{ij,w}\,P_w^{-1}=r^\omega_{ij}.
\]
Thus every word that allows this merger has the same coefficient map in the common order. Its scalar partner acts on a letter containing both blocks by minus contraction of its determinant with the covector dual to \(i\). It kills every other letter and extends to words by the graded Leibniz rule.

For a surjection \(\alpha:I\twoheadrightarrow J\), relabel the incoming blocks by their inverse images and include their supported coefficient. In the common orders, the two grouped orders cancel from the state transport. The incoming order induces an order \(\alpha^*\omega_{\rm in}\) on the inverse-image blocks. Transport from that order to the order by output maxima is \(\tau_{\omega_{\rm out},\alpha^*\omega_{\rm in}}\) for every word, with the induced relabelling on determinant lines. For example, if \(1,3\) map to \(A\) and \(2\) to \(B\), the fibre maxima order the output blocks as \(B,A\). An input ordered \(A,B\) requires one exchange, and its tangent \(e_A\) goes to \(e_1+e_3\). For an adjacent transposition the action on \(\mathcal D_r\) is the state exchange \(X_{i,i+1}\) followed by relabelling the positions and their tangents.

Over a characteristic-zero field \(k\), the Eulerian idempotent \(e^{(n)}\) on the scalar tensor algebra projects to symmetric degree \(n\) in its primitives. Here the convolution \(f\star g\) acts on endomorphisms of this tensor algebra. It unshuffles a word, applies \(f\) and \(g\) to the two subwords, and concatenates the results. Its unit \(\eta\) projects onto the empty word and includes it again. For \(J=\mathrm{id}-\eta\), the first projector \(e^{(1)}=\log^\star(\mathrm{id})\) is the sum \(J-J^{\star2}/2+J^{\star3}/3-\cdots\). On each word only finitely many terms survive, and \(e^{(n)}=(e^{(1)})^{\star n}/n!\) for \(n\ge1\).

A split sends a determinant letter to a sum of commutators of primitive letters. A signed merger takes a letter to another determinant letter, with its contraction sign, or to zero. Both are derivations taking primitive letters to primitives. They are therefore also coderivations of the unshuffle and commute with the Eulerian projectors. Relabelling the letters commutes with them as well. Thus \(1_{C_\pi}\otimes e^{(n)}\) respects the differential and the support maps in the common order. In the original word coordinates its action is \(P^{-1}(1_{C_\pi}\otimes e^{(n)})P\), where \(P\) applies \(P_w\) separately on each word.

On the discrete partition the permutohedral augmentation sends every singleton word to \(1\). To see its Eulerian degree, send the \(r\) singleton letters to distinct commuting variables and all larger letters to zero. Every singleton word maps to the same monomial, the product of the \(r\) variables, of symmetric degree \(r\). The permutohedron is contractible, so only \(e^{(r)}\) contributes to this layer. Averaging over \(\Sigma_r\) gives ordinary coinvariants for the exchange and tangent action above. Since the proper-quotient terms have already disappeared in each layer, a fixed projector can have nonzero cohomology only in its own cardinality. Taking the exact filtered union in the algebraic direct sum gives the additive splitting
\[
 G_U(V)\simeq R\oplus\bigoplus_{r\ge1}(\mathcal D_r)_{\Sigma_r}
 \qquad\text{as complexes}.
\]
The cardinality spectral sequence consequently degenerates on its first page. The splitting is additive. On passing the product to the mode quotient, the boundary of an unsplit double factor relates the two ordered products by \(\rho_i x\), a term of smaller cardinality.

Return to the constant square-zero field. Write \(A=[z^{-1};a]\) for the unary mode of the test function \(z^{-1}\) with state \(a\). In the surviving cardinality-one layer its coefficient has residue \(a\), since \(dz/z\) has residue one, whereas a derivative has zero residue. Thus \(A\ne0\) in degree zero. In the mode algebra the two relabelled terms of the double-factor boundary both represent \(A^2\), giving \(2A^2=0\). Since the ground field is \(\mathbb Q\), \(A^2=0\). An ordinary multiplicative coproduct declaring the even mode \(A\) primitive would take its square to \((A\otimes1+1\otimes A)^2=2A\otimes A\ne0\). The scalar unshuffle above acts on the determinant letters of \(E_\pi\). Its transported projectors act on the additive complex.

Adjoining the relation homotopies to the algebra of multipoint coefficients gives a dg algebra \(\mathcal P_U(V)\). Sending its coefficients to the standard singleton words and its relation homotopies to \(h_i\) defines \(\Theta:\mathcal P_U(V)\to G_U(V)\). The boundary calculation and the inverse by listing blocks show that this map induces the identity on \(\mathsf M_U(V)\) in degree zero. A comparison in negative degrees with an independent derived algebra of modes or a global geometric pushforward requires a map to that object. [Integration and field reconstruction](13-geometric-reconstruction.md#ch13-integrating-the-collision-diagram)

Even when the mode algebra is known, it can act on many representations. For an affine current algebra \(A\), fix a representation \(W\) used for induction. Maps from \(W\) to a second representation \(M\) detect the states that can occur as images of its generators. Write \(B=\operatorname{RHom}_A(W,W)^{\mathrm{op}}\) for the graded opposite of the derived endomorphism algebra. Precomposition gives \(\operatorname{RHom}_A(W,M)\) a right action of the endomorphisms and hence a left \(B\)-action. The same endomorphisms make \(W\) a right \(B\)-module in addition to its left \(A\)-action.

Evaluation \(W\otimes_B^{\mathbf L}\operatorname{RHom}_A(W,M)\to M\) is the counit of the tensor–Hom adjunction. In the other order the unit starts with a \(B\)-module \(L\) and takes it to \(\operatorname{RHom}_A(W,W\otimes_B^{\mathbf L}L)\). In degree zero it sends \(l\) to the map \(w\mapsto w\otimes l\).

Even for a single symmetry, the choice of \(W\) affects what evaluation can reach. If an involution acts trivially on \(W\), every equivariant map \(W\to M\) has image in the fixed subspace of \(M\). Which part of a current representation can be recovered when \(W\) is induced from its positive modes? [The two comparison maps](06-duality-and-induction.md#adjunction-comparison-maps)
