# Boundary observables and reconstruction

Suppose a quantum field is prepared in a half-space and only its boundary is accessible. Can measurements there distinguish two preparations with the same energy?

For a model of this boundary measurement, take a free current on a circle. Its independent oscillations are called harmonics. The first harmonic completes one cycle around the circle, the second two. Each harmonic gains energy in discrete steps above its unexcited state. A single excitation is called a quantum. Its energy is proportional to the frequency.

Two quanta of the first harmonic therefore have the same energy as one quantum of the second. Prepare a superposition of these alternatives by taking the normalised sum of their unit states. The coefficients of the two unit states are their amplitudes. On a fresh preparation take the normalised difference, reversing the sign of the second amplitude. Counting the quanta gives the same two pairs of counts, or occupations, each with probability one half in either preparation. Which observable lets the two alternatives interfere, so that its reading distinguishes the relative sign?

## Two preparations and one joint measurement {#ch01-two-preparations}

Keep the first two harmonics of the free current. Each positive harmonic is an independent oscillator. Leave all higher harmonics unexcited, in the state called the vacuum.

Measure energy above the vacuum in units of one quantum of the first harmonic. If the counts are \(m_1,m_2\), their energy is \(m_1+2m_2\). The only occupation pairs at energy two are \((2,0)\) and \((0,1)\). A joint measurement of the sign needs an operation that connects these two occupations.

How can the current add or remove one quantum? Its Fourier components act on the states of each harmonic and are called its modes. The *level* fixes the normalisation of these operations. For harmonic \(n\), subtract removal followed by creation from creation followed by removal. At level one this gives \(n\) times the identity.

**Definition (two-harmonic Fock space).** Use one formal variable \(p_n\) for each harmonic \(n=1,2\). Write \(1\) for the vacuum and \(p_1^{m_1}p_2^{m_2}\) for the state with \(m_n\) quanta of harmonic \(n\), where \(m_n\) is a non-negative integer. Finite superpositions form the polynomial space \(\mathbb C[p_1,p_2]\), with complex amplitudes as coefficients. Multiplication by \(p_n\) adds a quantum. Differentiation with respect to \(p_n\) removes one and counts how many could have been removed. With creation represented by multiplication, the level-one creation and annihilation modes are respectively
\[
J_{-n}=p_n\cdot(-),\qquad J_n=n\frac{\partial}{\partial p_n}\qquad(n=1,2).
\]
{#eq-two-harmonic-modes}
For example, \(J_2p_2=2\) gives twice the vacuum vector, while \(J_2p_1^2=0\). On a polynomial \(f\), adding a quantum and then removing one gives \(n\partial_{p_n}(p_nf)=nf+p_n n\partial_{p_n}f\). The last term comes from removing a quantum already present in \(f\). For operators \(A,B\) write \([A,B]=AB-BA\) for their commutator and \(\mathrm{id}\) for the identity. The calculation gives \([J_n,J_{-n}]=n\,\mathrm{id}\). Modes on different harmonics commute. [The free current](03-local-fields.md#heisenberg-current)

Starting at the vacuum, the two paths to energy two give \(p_1^2\) and \(p_2\). To assign probabilities to their sum we need their lengths and their inner product. For a real current the amplitude for adding a quantum is the complex conjugate of the amplitude for the reverse transition. The Fourier modes at opposite indices must therefore be adjoints in the polynomial inner product. Moving \(J_{-n}\) to the other side of the pairing gives \(J_n\).

**Lemma (occupation inner product).** With vacuum norm one and \(J_n\) adjoint to \(J_{-n}\), there is a unique positive Hermitian inner product on the polynomials. We take it conjugate-linear in the first entry. Different occupation monomials are orthogonal, and
\[
\bigl\|p_1^{m_1}p_2^{m_2}\bigr\|^2=m_1!\,2^{m_2}\,m_2!.
\]
{#eq-two-harmonic-norms}

*Proof.* For polynomials \(f,g\), adjointness gives \(\langle p_n f,g\rangle=\langle f,n\partial_{p_n}g\rangle\). Transfer the factors of the first monomial, one at a time, to derivatives on the second. If the first exponent of a given harmonic is larger, these derivatives kill the second monomial. If the second exponent is larger, interchange the two monomials using Hermitian symmetry. For equal exponents \(m_n\) the repeated derivative gives \(n^{m_n}m_n!\). The two factors multiply the vacuum norm squared, which is one.

Conversely, the positive diagonal entries in this formula and zero entries between different monomials give a Hermitian inner product. It satisfies the adjoint relation on monomials and hence on all polynomials. ∎

For the two paths from the vacuum the calculation gives \(\langle p_1^2,p_1^2\rangle=\langle1,J_1^2p_1^2\rangle=2\), \(\langle p_2,p_2\rangle=\langle1,J_2p_2\rangle=2\), and \(\langle p_1^2,p_2\rangle=\langle1,J_1^2p_2\rangle=0\). Completing the polynomials in this norm gives the two-harmonic Hilbert space. Its energy-two subspace has orthonormal basis
\[
a=\frac{p_1^2}{\sqrt2},\qquad b=\frac{p_2}{\sqrt2}.
\]
Thus \(a\) and \(b\) have the same energy and different occupation numbers in each harmonic. To describe a measurement on one harmonic, take a state \(f\) of the first and a state \(g\) of the second. Write \(f\otimes g\) for their product \(f(p_1)g(p_2)\). By the occupation lemma the inner product of two such states is the product of the inner products in the two harmonics. In this notation \(a=(p_1^2/\sqrt2)\otimes1\) and \(b=1\otimes(p_2/\sqrt2)\).

Prepare \(\psi=\alpha a+\beta b\) with \(|\alpha|^2+|\beta|^2=1\). By the squared-amplitude rule the two occupations have probabilities \(|\alpha|^2\) and \(|\beta|^2\). More generally, let \(B\) represent any measurement event on the first harmonic. It is positive and bounded by the identity, \(0\le B\le\mathrm{id}\), so its expectation on a unit state is a probability. On the two harmonic spaces together the event acts by \(A=B\otimes\mathrm{id}\), sending \(f\otimes g\) to \((Bf)\otimes g\).

The probability of this event is \(\langle\psi,A\psi\rangle\). The cross term \(\langle a,Ab\rangle\) contains the inner product \(\langle1,p_2/\sqrt2\rangle=0\) from the untouched second harmonic. Since \(A\) is self-adjoint, \(\langle b,Aa\rangle\) vanishes as well. Thus
\[
\langle\psi,A\psi\rangle=|\alpha|^2\langle a,Aa\rangle+|\beta|^2\langle b,Ab\rangle .
\]
Let \(C\) be the event operator for a measurement on the second harmonic alone. Its action on both harmonics is \(\mathrm{id}\otimes C\). Its cross term contains the first-harmonic inner product \(\langle p_1^2/\sqrt2,1\rangle=0\). In particular the normalised sum and difference
\[
u_\pm=\frac{a\pm b}{\sqrt2}=\frac{p_1^2\pm p_2}{2}
\]
{#eq-sum-and-difference}
give the same probabilities for every event confined to one harmonic. For a joint observable the off-diagonal entries can survive. Subtracting its expectation on the difference from its expectation on the sum gives twice the real part of its matrix element between \(a\) and \(b\). Choose the two off-diagonal entries to be one and the diagonal entries to vanish. This observable sends either unit vector to the other.

**Definition (exchange at energy two).** On the span of \(a,b\) let \(Sa=b\) and \(Sb=a\). The matrix of \(S\) in this orthonormal basis is real and symmetric. Its eigenvectors \(u_+,u_-\) have eigenvalues \(+1,-1\), respectively. Measuring this self-adjoint observable on a fresh preparation reads the sign with certainty. On a general unit state \(\alpha a+\beta b\) its expectation is \(2\operatorname{Re}(\bar\alpha\beta)\).

Which operation of the current measures this exchange? Removing a quantum of harmonic two from \(b\) and creating two quanta of harmonic one gives a multiple of \(a\). The reverse conversion gives a multiple of \(b\) from \(a\). Reading the modes from right to left gives \(J_{-1}^2J_2\) and \(J_{-2}J_1^2\). They are adjoints on polynomials. Their sum acts by
\[
\begin{gathered}
\begin{aligned}
O&=J_{-1}^2J_2+J_{-2}J_1^2\\
 &=2p_1^2\frac{\partial}{\partial p_2}
   +p_2\frac{\partial^2}{\partial p_1^2},
\end{aligned}\\[3pt]
O\,p_2=2p_1^2,\qquad O\,p_1^2=2p_2 .
\end{gathered}
\]
{#eq-energy-two-exchange}
In the first conversion the factor two comes from \(J_2=2\partial_{p_2}\). In the reverse conversion \(J_1^2p_1^2=2\) counts the two orders of removal. Both paths pass through the vacuum occupation \((0,0)\). The occupation monomials have equal norm, so both transitions keep their coefficient two in the unit basis. Adjointness pairs the conversions and the mode normalisation fixes their scale. On the energy-two subspace \(O=2S\), so \(O\) has the sharp readings \(+2\) on \(u_+\) and \(-2\) on \(u_-\).

One can also sample the shape of a real harmonic field on a disk. To obtain its joint reading \(C\), square the first harmonic amplitude and multiply by the conjugate of the second. Take twice the real part. Its mean can be compared with the sharp reading of \(O\).

::: figure fig-energy-two-exchange

How could a second system read the sign? Give an ideal detector two orthonormal states \(|0\rangle,|1\rangle\) and prepare it in \(|0\rangle\). Let its Hermitian operator \(Y\) send \(|0\rangle\) to \(i|1\rangle\) and \(|1\rangle\) to \(-i|0\rangle\). For a real, dimensionless interaction strength \(\theta\), couple the energy-two current space to the detector by \(U_\theta=\exp(-i\theta O\otimes Y/2)\). Write \(u_\sigma\) for the state with \(Su_\sigma=\sigma u_\sigma\), where \(\sigma=\pm1\). Since \(O=2S\) there and \(Y^2=1\), the coupling gives the detector state \(d_\sigma\) through
\[
 \begin{gathered}
 U_\theta(u_\sigma\otimes|0\rangle)=u_\sigma\otimes d_\sigma,\\
 d_\sigma=\cos\theta\,|0\rangle+\sigma\sin\theta\,|1\rangle .
 \end{gathered}
\]
At \(\theta=\pi/4\) the detector states \(d_+,d_-\) are orthogonal. Measuring in the basis \((|0\rangle\pm|1\rangle)/\sqrt2\) reads \(\sigma\) with certainty and leaves the prepared current state \(u_\sigma\) intact. With the same coupling and strength, counting in the basis \(|0\rangle,|1\rangle\) gives probabilities \(1/2,1/2\) for either preparation.

Can a sample of a field distinguish the same two states \(u_+,u_-\)? On the Euclidean unit disk \(D\) the measured object is the shape of a real harmonic field \(\phi\). Mark the centre and choose an angular coordinate, with complex disk coordinate \(z\). With the constant mode fixed to zero, write \(\phi=h+\bar h\), where \(h(z)=\sum_{n\ge1}Z_nz^n/n\). The measured harmonic amplitudes are \(Z_n\). In particular \(Z_1=h'(0)\) and \(Z_2=h''(0)\), since the quadratic term is \(Z_2z^2/2\).

To determine how often a shape occurs, first keep just \(N\ge2\) harmonics. Write \(h_N\) for the first \(N\) terms of \(h\) and \(\phi_N\) for the resulting real field. Then \(|\nabla\phi_N|^2=4|h_N'|^2\). On integrating over Euclidean area \(d^2z\), the angular integral kills terms from different harmonics. The Dirichlet action is therefore
\[
S_{D,N}=\frac1{8\pi}\int_D|\nabla\phi_N|^2\,d^2z=\frac12\sum_{n=1}^N\frac{|Z_n|^2}{n}.
\]
At the vacuum the disk assigns the amplitude \(e^{-S_{D,N}}\). Square it and normalise against the product of complex area measures \(\prod_{n=1}^N d^2Z_n\) to obtain the probability law. Its coordinates are independent, and each \(Z_n\) has circular complex Gaussian density \((\pi n)^{-1}e^{-|Z_n|^2/n}\). Integrating out one more coordinate multiplies the density of those already present by one. These consistent marginals define the product law \(\mu\) on all harmonics.

A typical sample from \(\mu\) has infinite action. Indeed, the independent variables \(|Z_n|^2/n\) have exponential laws of mean one, so \(S_{D,N}/N\to1/2\) almost surely. The first two amplitudes nevertheless have finite moments of every order. With \(\mathbb E_\mu\) denoting expectation under the vacuum law,
\[
\mathbb E_\mu\bigl[|Z_1|^{2m_1}|Z_2|^{2m_2}\bigr]=m_1!\,2^{m_2}\,m_2!,
\]
in agreement with the squared occupation norms. A mismatch of exponents in either harmonic leaves an angular phase whose average is zero. Thus substituting \(p_n\mapsto Z_n\) preserves the full polynomial inner product. By completion, a unit current state gives a holomorphic wavefunction \(F\) of squared integral one. Its disk preparation weights the vacuum law by \(|F|^2\). In particular \(u_\pm\) give the wavefunctions \(F_\pm=(Z_1^2\pm Z_2)/2\) and the densities \(|Z_1^2\pm Z_2|^2/4\) relative to \(\mu\).

Expanding the two squares shows what to measure on a single field sample. The pure terms \(|Z_1|^4\) and \(|Z_2|^2\) occur in both. Write \(\theta_n\) for the phase of \(Z_n\) when it is non-zero. The term that changes sign gives the real disk statistic
\[
C=2\operatorname{Re}\bigl(Z_1^2\,\overline{Z_2}\bigr)
 =2|Z_1|^2\,|Z_2|\cos(2\theta_1-\theta_2),
\]
{#eq-disk-reading}
which compares the phase of the second harmonic with twice the phase of the first, weighted by the strengths of both waves. The reading vanishes if either amplitude vanishes. Write \(\mathbb E_\pm\) for expectation in the respective prepared laws. Since \(|Z_1^2\pm Z_2|^2=|Z_1|^4+|Z_2|^2\pm C\), the mean reading is
\[
\begin{aligned}
\mathbb E_\pm C
 &=\tfrac14\,\mathbb E_\mu\bigl[(|Z_1|^4+|Z_2|^2)C\bigr]\\
 &\quad{}\pm\tfrac14\,\mathbb E_\mu[C^2]\\
 &=0\pm\tfrac12\,\mathbb E_\mu|Z_1|^4\,\mathbb E_\mu|Z_2|^2\\
 &=\pm2 .
\end{aligned}
\]
The first expectation vanishes on averaging over the phase of \(Z_2\). The squared cosine in \(C^2\) has angular average \(1/2\), which gives the second expectation. Averaging over either harmonic phase also removes the interference term from the other harmonic's marginal.

One disk reading varies from sample to sample. To find its second moment in either preparation, multiply \(C^2\) by the density \((|Z_1|^4+|Z_2|^2\pm C)/4\) and integrate against \(\mu\). Replacing \(Z_2\) by \(-Z_2\) preserves \(\mu\) and reverses \(C\), so the term in \(C^3\) integrates to zero. Averaging the squared cosine in the other two terms gives
\[
\begin{aligned}
\mathbb E_\pm C^2
 &=\tfrac12\,\mathbb E_\mu\!\left[|Z_1|^8|Z_2|^2+|Z_1|^4|Z_2|^4\right]\\
 &=\tfrac12(4!\cdot2+2!\cdot8)=32 .
\end{aligned}
\]
In the two preparations \(u_\pm\) the disk statistic has mean \(+2\) or \(-2\), respectively, and variance \(32-4=28\). On the same choice of sign the current observable \(O\) gives its eigenvalue with certainty.

Why do the means agree? In \(L^2(\mu)\), the space of square-integrable functions of the amplitudes, the disk wavefunctions form the closed span of the holomorphic polynomials. Let \(P\) project orthogonally onto this subspace.

Multiply \(Z_n^m\) by \(\bar Z_n\). When \(m\ge1\) its angular dependence agrees with just one holomorphic monomial in this variable, \(Z_n^{m-1}\). Pairing with this monomial gives \(\langle Z_n^{m-1},\bar Z_n Z_n^m\rangle=\|Z_n^m\|^2\). Dividing by \(\|Z_n^{m-1}\|^2\) gives the projection coefficient \(nm\). When \(m=0\) every such pairing vanishes.

Thus \(P(\bar Z_n F)=n\partial_{Z_n}F\) on holomorphic polynomials. For two conjugate factors in one variable the same moment calculation gives the square of the operator \(n\partial_{Z_n}\). Since the harmonics are independent, \(P(CF)=2Z_1^2\partial_{Z_2}F+Z_2\partial_{Z_1}^2F\). This is the action of \(O\) under \(p_n\mapsto Z_n\). For every holomorphic polynomial \(F\), pairing with \(F\) gives \(\langle F,P(CF)\rangle=\int C|F|^2\,d\mu\).

Which insertions in the interior of the half-space have this action? Write \(\hbar\) for the fluctuation scale and \(\kappa_{\mathrm b}\) for the bulk coefficient of the free theory. Their product is the boundary level, here fixed by \(\hbar\kappa_{\mathrm b}=1\).

Choose a smooth radial function \(\chi\) on the boundary disk that equals one near the origin and zero outside a smaller disk in its interior. Its derivative is supported on an annulus. Represent the factor \(p_m\) there by the smooth form \(\alpha_m=z^{-m}\bar\partial\chi\). For a boundary form \(\alpha\), use the oriented integral \(\tau(\alpha)=(2\pi i)^{-1}\int_D dz\wedge\alpha\). In \(\tau(z^{n-1}\alpha_m)\) the angular integral vanishes unless \(n=m\). For equal indices it leaves the radial integral \(-\int_0^\infty\chi'(r)\,dr=1\).

Extend the boundary representatives into a thin collar. For the interior probe take a smooth normal profile of integral one supported above the collar. Its tangential weight is \(\chi_o z^{n-1}\), where \(\chi_o\) is compactly supported and equals one on the annulus. The kinetic term pairs two fields. Use the component \(\Phi\) paired with the annular insertion. In the collar convention of Chapter 11 the propagator has a phase \(\zeta\) with \(\zeta^2=-1\). Give the \(\Phi\)-test coefficient \(\zeta^{-1}\kappa_{\mathrm b}\). Its contraction with one boundary factor \(p_m\) is then \(\hbar\kappa_{\mathrm b}\,\tau(\chi_o z^{n-1}\alpha_m)\), equal to one for \(m=n\) and zero otherwise. On a monomial each copy of \(p_n\) can supply the contracted factor. Summing over these choices gives \(\partial_{p_n}\) on the specified representatives. A boundary creation multiplies by \(p_n\).

To convert \(p_2\) into \(2p_1^2\), use twice the unit second-harmonic probe and then two boundary creations. For the reverse conversion, apply two unit first-harmonic probes in succession on disjoint intervals of height. Then create one quantum of the second harmonic at the boundary. These operations give the two coefficients of \(O\) on the specified representatives. [The half-space probes and the disk projection](11-states-and-lines.md#ch11-relative-phase)

### How far a boundary can move {#ch01-boundary-displacement}

For the disk reading \(C\) we fixed the Dirichlet action and varied the preparation. Can two bulk interactions instead be distinguished by the changes they allow in a boundary coupling? In the B-twisted Landau–Ginzburg model, take a formal coordinate \(x\) at the origin. The bulk interaction is given by the potential \(V_r(x)=x^r\), with \(r=3\) or \(4\).

Give the boundary one even and one odd basis vector over the formal power series ring \(\mathbb C[[x]]\). A matrix \(Q\) specifies the boundary coupling. It interchanges the two parities and satisfies \(Q^2=V_r(x)I\), where \(I\) is the identity. Such a matrix is called a *matrix factorisation* of the potential.

::: example {#ch01-fixed-potential-test title="A cubic and a quartic boundary"}
Take \(Q\) with upper right entry \(x\) and lower left entry \(x^{r-1}\). Change the upper entry to \(x+t\), with \(t\) a formal parameter. Can we choose the lower entry so that the square still gives the same potential through order \(N\) in \(t\)? Work with coefficients in \(\mathbb C[t]/(t^{N+1})\), where \(t^{N+1}=0\).

A lower entry \(b(x,t)\) would have to satisfy \((x+t)b(x,t)=x^r\). Since \(t\) is nilpotent, we can substitute \(x=-t\) in a formal \(x\)-series. This forces \(t^r=0\). Conversely the finite geometric sum gives
\[
 \begin{gathered}
 b_r(x,t)=\sum_{j=0}^{r-1}(-t)^j x^{r-1-j},\\
 (x+t)b_r(x,t)=x^r-(-t)^r .
 \end{gathered}
\]
Thus the displacement is possible through order \(N\) precisely for \(N<r\). Retaining terms through \(t^3\) distinguishes the two boundaries. Before truncation the cubic square acquires \(+t^3 I\), while the quartic square first changes by \(-t^4 I\).

What part of this change is visible to the boundary operators of the original matrix \(Q\)? In its ordered even, odd basis let \(E_{ij}\) send basis vector \(j\) to vector \(i\) and kill the other vector. The linear term of the displaced matrix is \(t\psi\) with \(\psi=E_{12}-x^{r-2}E_{21}\).

For a boundary operator \(B\) of parity \(|B|\), its differential is \(dB=QB-(-1)^{|B|}BQ\). Applying \(d\) a second time gives \(Q^2B-BQ^2=0\) because \(Q^2\) is a scalar matrix. A closed operator satisfies \(dB=0\). Two closed operators give the same protected class if their difference is exact, that is, of the form \(dH\) for a boundary operator \(H\). For \(f,g,u,v\in\mathbb C[[x]]\), direct multiplication gives
\[
 \begin{aligned}
 d\,\operatorname{diag}(f,g)&=x(g-f)\psi,\\
 d(uE_{12}+vE_{21})&=(xv+x^{r-1}u)I .
 \end{aligned}
\]
The even cycles are multiples of \(I\), the odd cycles multiples of \(\psi\). In either parity a multiple is exact precisely when its coefficient is divisible by \(x\), that is, belongs to the ideal \((x)\). The classes \([I],[\psi]\) therefore form a basis over \(\mathbb C\). Since \(\psi^2=-x^{r-2}I\) is exact, the two potentials give the same ordinary multiplication.

Can three insertions distinguish the two potentials when two agree? For an odd change \(\alpha\) of \(Q\), the change in its square is \(d\alpha+\alpha^2\). The chosen lower entry cancels each coefficient up to the first non-zero scalar multiple of \(I\), which survives in cohomology.

On the two classes there is a model whose differential vanishes and whose unit is \([I]\). Its products of arity greater than two vanish if any input is the unit. This is a minimal strictly unital model.

The entry \(x+t\) fixes the coordinate. The product on \(n\) copies of \([\psi]\) is \([I]\) times the coefficient of \(t^n\) in \(-V_r(-t)\). The cubic therefore gives \(+[I]\) on three copies. For the quartic it takes four copies to give \(-[I]\). [The higher products in the one-variable model](19-interacting-theories.md#ch19-boundary-potential)
:::

### Splitting and joining harmonics {#ch01-splitting-and-joining}

For the free current, the two terms of \(O\) convert the occupation \(1+1\) to \(2\) and back at the same energy. What conversions preserve a higher energy? At higher energies one can join harmonics \(i,j\) into \(i+j\) or split \(i+j\) into \(i,j\). Allow all harmonics, with \(J_{-n}\) multiplication by \(p_n\) and \(J_n=n\,\partial/\partial p_n\) for \(n\ge1\). A polynomial in \(\mathbb C[p_1,p_2,\ldots]\) uses finitely many harmonics. As in the two-harmonic inner product, distinct occupations are orthogonal and an occupation with counts \(m_n\) has squared norm \(\prod_n n^{m_n}m_n!\).

**Definition (cubic current observable).** The sum of the splitting and joining operations over ordered pairs of positive indices defines the operator
\[
W=\frac12\sum_{i,j\ge1}\bigl(J_{-i}J_{-j}J_{i+j}+J_{-i-j}J_iJ_j\bigr).
\]
{#eq-cubic-observable}
On a monomial of energy \(e\), a split requires an occupied harmonic \(i+j\) and a join requires the two quanta \(i,j\). Either can occur only when \(i+j\le e\), so the sum is finite on polynomials. The terms preserve energy and come in adjoint pairs, so their sum \(W_e\) on each finite-dimensional energy space is self-adjoint. At energy two only \(i=j=1\) occurs, and \(W_2=O/2=S\). In the Hilbert completion let \(F_e\) be the orthogonal energy-\(e\) component of a vector \(F\). The self-adjoint direct sum has domain \(\{F=\sum_e F_e:\sum_e\|W_eF_e\|^2<\infty\}\) and value \(WF=\sum_eW_eF_e\).

Can the current at one point give the same energy-preserving sum in the neutral sector, where the total-charge mode \(J_0\) vanishes? Assemble the modes into the formal field \(J(z)=\sum_{n\in\mathbb Z}J_n z^{-n-1}\). In a product between colons put all creation modes to the left of the annihilation modes. A product of three modes whose indices sum to zero multiplies \(z^{-3}\) in the cube. Multiplication by \(z^2\) turns this into the coefficient of \(z^{-1}dz\), which the residue selects. With these conventions,
\[
W=\frac16\operatorname{Res}_{z=0}\,z^2\,{:}J(z)^3{:}\;dz .
\]
{#eq-cubic-residue}
The colons place the removal operators \(J_n\), \(n>0\), to the right. With \(J_0=0\), only triples of non-zero indices contribute to the residue. In each such triple one index has sign opposite to the other two. Its three possible positions give the factor \(3/6=1/2\), leaving the other two indices as the ordered pair in the sum. Thus the same exchange can be read from three currents multiplied *at one point*, with the singular terms removed by normal ordering. [Normal ordering of the free current](03-local-fields.md#heisenberg-current)

Can an energy measurement distinguish \(u_+\) from \(u_-\) even though they have the same oscillator energy? On a ring, the kinetic energy of a free fermion is quadratic in its momentum. Put an odd number \(N\) of free spinless fermions of mass \(m\) on a ring of circumference \(L\). Here \(\hbar\) is the reduced Planck constant. The ground state fills the momenta \(2\pi\hbar j/L\) for \(|j|\le(N-1)/2\). Write \(\psi_0\) for its wavefunction, the determinant of the occupied orbitals divided by its norm.

For a particle at position \(y_a\) put \(x_a=e^{2\pi i y_a/L}\). Multiplying the ground-state wavefunction by the density wave \(p_n=\sum_{a=1}^N x_a^n\) adds momentum \(2\pi\hbar n/L\). In this representation of the current a polynomial \(F\) gives the ring state \(F(p(x))\,\psi_0(x)\). The ground-state position law weights product angular probability measure by \(|\psi_0|^2\). To obtain the inner product of two density-wave polynomials, integrate the complex conjugate of the first times the second against this law.

At total oscillator energy \(n\), the added momentum is \(n\) steps, so only the top \(n\) filled orbitals can change in these excitations. Thus \(n\ll N\) gives an upper-edge excitation. The current and ring inner products agree exactly on the span of occupations of energy \(n\le N\). [Density waves of free fermions](11-states-and-lines.md#ch11-boundary-fermions)

Let \(E\) multiply a current state of dimensionless oscillator energy \(n\) by \(n\). Raising the highest occupied fermion by one momentum step costs \(\varepsilon_1=2\pi\hbar v_F/L\), where \(v_F=\pi\hbar N/(mL)\) is the velocity halfway across that step. A dispersion relation linear with this slope would give excitation energy \(\varepsilon_1 E\). For a fermion of wave number \(k\), the kinetic energy is \(\hbar^2 k^2/(2m)\). With this quadratic dispersion the energy operator above the ground state acts on density-wave polynomials as
\[
\varepsilon_1\Bigl(E+\frac2N\,W\Bigr).
\]
{#eq-ring-energy}
For the preparations of energies two and three take odd \(N\ge3\). Since \(W u_\pm=\pm u_\pm\), the ring energies above the ground state are \(\varepsilon_1(2\pm2/N)\). An energy measurement on this shell that resolves the separation \(4\varepsilon_1/N\) determines the sign of \(S\). For \(N=101\) the predicted separation is about four hundredths of the spacing \(\varepsilon_1\) between successive levels of the linear spectrum. [Kinetic energy in the density waves](11-states-and-lines.md#ch11-cubic-observable)

Position measurement on the ring gives a separate test. From the measured positions form the first two density waves and compute \(C\) by substituting them for \(Z_1,Z_2\) in the disk statistic. Give \(p_n\) weight \(n\). In the product of \(C\) with the preparation density, each term has weight four in the waves and four in their complex conjugates. The inner-product identity therefore gives means \(\pm2\) for \(N\ge4\) in the stated odd-\(N\) regime.

The full distribution still depends on \(N\). At any finite odd \(N\ge3\), the mean of \(|p_1|^{2(N-1)}\) in \(u_+\) exceeds its mean in \(u_-\) by one. Both density waves are functions of the same particle positions, so a high moment of the first can distinguish their position laws. As \(N\) grows, the ground-state law of any fixed finite set of waves tends to its marginal under \(\mu\). The corresponding limits in the two preparations are their marginals under \(|F_\pm|^2d\mu\). [Finite-ring moments and their disk limit](11-states-and-lines.md#ch11-boundary-fermions)

What does \(W\) measure at higher energy? At energy three the monomials \(p_1^3\), \(p_1p_2\) and \(p_3\) form a basis, and the definition gives
\[
W\,p_1^3=3p_1p_2,\qquad W\,(p_1p_2)=p_1^3+2p_3,\qquad W\,p_3=3p_1p_2 .
\]
Its eigenvalues are \(3,0,-3\), with unit eigenvectors
\[
\frac{p_1^3+3p_1p_2+2p_3}{6},\qquad\frac{p_1^3-p_3}{3},\qquad\frac{p_1^3-3p_1p_2+2p_3}{6}.
\]
A measurement of \(W\) therefore distinguishes these three preparations with certainty. On the ring they are stationary states from the shell \(E=3\), at the energies \(\varepsilon_1(3+6/N)\), \(3\varepsilon_1\) and \(\varepsilon_1(3-6/N)\). In the first and the third, a count of quanta finds the three basis occupations with the same probabilities \(\tfrac16,\tfrac12,\tfrac13\). At \(N=3\) the third polynomial equals \(x_1x_2x_3\). It takes the occupied momentum labels \(\{-1,0,1\}\) to \(\{0,1,2\}\), leaving a hole at the lower edge while adding a particle above the upper edge. The energy formula still applies exactly.

Which states have definite occupied momenta at every oscillator energy \(n\)? A partition \(\lambda\) of \(n\) lists positive integers in weakly decreasing order with sum \(n\). Give row \(i\) of its diagram \(\lambda_i\) boxes. Take \(N\ge n\).

Starting from the ground state, move the \(i\)-th fermion from the top up by \(\lambda_i\) momentum steps, with zero steps for an empty row. Divide the determinant of these orbitals by the ground-state determinant in the same order. The quotients are the Schur polynomials \(s_\lambda\). Multiplying the ground state by \(s_\lambda\) therefore prepares the specified occupied momenta. These polynomials give an orthonormal eigenbasis of \(W\) in the current space of energy \(n\).

To read the eigenvalue, start the \(i\)-th fermion at its ground-state momentum label \((N+1)/2-i\). By the quadratic dispersion, its \(j\)-th step costs \(\varepsilon_1+(2\varepsilon_1/N)(j-i)\). Each box \((i,j)\) counts one step, so the first term sums to the linear energy \(\varepsilon_1 n\). Subtract from the full ring energy both the ground energy and \(\varepsilon_1 E\). The residual operator is \((2\varepsilon_1/N)W\), and dividing by \(2\varepsilon_1/N\) gives the dimensionless eigenvalue \(\sum_{(i,j)\in\lambda}(j-i)\).

At energy two, the row gives \(u_+\) with reading \(0+1\), while the column gives \(u_-\) with reading \(0-1\). Through energy five this sum distinguishes the diagram within its energy space. At energy six the shapes \((4,1,1)\) and \((3,3)\) both give \(3\). [The exchange at every energy](11-states-and-lines.md#ch11-cubic-observable)

In the two disk preparations, both the squared wavefunction and the reading \(C\) depend only on \(Z_1,Z_2\). Integrating out every other harmonic leaves the mean unchanged because each of its Gaussian laws has mass one. What if the detector measures a variable that we intend to integrate out? Two coupled oscillators give a first case in which the answer depends on the coordinate we keep.

## Reduction must retain the measurements {#reduction-must-retain-the-measurements}

Let \(x,y\) be the displacements of two coupled oscillators. We can retain a record of \(x\) alone even when an instrument also measures \(y^2\). To predict the mean of that second reading from the first record we need the distribution of \(y\) at each fixed \(x\). With stiffnesses \(a,b\) and coupling coefficient \(c\), take the Euclidean quadratic action
\[
 S(x,y)=\frac12 ax^2+cxy+\frac12 by^2,
 \qquad b>0,\qquad ab>c^2 .
\]
These inequalities make the quadratic form positive definite. Let \(\hbar>0\) set the fluctuation scale and use ordinary Lebesgue measure in both displacements. Integrating out \(y\) gives the weight \(Z_y(x)\) per unit \(dx\),
\[
Z_y(x)=\int_{\mathbb R}\exp\!\left(-\frac{S(x,y)}{\hbar}\right)\,dy.
\]
Completing the square gives
\[
S(x,y)
=\frac b2\left(y+\frac cbx\right)^2
 +\frac12\left(a-\frac{c^2}{b}\right)x^2,
\]
and hence
\[
Z_y(x)
=\sqrt{\frac{2\pi\hbar}{b}}\,
\exp\!\left[
-\frac{1}{2\hbar}\left(a-\frac{c^2}{b}\right)x^2
\right].
\tag{1.1}
\]
{#eq-gaussian-integral}

The centre of the Gaussian in \(y\) moves with \(x\). Allowing \(y\) to relax to \(-cx/b\) gives the retained coordinate its effective stiffness \(a-c^2/b\), the Schur complement of \(b\). Holding \(y=0\) instead would give stiffness \(a\). Integration also supplies the prefactor \(\sqrt{2\pi\hbar/b}\), which measures fluctuations about the displaced centre.

For the instrument measuring \(y^2\), the displaced centre gives only part of the answer. What function of \(x\) gives the mean of its readings?

**Definition (conditional expectation).** For a polynomial observable \(f(x,y)\), average over \(y\) at fixed \(x\) in the normalised Gaussian law,
\[
\mathcal E(f)(x)=\frac{1}{Z_y(x)}\int_{\mathbb R} f(x,y)e^{-S(x,y)/\hbar}\,dy .
\]
Multiplying this function by \(Z_y(x)\) and integrating over \(x\) recovers the original integral with insertion \(f\). From the completed square, \(y\) at fixed \(x\) has mean \(-cx/b\) and variance \(\hbar/b\). Writing \(\langle f\rangle_x=\mathcal E(f)(x)\) gives
\[
\langle y\rangle_x=-\frac cbx,
\qquad
\langle y^2\rangle_x=\frac{c^2}{b^2}x^2+\frac{\hbar}{b}.
\tag{1.2}
\]
{#eq-gaussian-moments}
The second term in \(\langle y^2\rangle_x\) is the conditional variance. At \(x=0\) the mean displacement of the hidden oscillator is zero, yet a detector sensitive to its squared displacement reads \(\hbar/b\) on average.

The map \(\mathcal E\) is linear and sends \(1\) to \(1\). For two insertions of \(y\), the failure of multiplicativity is the variance
\[
\mathcal E(y^2)-\mathcal E(y)^2=\frac{\hbar}{b}.
\tag{1.3}
\]
{#eq-conditional-product-defect}
For two linear Gaussian insertions the covariance is the mean of their product minus the product of their means. Pairing two insertions by their covariance is a *contraction*.

At fixed \(x\), subtract the conditional mean of \(y\). Products of an even number of centred linear Gaussian insertions average to the sum over pairings of products of covariances. Odd products have zero mean. Restoring the conditional means recovers the moments of the original variables. Successive Gaussian integrations must give the same joint expectation.

What information is lost by keeping only normalised expectations? Hold the effective stiffness \(a-c^2/b\) fixed and change \(b\), adjusting \(a\) accordingly. Equation (1.1) gives the same normalised distribution of \(x\) but a different absolute integral, through the factor \(\sqrt{2\pi\hbar/b}\).

To glue two Gaussian integrals along \(x\), multiply their weights at the same \(x\) and integrate over that common coordinate. Both prefactors enter the result. In a field theory the corresponding determinants need an infinite-dimensional definition, including a prescription for their phases. For two separated sources, how does the absolute amplitude vary with their distance?

::: figure fig-gaussian-reduction

In three-dimensional abelian Chern–Simons theory a Wilson line of charge \(a\) couples to the integral of the gauge one-form along its oriented curve. Put two rays of charges \(a,-a\) at distinct boundary points \(r,0\), with \(a\) real and \(0<r<1\). Work at level one, with neutral vacuum \(|0\rangle=1\). An enclosing current contour measures zero total charge. Which neutral state do the rays prepare? Its constant polynomial term is the amplitude of the vacuum, and the positive current modes probe its other coefficients.

To find the vacuum coefficient, integrate the planar Cauchy propagator between the rays. Smooth each ray radially in its transverse plane, with disjoint supports for the two regularisations. Give the rays parallel framings and subtract each self-contraction. The rays are disjoint graphs, vertical near the boundary tests and above the bending region.

In the real ordered chamber bring the outgoing ends to separation \(\epsilon d\) with fixed \(d>0\). On each compact interval met by the tests, require uniform bounds on the graphs and their first derivatives. Require smooth convergence there as \(\epsilon\) tends to zero. The mutual contraction contributes \(-a^2(\log r-\log(\epsilon d))\) to the exponent. Exponentiating gives \(r^{-a^2}(\epsilon d)^{a^2}\). Dividing out the outgoing factor leaves the vacuum coefficient \(r^{-a^2}\).

For the mode responses, let \(w\) run along a contour enclosing both endpoints. The ray of charge \(a\) contributes \(a/(w-r)\) and the ray of charge \(-a\) contributes \(-a/w\). In the expansion of \(a/(w-r)-a/w\) for \(|w|>r\), the \(w^{-1}\) terms cancel, as total charge requires. For every \(n>0\) the coefficient of \(w^{-n-1}\) is \(ar^n\).

At each energy the ray amplitude has a polynomial coefficient. Write \(F_d\) for the finite-dimensional space of energy-\(d\) polynomials and let \(\Psi=(\Psi_d)_{d\ge0}\) belong initially to their formal product \(\prod_{d\ge0}F_d\). On polynomials the positive mode acts by \(n\partial_{p_n}\), lowering energy by \(n\). The response of the ray says that \(n\partial_{p_n}\Psi_{d+n}=ar^n\Psi_d\) for every \(d\ge0\). In this completion the equations determine all coefficients from the vacuum amplitude. With the vacuum coefficient just calculated the state is
\[
 \Psi_{a,r}=r^{-a^2}\exp\!\left(a\sum_{n>0}\frac{r^n}{n}J_{-n}\right)|0\rangle .
\]
The formal product allows a coefficient at every energy. Is the sum of their squared norms finite?

Use the disk with the same centre, angular coordinate and zero constant mode as in the two-harmonic measurement. Under the vacuum law \(\mu\) the complex amplitudes \(Z_n\) in \(h(z)=\sum_{n>0}Z_nz^n/n\) are independent, with variance \(n\). The moment \(n^m m!\) is the squared norm of \(J_{-n}^m|0\rangle\). Thus multiplication by \(Z_n\) again represents \(J_{-n}\) on holomorphic polynomials, now in every harmonic.

We can prepare a disk field directly by coupling it to \(a\) at \(r\) and \(-a\) at zero. Its density relative to the vacuum is proportional to \(e^{2a\operatorname{Re}h(r)}\). Completing the square in each complex coordinate shifts its mean to \(ar^n\) and leaves its variance \(n\). The squared norm of \(e^{ah(r)}\) is \(\exp(a^2\sum_{n>0}r^{2n}/n)=(1-r^2)^{-a^2}\), finite in the chosen range. On substituting \(p_n=Z_n\), the ray state becomes \(r^{-a^2}e^{ah(r)}\). Squaring its modulus and normalising gives exactly the independently prepared disk law on all harmonic amplitudes.

The disk preparation gives the probability law of the complex amplitudes \(Z_n\). One can also ask for the occupation numbers in the same ray state. The probability of a given list of occupations is the squared norm of the projection of the normalised state onto the corresponding occupation monomial. How does propagation weight these probabilities? A collar of Euclidean length \(-\log q\), with \(0<q\le1\), propagates the holomorphic ray amplitude. After subtracting the vacuum energy, the propagation operator \(q^{L_0}\) multiplies its energy-\(m\) component by \(q^m\), where \(L_0\) measures total oscillator energy. Pair the propagated vector with a copy of the original ray vector. Dividing by its original squared norm weights each occupation probability by its propagation factor. The same Gaussian moment sum, now weighted by \(q^n\) in mode \(n\) on the second amplitude, gives
\[
 \frac{\langle\Psi_{a,r},q^{L_0}\Psi_{a,r}\rangle}{\|\Psi_{a,r}\|^2}
 =\left(\frac{1-r^2}{1-qr^2}\right)^{a^2}.
\]
The collar replaces \(r\) by \(qr\) in the exponential of the second amplitude. Its pairing with the first therefore involves \(qr^2\). The ratio is one at zero collar length. The scalar \(r^{-a^2}\) cancels at every length, just as the determinant cancels from a normalised finite Gaussian. Computing an absolute amplitude requires the normalisation of the filling. [The disk and cylinder actions](11-states-and-lines.md#ch11-harmonic-disk-and-collar) · [The regularised rays and the sourced disk](11-states-and-lines.md#ch11-neutral-ray-pair)

### The field of a neutral pair of lines {#ch01-neutral-wilson-lines}

Keep the two endpoints at \(r\) and \(0\) and exchange their charges. In the level-one Chern–Simons preparation the vacuum coefficient \(r^{-a^2}\) stays fixed, while the eigenvalue \(ar^n\) of each positive current mode changes sign. On the disk this eigenvalue is the mean of the complex amplitude \(Z_n\). Can a distant detector also distinguish which of two parallel lines carries the positive charge? In four-dimensional electrodynamics the separation is an ordinary transverse length, and the detector reads the Maxwell field strength.

::: example {#ch01-example-neutral-maxwell title="A neutral Wilson pair with a nonzero dipole"}
Let \(A\) be the gauge potential of Euclidean free Maxwell theory, with field strength \(F=dA\) and action \(\tfrac14\int F_{\mu\nu}F^{\mu\nu}\,d^4x\). With coupling \(e\), a Wilson line of charge \(q\) is \(W_q=\exp(ieq\int A)\). Give two infinite lines the same unit tangent \(v\). Place charge \(+q\) at \(r n\) and charge \(-q\) at the origin, where \(n\) is a unit normal and \(r>0\).

Subtract the two line self-energies. For charges \(q_1,q_2\) the remaining logarithm of the line correlator per unit length is \(a_0/r\), with \(a_0=-e^2q_1q_2/(4\pi)\). Either placement of the neutral charges gives \(a_0=e^2q^2/(4\pi)\).

Place the detector at \(xn\), \(x>r\). To find the gauge potential produced by either source, integrate the photon propagator along a straight line at distance \(y>0\). The integral in its arclength coordinate \(s\) is \(\int_{\mathbb R} ds/[4\pi^2(s^2+y^2)]=1/(4\pi y)\). The source contributes this function times its charge and \(ie\,v_\nu\) to the normalised expectation of \(A_\nu\). Taking the antisymmetric derivative of the two source contributions gives the field strength at the detector.

Write \(W=W_q(rn)W_{-q}(0)\) for the pair and \(t_{\mu\nu}=(v_\mu n_\nu-v_\nu n_\mu)/2\) for its oriented tensor. In \(\langle F_{\mu\nu}(xn)W\rangle/\langle W\rangle\) the coefficient of \(ie\,t_{\mu\nu}/(2\pi)\) is
\[
 q\left(\frac1{(x-r)^2}-\frac1{x^2}\right)
   =\frac{2qr}{x^3}+O\!\left(\frac{|q|r^2}{x^4}\right).
\]
The expansion holds for \(r/x\) small. The total charge vanishes, so the first surviving term measures the dipole, the first moment of the charges along \(n\). At \(q=1,\ x=3,\ r=1/5\) in a common length unit, the exact coefficient is \(25/196-1/9=29/1764\) in inverse square length units. Exchanging the charges gives \(-29/1764\). Translating the multipole origin by \(\delta n\) changes the dipole by \(-\delta(q_1+q_2)\), which vanishes here. The sign identifies which end of the neutral pair carries the positive charge. [Albert, Forslund and Homrich, equations (4.39)–(4.43)](https://arxiv.org/pdf/2611.33272v1#page=41)
:::

When a bulk or line deformation introduces a mass scale \(m\), which single line could reproduce the two-line measurements at small separation? The reference line is the defect obtained by fusing the pair in the undeformed ultraviolet conformal theory. Albert, Forslund and Homrich propose that for \(mr\ll1\) a local action on this fused defect describes the deformed pair. This general expansion is conjectural. Its coefficients must reproduce correlators with distant insertions as well as the static interaction.

If the fused line has two sectors, closing it takes a trace over their direct sum. Take one basis vector per sector and let \(E_{ij}\) send vector \(j\) to vector \(i\) and kill the other vector. The transition \(E_{12}\) alone has zero trace. In \(E_{12}E_{21}\) the right factor takes the first vector to the second and the left factor returns it. Thus \(\operatorname{tr}(E_{12}E_{21})=\operatorname{tr}E_{11}=1\) in this two-dimensional example.

Chiral exchange has a different geometry, with a complex separation and a topological crossing. Identifying a Euclidean dipole coefficient with a chiral exchange coefficient would require a map of the two operations and their probes. [The proposed line action, equations (3.6)–(3.7)](https://arxiv.org/pdf/2611.33272v1#page=22) · [Transitions between sectors, equations (3.15)–(3.16)](https://arxiv.org/pdf/2611.33272v1#page=27) · [A massive Gaussian line pair](11-states-and-lines.md#ch11-example-massive-line-spectator)

### Moving parallel lines and measuring a crossing {#ch01-parallel-lines-and-crossing}

Can two labelled Wilson lines pass one another while they remain parallel? In four-dimensional Chern–Simons theory each line follows a curve in a real plane and sits at a fixed point of a complex curve. That point is its spectral parameter. The real plane is topological. For straight parallel lines we can therefore ask which displacements at fixed spectral parameters are possible without contact. To read a crossing amplitude one prepares a different pair of lines. Their projections cross in the real plane, and one fixes the internal states, or colours, at the ends of both lines.

Take coordinates \(s,t\) in the real plane. Direct both lines along increasing \(s\) and put line \(i\) at height \(t_i\) and spectral point \(z_i\). For \(z_1\ne z_2\) one can move \(t_1\) through \(t_2\). Even at equal height the lines occupy different points of the complex curve. For \(z_1=z_2\), reversing the sign of \(t_1-t_2\) would make the lines meet. One can forget the height distances if one keeps the two possible orders over the common spectral point.

::: proposition {#ch01-height-components title="Order at coincident spectral points"}
Let \(X\) be a smooth Hausdorff, second-countable complex curve in its analytic topology. For \(n\ge2\) labelled parallel lines, fix \((z_1,\ldots,z_n)\in X^n\). Each connected component of the allowed heights is specified by one linear order on the labels at each common spectral point. As the spectral points vary, collapsing these components gives one chart \(X^n\) for each total order of the labels. Two charts agree wherever their orders agree on every group of coincident points.
:::

::: proof {#ch01-proof-height-components}
At fixed spectral points the only forbidden equalities are \(t_i=t_j\) for pairs with \(z_i=z_j\). The sign of any such difference is constant along a path. Conversely, once the signs in each group are fixed, the allowed heights satisfy strict linear inequalities. Straight-line interpolation joins any two solutions. Every collection of orders within groups extends to a total order of all the labels.

For a total order \(\sigma\), admit a height tuple whenever \(z_i\ne z_j\) or \(t_i<t_j\) for each pair with \(i\) before \(j\) in \(\sigma\). These conditions define an open set of configurations. Projection from it to \(X^n\) is open and onto, and its fibres are precisely the chosen components. This identifies its quotient with \(X^n\). A pair ordered oppositely in two charts must have distinct spectral points throughout their overlap. For two lines, a disk in the relative spectral coordinate therefore gives two disks glued along the punctured disk. Their two origins distinguish which line has the greater height. [Petersen and Tosteson, §2.3.1 and Theorem 3.3.5 for the affine line](https://arxiv.org/abs/2004.06024v3)
:::

::: example {#ch01-framed-wilson-crossing title="A crossing with fixed incoming and outgoing colours"}
Direct the first line along increasing \(s\) and the second along increasing \(t\), each along its entire axis. Choose \(X=\mathbb C\) with the holomorphic one-form \(dz\), and set \(u=z_1-z_2\ne0\). The projections cross once positively for the orientation \(ds\wedge dt\). The lines in four dimensions remain disjoint. Use the coordinate frame of the plane and the complex orientation of the spectral plane. In the rational theory, expand about the trivial connection in the formal coupling \(\hbar\). Use the flat decaying propagator of Costello, Witten and Yamazaki, which pairs a field insertion on one line with an insertion on the other. Trivialise the gauge bundle at spectral infinity and require gauge transformations to fix the external colour frames at the ends.

Give each line the defining colour space \(\mathbb C^2\) of \(\mathfrak{gl}_2\). Prepare basis vectors \(e_1,e_2\) on the respective incoming ends. On the outgoing ends select the coefficient of \(e_2\otimes e_1\), keeping the tensor slots labelled by the original lines. Free propagation gives zero in this channel. The first possible contribution pairs one gauge field on each line. With the invariant form \((A,B)=\operatorname{Tr}(AB)\), the colour tensor of this contraction is \(\Omega=\sum_{i,j=1}^2 E_{ij}\otimes E_{ji}\), where \(E_{ij}\) sends \(e_j\) to \(e_i\) and kills the other basis vector. Only \(E_{21}\otimes E_{12}\) contributes to the selected transition, with coefficient one.

In this gauge the scalar density for insertions at \((s,0)\) and \((0,t)\) is \(\bar u\,ds\,dt/[\pi(s^2+t^2+|u|^2)^2]\). Integrate first over pairs with \(s^2+t^2<R^2\), for \(R>0\). With radial coordinate \(\rho\), the integral is
\[
 K_R(u)=2\bar u\int_0^R\frac{\rho\,d\rho}{(\rho^2+|u|^2)^2}
       =\frac{1}{u}\frac{R^2}{R^2+|u|^2}.
\]
At \(R=|u|\) this window contains half the full contraction. It restricts pairs of insertion points in the chosen gauge. The amplitude for the two complete lines uses \(R\to\infty\) at fixed \(u\), giving \(\hbar/u+O(\hbar^2)\) in the selected colour channel. Reversing one tangent changes the sign of the contraction. For two straight parallel lines at distinct spectral points the contraction vanishes because the determinant of their two plane tangents is zero. An exchange written with the output slots in the opposite order applies the tensor flip after the crossing operator. [Costello, Witten and Yamazaki, §4, equations (4.4)–(4.14)](https://arxiv.org/pdf/1709.09993v2#page=32) · [The crossing on tensor states](12-chiral-quantum-groups.md#ch12-combined-probe-exchange)
:::

A family of parallel lines can detect the omitted coincidence in another way. Write \(\xi\) for the first longitudinal coordinate minus the second, \(Y=t_1-t_2\) and \(u=z_1-z_2=a+ib\). Move the relative displacement \((Y,a,b)\) on the sphere \(Y^2+a^2+b^2=r^2\) at fixed \(r>0\). Give the sphere the outward orientation in \(dY\wedge da\wedge db\). With the coupling and colour tensor removed, the free propagator in these coordinates is the two-form
\[
 P=\frac{\xi\,dY\wedge d\bar u+Y\,d\bar u\wedge d\xi
                  +2\bar u\,d\xi\wedge dY}{2\pi(\xi^2+r^2)^2}.
\]
The source flux through this family uses the three-form \(i\,du\wedge P/(2\pi)\). Insert the tangent \(\partial_\xi\) into its first slot and integrate in increasing \(\xi\) along the whole relative line. The term of \(P\) without \(d\xi\) drops out. With \(\iota_{\partial_\xi}\) denoting this insertion and \(\int_{\mathbb R}(\xi^2+r^2)^{-2}d\xi=\pi/(2r^3)\), the resulting two-form is
\[
 \tau=\int_{\mathbb R}\iota_{\partial_\xi}
             \!\left(\frac{i}{2\pi}du\wedge P\right)d\xi
     =\frac{i}{8\pi r^3}
       \bigl(Y\,du\wedge d\bar u-2\bar u\,du\wedge dY\bigr).
\]
On the sphere put \(Y=r\cos\vartheta\) and \(u=r\sin\vartheta\,e^{i\varphi}\). Substitution at fixed \(r\) gives
\[
 \left.\tau\right|_{S^2_r}
       =\frac{\sin\vartheta}{4\pi}\,d\vartheta\wedge d\varphi .
\]
Integrating for \(0\le\vartheta\le\pi\), \(0\le\varphi<2\pi\) gives \(+1\). On the northern and southern patches of the sphere, primitives are \((1-\cos\vartheta)d\varphi/(4\pi)\) and \(-(1+\cos\vartheta)d\varphi/(4\pi)\), respectively. Subtract the southern primitive from the northern one. The difference is \(d\varphi/(2\pi)\), of period one around the positively oriented complex equator. Taking all three differences in the reverse order acts on this oriented sphere by the antipodal map, of degree \(-1\). [The two order charts](04-factorization.md#ordered-cut-geometry)

Thus the unit flux of the parallel family equals the residue of the scalar \(1/u\) in the crossed preparation, with the contour integral divided by \(2\pi i\). The actual tree amplitude also includes the coupling and the matrix element of \(\Omega\). Extending this operation to fields at \(u=0\) requires collision coefficients and maps compatible with fusion. For the three-dimensional neutral rays, the vacuum amplitude already fixes one coefficient of the boundary product.

## From products to local operations {#from-products-to-local-operations}

Bringing the two Chern–Simons boundary rays closer changes their vacuum coefficient by a power of their separation. How can the product of two insertions record that dependence? Forgetting the positions gives only a bilinear multiplication \(m\) on a space \(A\) of observables,
\[
m:A\otimes A\longrightarrow A.
\]
For *local* observables, keep one point \(w\) fixed in a complex coordinate disk and move the other to \(z=w+t\). For states \(a,b\in A\), write \(Y(a,t)b\) for the action of the field of \(a\) at separation \(t\) on \(b\). It gives a Laurent series in the separation with coefficients in \(A\), written \(Y(a,t)b\in A((t))\). Each coefficient is a state at \(w\). For each fixed pair \(a,b\) only finitely many negative powers occur. They record the singularity as \(z\) approaches \(w\). [Fields acting on states](03-local-fields.md#fields-and-modes)

For the free current write \(\kappa\) for the boundary level. In the half-space model this is \(\hbar\kappa_{\mathrm b}\), equal to one in the oscillator experiment. Write \(\sim\) for equality of the terms singular as \(z\) approaches \(w\), with scalar coefficients understood to multiply the identity operator. The current product at distinct points has singular part
\[
J(z)J(w)\sim \frac{\kappa}{(z-w)^2}.
\tag{1.4}
\]
{#eq-current-singularity}
All omitted terms are regular at \(z=w\).

Even this one pole has two different expansions. In the region \(|w|<|z|\),
\[
\frac1{(z-w)^2}
=\sum_{n\ge0}(n+1)\frac{w^n}{z^{n+2}},
\]
whereas in \(|z|<|w|\),
\[
\frac1{(z-w)^2}
=\sum_{n\ge0}(n+1)\frac{z^n}{w^{n+2}}.
\tag{1.5}
\]
{#eq-local-expansions}
These are Taylor expansions of the same rational function in two different ratios. In the first, the insertion at \(w\) is inside the contour through \(z\). Interchanging the radii gives the second. For a formal field the inner and outer variables specify an order of expansion even when no analytic convergence is assumed.

::: figure fig-local-expansions

What survives of the double pole at the point of collision? Integrate it against a regular test function \(f(t)\) around \(t=0\), anticlockwise, and divide the contour integral by \(2\pi i\). The residue \(\operatorname{Res}_{t=0} f(t)t^{-2}dt=f'(0)\) distinguishes \(f(t)=t\) from zero although the two have the same value at the origin. Applied to the same current pole, the tests \(1\) and \(t\) give respectively zero and \(\kappa\) times the identity. An output supported at the collision must therefore retain differentiation in the separation.

On a smooth complex algebraic curve \(X\), let \(L\) be a right module for the differential operators on \(X\). Its external product \(L\boxtimes L\) has one copy of \(L\) at each input position. Let \(j\) include the open set of distinct pairs in \(X^2\). Restriction to this open followed by direct image, written \(j_*j^*\), allows inputs with poles of finite order along the diagonal. A multiplier \(t^{-1}\), for example, lets the residue read a regular constant coefficient.

Write \(\Delta(x)=(x,x)\) for the diagonal inclusion. Its direct image \(\Delta_*L\) retains outputs on the diagonal together with their finite normal derivatives. The Beilinson–Drinfeld **chiral bracket** sends the extended inputs to this diagonal module. As a map commuting with differential operators in both positions, it has the form
\[
 \mu_{\mathrm{ch}}:j_*j^*(L\boxtimes L)\longrightarrow\Delta_*L .
\]
The bracket is skew-symmetric. For three inputs, any pair can collide first while the third stays apart. The Jacobi identity says that the signed sum of the three iterated brackets vanishes.

For three positions \(z_1,z_2,z_3\), put \(u=z_1-z_3\) and \(v=z_2-z_3\). In \(1/[u(u-v)]\) the pole at \(u=v\) has residue \(1/v\). The expansion at \(v=0\) for fixed non-zero \(u\) has no pole. The pole at \(u=0\) has residue \(-1/v\). The second residues in the remaining separation give \(1,0,-1\), respectively.

If a unit is specified, it is a map from the module of one-forms \(\omega_X\) to \(L\). Bracketing its image with a field takes the principal part at the diagonal, the polar term modulo regular terms. [Right differential modules](03-local-fields.md#differential-modules) · [The chiral operation on the diagonal](04-factorization.md#chiral-operation)

Even when an amplitude is known at every configuration of distinct points, extending it to a collision can require a choice. At level two, place four charged rays at distinct points \(z_1,\ldots,z_4\). Each carries charge one and has no excited oscillator. The outgoing charge is four. Apply the functional that extracts the oscillator-free coefficient and takes value one on the charge-four state with no excitations.

With fixed coordinate frames and the Gaussian ray prescriptions, that coefficient on the separated points is a branch of \(\prod_{i<j}(z_i-z_j)^{1/2}\). The branches give a one-dimensional space of coefficients that continues along paths, a rank-one local system. Winding a pair once multiplies the amplitude by \(-1\). Rotating the whole configuration through a full turn winds six pairs and gives \(+1\).

Fix the common position and vary the three independent differences. On this labelled transverse slice, take the part of a small neighbourhood of the collision where all four points are distinct. Take the cohomology of these nearby distinct configurations with coefficients in the branch local system. At a proper collision a group of two or three rays can make a full turn with multiplier \(-1\), and the nearby cohomology vanishes. At the full collision its dimension is two in each of degrees two and three, before any shift, and zero in all other degrees.

Which nearby classes extend to the collision itself? Restrict the cochains of a proposed extension on the whole neighbourhood to its distinct-point part. As the neighbourhood shrinks this restriction gives the attaching map from the stalk of the extension to the nearby cochains. Its image on cohomology consists of the extendible classes.

One way to constrain an extension is to bound both its cohomology at the collision and its local cohomology supported there. These are the stalk and costalk bounds for the perverse sheaves in Chapter 4. Write \(j\) for the inclusion of the distinct configurations, \(i\) for the inclusion of the collision point and \(L\) for the branch local system. On this three-dimensional slice the shift \(L[3]\) places its coefficients in degree minus three. Its extension by zero, \(P_!=j_!L[3]\), is perverse. If \(V\) is the two-dimensional nearby cohomology in unshifted degree two, the map from \(P_!\) to the intermediate extension has kernel \(i_*V\) at the collision point. The intermediate extension has no non-zero subobject or quotient supported there. For each line \(W\subset V\) take the quotient \(P_!/(i_*W)\). Its stalk in degree minus one is \(W\), and its degree-zero costalk is \(V/W\). The attaching image is the kernel of \(V\to V/W\), hence precisely \(W\). Changing that line preserves both ranks.

For identical charges, exchanging positions along a path and permuting the labels on the coefficient line give two distinct operations. On the trivial coordinate line take the connection \(d-\tfrac12d\log\Delta\), where \(\Delta=\prod_{a<b}(z_a-z_b)\). Keep each coordinate frame fixed during a positive half-braid. The argument of \(\Delta\) increases by \(\pi\), giving transport by \(+i\). Two successive positive half-braids give transport by \(-1\). A permutation acts on the coordinate fibre by the identity and permutes the variables in the connection. It preserves \(d\log\Delta\) because a permutation changes \(\Delta\) only by its sign. These relabellings therefore induce an action of the permutation group \(S_4\) on \(V\). The shape calculation in Chapter 4 gives trace zero for a transposition and shows that the three-cycles act trivially. Thus \(V\) is the direct sum of the trivial and sign representations. Precisely these two lines \(W\) are preserved under every permutation, so they are the two equivariant choices of quotient.

Ordinary pullback from the unordered quotient imposes the further condition that every permutation fixing the collision must fix each vector in the stalk. This selects the trivial line. For a physical preparation the choice still requires the attaching map of that preparation. [Four charged rays and their possible attachments](04-factorization.md#ch04-gaussian-collision)

There is a choice even before extending across a collision. Consider the difference between labelling three inputs and arranging them in a word. In the triple \((x,y,x)\) with \(x\ne y\), the first and third inputs can form one cluster disjoint from the middle input. Neither consecutive cut \(1|23\) nor \(12|3\) separates the two blocks. In either cut \(x\) lies on both sides. Thus the choice of cuts determines where separate clusters can be multiplied.

To realise this triple with parallel lines, choose real numbers \(a_1<a_2<a_3\) and put the lines at heights \(t_i=\epsilon a_i\), with \(\epsilon>0\). All three lines are disjoint. Let \(\epsilon\) tend to zero while retaining their order of approach. In the limit, two groups are still disjoint from each other exactly when no spectral value occurs in both. Thus the group of labels \(\{1,3\}\) at \(x\) is separated from \(\{2\}\) at \(y\) even in this increasing order chart. Union of disjoint groups admits this assembly. Concatenating two consecutive blocks of the word omits it. Choosing which groups can serve as inputs to a product is additional data.

One can instead move line 2 past line 3 while \(y\ne x\). The two lines at \(x\) keep their relative order, and the word becomes \((x,x,y)\), with a cut after its second letter. Comparing the two products on quantum states requires an exchange for that middle \(y\)-line and the last \(x\)-line at spectral difference \(y-x\). Fusing the two \(x\)-lines then requires their operation at equal spectral points. The motion alone specifies neither map. [Ordered cuts and separated groups](04-factorization.md#ordered-cut-geometry)

Each word has a coefficient, a complex of right differential modules depending on the positions of its inputs. Cut a word into two blocks of lengths \(p,q\). Write \(U_{p,q}\) for the open set where every position in the first block is distinct from every position in the second. Positions within a block may coincide. Restrict the derived external tensor product of the two block coefficients to \(U_{p,q}\). Its derived direct image extends this coefficient to the whole configuration space.

For a fixed word, summing over consecutive cuts gives an *ordered convolution*. A multiplication for this convolution combines consecutive groups of inputs. On three ordered inputs a homotopy compares the two ways to apply that multiplication, first to the left pair or first to the right pair. The Beilinson–Drinfeld Lie bracket used all three choices of pair in its Jacobi identity.

Write \(A\) for the family of word coefficients with this multiplication. An augmentation maps \(A\) to the scalars supported on the empty word. Its kernel is the augmentation ideal. The bar construction \(BA\) records strings of inputs from this ideal in a complex. Its differential uses the successive ordered multiplications and their higher homotopies. Its coproduct cuts a word.

For an associative chiral algebra in this word construction, the empty word has the scalar field as its bar coefficient. On the separating open, cutting identifies the whole coefficient with the derived external tensor product \(\boxtimes\) of the block coefficients, \((BA)_{p+q}|_{U_{p,q}}\simeq((BA)_p\boxtimes(BA)_q)|_{U_{p,q}}\). At \((x,y,x)\) neither consecutive cut gives this information. A chiral quantum group also needs a rule for how an observable acts on two systems at coincident positions. [The geometry of ordered cuts](04-factorization.md#ordered-cut-geometry) · [The bar construction on words](05-bar-and-coherence.md#ch05-ordered-cuts-give-a-finite-geometric-bar-construction)

## Why representations and centres enter {#why-representations-and-centres-enter}

An enclosing current distinguishes rays of different charges \(a,b\) even when both sectors obey the same operator relations. Each sector is described by a representation, or module, \(M\) of the observable algebra \(A\). An element of \(A\) acts on the states in \(M\), and a product acts by successive operations. Place the two rays side by side. The total charge is \(a+b\). How can a rule on the observables tell us this for every pair of modules?

Let \(M,N\) be two left modules of the same unital associative algebra \(H\). To act on their tensor product, an observable \(h\in H\) must specify which operators to apply to the two factors. For an ordinary bialgebra \(H\), a coproduct \(\Delta:H\to H\otimes H\) supplies a sum of pairs. Write \(h_{(1)},h_{(2)}\) for the first and second entries of each summand of \(\Delta(h)\). Acting term by term on \(m\in M,\ n\in N\) gives the diagonal action
\[
h\cdot(m\otimes n)
=\sum h_{(1)}m\otimes h_{(2)}n,
\qquad
\Delta(h)=\sum h_{(1)}\otimes h_{(2)}.
\tag{1.6}
\]
{#eq-tensor-action}
For a conserved additive charge \(Q\), take \(\Delta Q=Q\otimes1+1\otimes Q\). On a product of states with charges \(a,b\), the two terms act by \(a,b\), giving total charge \(a+b\). Requiring \(\Delta(hh')=\Delta(h)\Delta(h')\) makes acting by a product the same as acting in succession. The algebra unit acts as the identity on both factors because \(\Delta(1)=1\otimes1\).

Coassociativity says that on three modules either grouping gives the same action. A bialgebra also has a counit, a map to the scalars giving a one-dimensional neutral system. Combining a module with this system on either side recovers its original action.

Does flipping the factors carry one module action to the other? It does when the coproduct is invariant under the exchange of factors.

A more general exchange requires a braiding, a natural family of module isomorphisms that exchanges two factors. Moving one factor past a pair, on either side, must agree with moving it past each member in succession. These are the two hexagon equations. A chiral quantum group must solve these problems for operations that depend on position. [Tensor actions](02-algebras-and-modules.md#ch02-a-coproduct-gives-the-action-on-a-tensor-product) · [Exchange and its two hexagons](02-algebras-and-modules.md#ch02-associators-exchange-and-coherence)

What would it take for a fixed insertion in the interior to act centrally as the boundary state varies? Such an action should commute both with the boundary operators and with maps that transport states between boundary representations. For an ordinary algebra \(A\) this asks for an \(A\)-linear operator \(T_M\) on every module \(M\), compatible with every module map. How large is the space of such choices? One vector in the algebra itself determines the answer.

**Proposition (the centre acting on modules).** Let \(A\) be a unital associative algebra over a field. Suppose that every left \(A\)-module \(M\) has an \(A\)-linear operator \(T_M\). Assume \(fT_M=T_Nf\) for every module map \(f:M\to N\). Then a unique element of the centre \(Z(A)=\{z\in A:za=az\text{ for all }a\in A\}\) acts by \(T_M\) on every \(M\).

*Proof.* Let \(A\) act on itself by left multiplication and put \(z=T_A(1)\). Left linearity gives \(T_A(a)=az\). Right multiplication by \(a\) is a left module map, so applying naturality to this map at \(1\) gives \(T_A(a)=za\). Hence \(z\) is central. For \(m\in M\), the map \(A\to M,\ a\mapsto am\), is also a module map. Evaluating its naturality equation at \(1\) gives \(T_M(m)=zm\).

Conversely, multiplication by a central element defines such an \(A\)-linear family. Its value on \(1\in A\) recovers the element uniquely. ∎

The proof used both multiplications on \(A\). A map \(A\to A\) respecting the left and right actions is determined by its value on \(1\), which can be any central element. Thus \(Z(A)\) is the space of these bimodule maps. To describe both actions by a single left action, let \(A^{\mathrm{op}}\) be the algebra with multiplication reversed. An element \(a\otimes b^{\mathrm{op}}\) of \(A\otimes A^{\mathrm{op}}\) sends \(x\in A\) to \(axb\).

For complexes we need the derived space of bimodule maps. Taking a resolution before forming the complex of maps gives derived Hom, written \(\operatorname{RHom}\). It retains maps up to homotopy and their higher extension groups. This gives the Hochschild cochain complex in the derived Hom model, \(C^\bullet(A,A)=\operatorname{RHom}_{A\otimes A^{\mathrm{op}}}(A,A)\). For a chiral boundary one must also compare the actions when points separate or collide.

Combining two probes can reveal a coefficient invisible on either alone. Suppose on one-dimensional probes the readings of three commuting observables are \((x,y,z)\). On an ordered pair one possible law for the third reading is \(z_1+z_2+x_1y_2\). The separate calibrations with the empty probe \((0,0,0)\) give the same result as simple addition. With \((1,0,0)\) followed by \((0,1,0)\), the joint reading is one. Reversing the probes gives zero. Measuring only one probe at a time leaves this part of the combination law undetermined. [How the coproduct expresses this joint action](02-algebras-and-modules.md#ch02-joint-action-on-regular-probes)

## The mathematical problem in its present form {#the-mathematical-problem-in-its-present-form}

In the Gaussian half-space, a supported interior insertion already acts on chosen representatives of the boundary observables. Let \(V\) be open in the boundary and let \(A_\partial(V)\) be its complex of observables for the chosen boundary condition. Choose a bulk open \(U\) at positive normal separation above a thin collar of \(V\).

For a regular bulk cochain \(f\) supported in \(U\), write \(\operatorname{ext}_U(f)\) for its extension by zero to the joint region. The quantum collar inclusion \(i_\hbar\) carries a boundary cochain \(v\) into this region. Multiply the extended insertion by \(i_\hbar(v)\), then apply the projection \(p_\hbar\), which contracts the fluctuations and returns a boundary cochain. The resulting action is
\[
 \beta_{U;V}(f)(v)=p_\hbar\bigl(\operatorname{ext}_U(f)\,i_\hbar(v)\bigr),
 \qquad v\in A_\partial(V).
\]
On the annular polynomial representatives, a unit probe for harmonic \(j\) contracts with a single \(p_n\) to give \(\delta_{jn}\), one for \(j=n\) and zero otherwise. Summing over the factors of a monomial gives \(\partial_{p_j}\). This is the action that supplied the energy-two exchange. The probe can have non-zero differential, and a fixed compact probe can distinguish cohomologous representatives on the whole disk. To reconstruct a bulk theory one would have to characterise *all* compatible actions and show that bulk observables realise them. [The supported probe calculation](11-states-and-lines.md#ch11-relative-phase)

**Open problem (bulk reconstruction).** Fix the class of coherent actions on boundary observables, including their restrictions to separated points and their behaviour at collisions. Does a geometric centre represent these actions, so that a map to the centre specifies an action by pullback of its universal action? Suppose such a centre exists and a bulk theory is specified independently. When do its supported insertions induce an equivalence from bulk observables to this centre that preserves factorisation? [Bulk actions and the universal centre](17-holographic-reconstruction.md#bulk-action-and-centre)

Can a boundary module be recovered after crossing an interface and returning? Suppose the interface gives two functors \(\Phi,\Psi\). The first carries modules from the first side to the second and the other carries modules back. Let \(\Phi\) be left adjoint to \(\Psi\). Take modules \(M,N\) on the first and second sides respectively. The adjunction identifies maps from \(\Phi M\) to \(N\) naturally with maps from \(M\) to \(\Psi N\).

The unit \(\eta_{M'}:M'\to\Psi\Phi M'\) compares a module on the first side with its round trip. Under the adjunction, \(\Phi(g)\) for a map \(g:M\to M'\) corresponds to \(\eta_{M'}\circ g\). Testing this postcomposition on maps from every \(M\) detects whether the unit at \(M'\) is an equivalence. Thus the unit is an equivalence on every module precisely when \(\Phi\) induces equivalences on all spaces of maps.

The counit \(\Phi\Psi\to\mathrm{id}\) tests recovery on the second side. For example, give a vector space the trivial action of an involution when crossing to the second side. On the return, take the vectors fixed by the involution. Starting from the first side, this recovers every vector. Starting instead with an arbitrary representation, the counit includes its fixed vectors into the whole representation.

Even when both round trips are equivalences, matching the state of a specified filling requires more. Its absolute vacuum amplitude can be a scalar or a vector in a determinant line. In the latter case one must identify the two lines and compare the amplitude vectors under that identification. The ray coefficient \(r^{-a^2}\) is a scalar that cancels from the normalised collar reading. [The unit and counit](06-duality-and-induction.md#adjunction-comparison-maps) · [The amplitude of a filling](17-holographic-reconstruction.md#states-lines-and-caps)

A comparison that preserves products of boundary fields must also preserve the space in which a successive product takes values. Fuse the first two fields in a Laurent series in their separation \(p\). Let \(V\) be the complex vector space of their coefficients and \(W\) the state space of the third field.

Tensoring after expansion gives \(V((p))\otimes W\). Expanding after tensoring gives \((V\otimes W)((p))\). In both expressions the series have finitely many negative powers. The map from the first space to the second sends an elementary tensor to the series obtained by tensoring each coefficient with its \(W\)-factor. Extend this rule by linearity.

To see what the map can miss, choose \(v\ne0\) in \(V\) and independent \(w_0,w_1,\ldots\) in \(W\). The second space contains \(\sum_{j\ge0}(v\otimes w_j)p^j\). An algebraic tensor in the first space is a finite sum, so all its coefficients use vectors from one finite-dimensional subspace of \(W\). Applying a functional on \(V\) taking \(v\) to \(1\) gives every \(w_j\) from the displayed coefficients, ruling out such a bound. Comparing the two orders of operation therefore requires a choice of coefficient space. [Laurent series with algebraic coefficients](08-completions.md#ch08-laurent-series-with-algebraic-coefficients)

For a symmetry acting on a boundary, which operators of a second system can couple to its generators? On the energy-two span of \(a,b\), let \(P\) project onto \(a\). Let \(E\) send \(b\) to \(a\) and \(a\) to zero. Then \(PE=E\) and \(EP=0\). Their commutator equals \(E\), so the two operators can represent generators whose bracket is the second generator.

Adding a non-zero multiple of the identity to the second operator leaves the commutator unchanged and breaks that relation. The algebra representing the solutions determines which couplings are possible on one system. Combining two solutions asks for an action on a tensor product. [The coupling equation](02-algebras-and-modules.md#ch02-consistent-lie-couplings) · [The action on a pair](02-algebras-and-modules.md#ch02-a-coproduct-gives-the-action-on-a-tensor-product)

::: figure fig-programme-overview
