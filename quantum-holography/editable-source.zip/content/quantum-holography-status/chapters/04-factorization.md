# Factorisation and collision geometry

How can the product of two fields at nearby points serve as an input to a third field? Place two Heisenberg currents at \(z,w\) on the complex plane. Prepare the vacuum. After the two insertions, apply the functional that extracts the vacuum coefficient and takes value one on the vacuum. At level \(\kappa\) this gives \(\kappa/(z-w)^2\). Hold \(w\) fixed and take a small positively oriented circle about it. If the weight \(f\) is holomorphic on and inside the circle, integration gives
\[
 \frac{1}{2\pi i}\oint_{w} f(z)\frac{\kappa}{(z-w)^2}\,dz
 =\kappa f'(w).
\]
The weights \(1\) and \(1+(z-w)\) agree at the collision. They give \(0\) and \(\kappa\), respectively. At nonzero level the residue distinguishes their first derivatives in the direction normal to the collision diagonal \(z=w\). [The free-current vacuum coefficient, (3.11)](03-local-fields.md#eq-3-11)

Now take three fields at \((z_1,z_2,z_3)=(w+t,w,y)\). Bring the first two together, keeping the third field, the spectator, at \(y\ne w\). Choose a circle about \(w\) of radius \(R\) with \(|t|<R<|w-y|\). For sufficiently small \(t\) it encloses the first pair and leaves the spectator outside. To select a coefficient of the pair product, take a weighted residue in the separation \(t\). For the two currents, weight \(t\) selects their double-pole coefficient, \(\kappa\) times the vacuum field at \(w\). This field can act on the spectator. The two inputs to that operation occupy \(w\) and \(y\), the partial collision \((w,w,y)\) in the original three coordinates.

Which separations may vanish during that first operation? The product \((z_1-z_3)(z_2-z_3)\) must stay nonzero. On \((w,w,y)\) it becomes \((w-y)^2\). Thus one open set contains both the approaching triple and the partially collided pair, and it excludes the final collision with the spectator. Bringing the last two fields together first requires the open set where the *first* field stays apart.

::: {.example title="A neutral pair and a charged spectator"}
The spectator can detect a term that the vacuum functional on the pair misses. Take three Wilson rays in Gaussian abelian Chern–Simons theory at level \(1\), with charges \(q_1=1,\ q_2=-1,\ q_3=1\). Prepare the incoming charge states without oscillator excitations. Use the planar Cauchy propagator, subtract self-contractions with parallel-copy framing and divide out the mutual contraction factor at the outgoing ends. In the separated chamber the pair with \(i<j\) contributes \((z_i-z_j)^{q_iq_j}\). The outgoing functional extracts the oscillator-free coefficient and gives one on the oscillator-free vector of the chosen total charge.

Put \(t=z_1-z_2\) and \(v=z_2-z_3\). For the neutral pair alone the charge-zero vacuum coefficient is \(1/t\). With the spectator present the total charge is \(1\), and the three pair factors give
\[
 F(t,v)=\frac1t\,\frac{v+t}{v}
       =\frac1t+\frac1v .
\]
{#eq-ch04-neutral-pair-with-spectator}
At fixed \(v\ne0\) the unweighted residue in \(t\) is \(1\), the same as for the isolated pair. Weighting by \(1/t\) extracts the constant term. It is zero in the vacuum coefficient of the isolated pair. In the three-ray coefficient it is \(1/v\), whose residue at \(v=0\) is \(1\).

Which field gives this second residue? Centre a current contour at \(z_2\), with radius between \(|t|\) and \(|v|\). For \(n>0\), the weight \((z-z_2)^n\) evaluates to \(t^n\) on the unit charge at \(z_1\) and to zero on the opposite charge at \(z_2\). In the Fock representation the negative current mode \(J_{-n}\) multiplies by the polynomial variable \(p_n\). At level one the positive mode \(J_n\) acts by \(n\partial_{p_n}\). Thus the neutral pair state \(\Psi\) satisfies \(n\partial_{p_n}\Psi=t^n\Psi\) for all \(n>0\), with vacuum coefficient \(1/t\). Write \(|0\rangle\) for the neutral vacuum. Solving at each oscillator weight gives the formal series
\[
 \Psi(t)=\frac1t\exp\!\left(\sum_{n>0}\frac{t^n p_n}{n}\right)|0\rangle
       =\frac1t|0\rangle+J_{-1}|0\rangle+O(t).
\]
The constant term \(J_{-1}|0\rangle\) is the state of the current. Place its field at \(z_2\). The current has a simple pole with the unit charge at \(z_3\), with coefficient \(+1\), giving the missing \(1/v\). [Charge read by a current contour](03-local-fields.md#ch03-charged-current-contour) · [The Gaussian ray coefficient](#ch04-gaussian-collision)
:::

For the first operation the pair and the spectator had to stay apart. Within the pair, the two positions were allowed to coincide. These are the two geometric conditions in factorisation. One must give both the product of independent blocks and a rule for restricting a section when positions in a block coincide.

## Configurations and partial diagonals {#configuration-spaces}

**Definition (configuration space).** Let \(X\) be a smooth algebraic curve over a characteristic-zero field \(k\). For a finite nonempty set \(I\), the product \(X^I\) records an \(I\)-labelled family of points. Its open configuration space is
\[
U_I=\{(x_i)\in X^I:x_i\ne x_j\text{ whenever }i\ne j\}.
\tag{4.1}
\]
Write \(j_I:U_I\hookrightarrow X^I\) for its inclusion. The **small diagonal** is the map
\[
\Delta_I:X\longrightarrow X^I,
\qquad x\longmapsto(x)_{i\in I}.
\]
Its image is the locus where all the labelled points coincide. For two labels \(i,j\), the partial diagonal \(\Delta_{ij}\) imposes only \(x_i=x_j\).

In the three-field calculation \(U_{\{1,2,3\}}\) is too small for the first residue. It contains the contour but omits the locus \(z_1=z_2\) that supports the residue. For the grouping \(12|3\) we need only \(z_1\ne z_3\) and \(z_2\ne z_3\). For any grouping, let \(J\) be the set of field labels and \(I\) the set of blocks. Assigning each label to its block gives a surjection \(\pi:J\twoheadrightarrow I\) with nonempty fibres \(J_i=\pi^{-1}(i)\). The required open is
\[
U_\pi=\{(x_j)\in X^J:
x_j\ne x_{j'}\text{ if }\pi(j)\ne\pi(j')\}.
\tag{4.2}
\]
No inequality is imposed within any one block. To put all the labels of a block at a single position, use the diagonal map
\[
\Delta_\pi:X^I\longrightarrow X^J,
\qquad(x_i)\longmapsto(x_{\pi(j)})
\]
Each label receives the position of its block. The image is the locus where the points in each block coincide.

For \(12|3\) the diagonal sends \((x,y)\) to \((x,x,y)\). Compare \(U_\pi\) with the image of \(\Delta_\pi\) on a coordinate line. The configuration \((0,1,2)\) lies in \(U_\pi\) and off this diagonal. The partial collision \((0,0,2)\) lies in both sets, and \((0,0,0)\) lies on the diagonal alone. Pulling \(U_\pi\) back to the two block positions therefore gives precisely \(x\ne y\). For any \(\pi\), two distinct blocks must occupy different positions. This proves \(\Delta_\pi^{-1}(U_\pi)=U_I\).

## A chiral operation is a map with a collision target {#chiral-operation}

Before colliding two fields, one can multiply them by \(1/(z-w)\). At separated positions this is an ordinary function. At coincidence the test by a residue still makes sense, even though the multiplier has a pole. To allow such inputs, take right \(\mathcal D_X\)-modules \(L_i\) for the fields and \(M\) for their output. In the external tensor product \(\boxtimes_{i\in I}L_i\), the \(i\)-th factor depends on the \(i\)-th position. Restrict this module to \(U_I\) and take its direct image back to \(X^I\). The resulting input module is
\[
j_{I*}j_I^*\Bigl(\boxtimes_{i\in I}L_i\Bigr).
\]
On a coordinate chart for two points this adjoins \((z-w)^{-1}\). Each section has finite pole order. For a field originally given as a left differential module, tensoring with the one-forms \(\omega_X\) gives the right module used here. This convention fixes the density in the residue. [Right differential modules for fields](03-local-fields.md#differential-modules)

**Definition (chiral operation).** The direct image \(\Delta_{I*}M\) is a differential module on \(X^I\) supported on the small diagonal. It includes derivatives in directions normal to that diagonal. A **chiral \(I\)-operation** is a differential-module map
\[
\mu:
j_{I*}j_I^*\Bigl(\boxtimes_{i\in I}L_i\Bigr)
\longrightarrow\Delta_{I*}M.
\tag{4.3}
\]
Thus its space is
\[
P_I^{\mathrm{ch}}((L_i);M)
=\operatorname{Hom}_{\mathcal D_{X^I}}
\left(j_{I*}j_I^*\boxtimes_iL_i,\Delta_{I*}M\right).
\tag{4.4}
\]
Both arguments of the Hom are modules on \(X^I\). Restrict (4.3) to the distinct open for \(|I|>1\) and its target becomes zero. On \(X^I\) the output remains supported at the collision. A regular weight can already detect a pole coefficient there, as \(1+(z-w)\) did for the double pole. Localising the input also allows weights with poles. This is the operation space of Beilinson–Drinfeld, *Chiral Algebras*, §3.1.1.

To see what a normal derivative detects, put \(t=z-w\) and hold \(w\) fixed. A pole of integral order \(r\ge1\) acts on a test series \(f(t)\) by the residue
\[
\operatorname{Res}_{t=0}\frac{f(t)}{t^r}\,dt
=\frac{f^{(r-1)}(0)}{(r-1)!}.
\tag{4.5}
\]
Use the ordered density frame \(dz\wedge dw=dt\wedge dw\). The unit operation on two one-forms takes a meromorphic two-form to its principal part, its class modulo forms regular along \(t=0\). The class of \(t^{-1}dz\,dw\) gives the diagonal generator \(dw\). The class of \(t^{-2}dz\,dw\) paired with \(f(z)\) gives \(f'(w)\,dw\), as in the current calculation. Thus a principal part with coefficient \(A(w)t^{-2}+B(w)t^{-1}\) in this frame returns \(\bigl(A(w)f'(w)+B(w)f(w)\bigr)\,dw\). Taking \(f=1\) reads \(B(w)\), and taking \(f=z-w\) reads \(A(w)\). The supported output retains both coefficients.

Keep the spectator at \(y\) and take the first residue at \(z_1=z_2=x\). In the residue pairing for densities, write \(s=z_1-z_2\) and \(v=z_2-z_3\). The simple pole \(1/(sv)\) has residue \(1/v\) in \(s\). At \((x,x,y)\) the multiplier \(1/(x-y)\) survives. The output therefore lies on the partial diagonal and still allows poles in the remaining separation.

Write \(\delta_{12}(x,y)=(x,x,y)\) and \(j:U_2\hookrightarrow X^2\) for the inclusion of the distinct pairs \(x\ne y\). On three labels, use \(j_3=j_{\{1,2,3\}}\) and \(\Delta_3=\Delta_{\{1,2,3\}}\) for the distinct-open and small-diagonal inclusions. Let \(N\) be the output module of the first binary operation. For fields in \(L_1,L_2,L_3\) and final output in \(M\), substitution gives the composite on \(X^3\)
\[
\begin{aligned}
 &j_{3*}j_3^*(L_1\boxtimes L_2\boxtimes L_3)\\
 &\quad\longrightarrow\delta_{12*}j_*j^*(N\boxtimes L_3)
 \longrightarrow\Delta_{3*}M .
\end{aligned}
\]
Over \(U_{12|3}\) the inner operation acts on the first two inputs while the spectator stays apart. Its output lies on \(\delta_{12}\). The inverse image of this open under \(\delta_{12}\) is \(U_2\), so direct image from the open gives the middle module displayed above. The second arrow applies the outer binary operation to \(j_*j^*(N\boxtimes L_3)\) and pushes the result forward along \(\delta_{12}\). For \(1|23\) the middle module lies on a different partial diagonal. Both composites belong to the ternary space (4.4). Substitution along a fixed sequence of partitions is associative. Equality of the two ternary maps obtained by bracketing one specified binary operation is an additional identity on that operation. [Beilinson–Drinfeld, *Chiral Algebras*, §3.1.2](https://math.uchicago.edu/~drinfeld/langlands/chiral/cha_ch3.pdf#page=2)

There are two readings even for the simple pole of a rational differential. Take the ordered points \(s=0,t\) and the form \(ds/[s(s-t)]\). With a test polynomial \(g\), the sum of its two residues is \((g(t)-g(0))/t\). For \(g(s)=s^2\) this gives \(t\). At the collision the value is zero, but at the infinitesimal displacement \(t=\epsilon,\ \epsilon^2=0\), the reading is \(\epsilon\). Conversely, inverting a local equation \(u\) of the diagonal sends the module \(k[u]/(u)\) to zero, since localisation is flat and \(u\) then acts invertibly. A kernel over configurations retains the displacement, its allowed expansions and the coefficient attached at coincidence. A comparison of joint field actions must commute with these maps. [A finite determination of generator poles](12-chiral-quantum-groups.md#ch12-bounded-chiral-reconstruction) · [Transport of a joint action](17-holographic-reconstruction.md#products-through-an-interface)

## The Lie convention and the full operator product {#lie-and-operator-product}

**Definition (chiral algebra).** In the classical Beilinson–Drinfeld convention, a non-unital **chiral algebra** is a right differential module \(A\) with a binary operation
\[
\mu\in P_2^{\mathrm{ch}}(A,A;A)
\]
that is skew-symmetric under exchange of the two labelled inputs and satisfies Jacobi. In the ternary operation space this means that the signed sum of the composites that first bracket \(1,2\), \(2,3\) and \(3,1\) vanishes. Thus \(A\) is a Lie algebra object for chiral operations. A unit is a differential-module map \(\omega_X\to A\). Inserting it in the left slot of the bracket with \(A\) must give the canonical residue operation on a one-form and an \(A\)-valued input. See *Chiral Algebras*, §§3.3.1–3.3.3.

The Lie bracket of modes uses only the singular terms of a field product. To see what else the geometric chiral bracket determines, multiply a regular term \(c_q(w)t^q\), \(q\ge0\), by \(t^{-q-1}\) and take the residue in \(t=z-w\). This recovers \(c_q(w)\), since no other power contributes. All these Laurent multipliers belong to the source of (4.3).

To retain the coefficients together, pass from right modules to left modules by removing the density factor. Let \(a,b\) be local sections of the resulting left module. Complete along \(z=w\) to allow all nonnegative powers of \(t\), then invert \(t\) to allow a finite pole for each pair of inputs. Write \(c_n(w)\) for the section at \(w\) multiplying \(t^n\). The full operator product determined by the bracket then has the local form
\[
a\boxtimes b\longmapsto
\sum_{n\in\mathbb Z}c_n(w)(z-w)^n,
\tag{4.6}
\]
with coefficients in the left module at \(w\) and only finitely many negative powers for fixed \(a,b\). For vertex fields in a translation coordinate, \(c_q\) is the field coefficient \(a_{(-q-1)}b\). In particular \(c_0=a_{(-1)}b\) is the normal product. On three copies of the current state \(j\), its left bracketing minus its right bracketing is \(\kappa T^2j\), where \(T\) is translation. Taking the constant term before the next multiplication can discard terms that contribute to that multiplication. [The current associator](03-local-fields.md#ch03-example-the-normal-product-associator)

Keeping all the coefficients changes the question. For the order \(1,2,3\), the two familiar bracketings bring \(1,2\) or \(2,3\) together first. On the labelled curve \(1,3\) may also collide while \(2\) stays apart. Each choice of pair gives a region for an iterated expansion. Can the three expansions be obtained from a single three-field product?

Beilinson–Drinfeld's Theorem 3.5.10 identifies chiral Lie brackets with commutative and associative *full operator products*. In the conversion from a bracket to a full product the ordered density factors supply the sign under transposition. Commutativity of the full product exchanges the point-labelled inputs. For associativity, let \(d_0\) send a full ternary expansion to its three successive expansions. The next map \(d_1\) takes the tuple to the signed sum of its collision residues in the ternary operation space, with the density sign. Exactness states that a tuple of iterated products comes from one full expansion precisely when \(d_1\) kills it. For the product obtained from the bracket, this sum is Jacobi. The individual residues can differ. [Beilinson–Drinfeld, *Chiral Algebras*, §3.5.10, pp. 198–199](https://math.uchicago.edu/~drinfeld/langlands/chiral/cha_ch3.pdf#page=43)

### Three residues and the obstruction to strict associativity on the diagonal {#ch04-three-residues}

::: {.example title="Three oriented residues"}
Translate the third point to the origin by writing \(u=z_1-z_3,\ v=z_2-z_3\). Use the two-form \(F\,du\wedge dv\) with \(F=1/[u(u-v)]\). It has poles at \(z_1=z_2\) and \(z_1=z_3\), and is regular at a generic point of \(z_2=z_3\). For a collision in two stages, first take the residue in the separation of the colliding pair, then in the remaining separation. To collide 1 with 2 first, set \(s=u-v\). The form has orientation \(du\wedge dv=ds\wedge dv\). Near \(s=0\) with \(v\ne0\) its coefficient expands as
\[
 F=\frac{1}{s(v+s)}
   =\frac{1}{sv}-\frac{1}{v^2}+\frac{s}{v^3}-\cdots .
\]

The coefficient of \(s^{-1}\) is \(v^{-1}\), so the second residue is \(1\). Collide 2 with 3 first and the expansion \(F=u^{-2}(1-v/u)^{-1}\) is regular in \(v\), giving \(0\). Collide 1 with 3 first and \(F=-u^{-1}v^{-1}(1-u/v)^{-1}\) has first residue \(-dv/v\), giving \(-1\). The three oriented contributions add to \(1+0-1=0\). The collision of \(1,3\) supplies the third term in the residue form of Jacobi.
:::

Could a binary chiral operation give the same ternary map in the first two orders? Equality would have to hold on every localised input. At the first step the separation \(z_1-z_3\) is invertible in *both* orders.

**Proposition (ternary diagonal operations).** Fix the three inputs and final output in the ternary space (4.4) for ordinary right differential modules, with the fully localised source and unshifted target of (4.3). Allow the intermediate module to vary. The linear spans of composites through \(12|3\) and \(1|23\) have zero intersection in this ternary space. Consequently a strictly associative binary operation in these spaces has zero triple products.

*Proof.* Near the small diagonal choose a local étale coordinate and put \(s=z_1-z_2\), \(v=z_2-z_3\), \(h=z_1-z_3=s+v\). Fix a section \(e\) of the fully localised input. Let \(\alpha_{12}\) and \(\alpha_{23}\) be the first arrows in the two channels. The section \(\alpha_{12}(e)\) involves finitely many derivatives normal to \(\Delta_{12}\), so \(s^a\alpha_{12}(e)=0\) for some \(a\ge1\). Likewise \(v^b\alpha_{23}(e)=0\) for some \(b\ge1\).

In the first intermediate module \(v\) is invertible. For a section \(y\) with \(s^2y=0\), multiplying \(v^{-1}y-v^{-2}sy\) by \(h=v+s\) gives \(y\). For a section killed by \(s^a\), the same geometric sum ends after \(a\) terms. In the second intermediate module \(s\) is invertible and \(v\) acts nilpotently on each section. Thus \(h\) acts invertibly in both modules. The first arrows commute with multiplication by functions and hence with \(h^{-1}\). For every integer \(N\ge0\) this gives \(s^a\alpha_{12}(h^{-N}e)=h^{-N}s^a\alpha_{12}(e)=0\), and likewise \(v^b\alpha_{23}(h^{-N}e)=0\).

Suppose that the two composites give the same map \(F\). Take \(N=a+b-1\) and expand \(e=(s+v)^Nh^{-N}e\). A summand with \(i\) factors of \(s\) contains \(N-i\) factors of \(v\). If \(i\ge a\), its image under \(\alpha_{12}\) vanishes. If \(i<a\), then \(N-i\ge b\) and its image under \(\alpha_{23}\) vanishes. Since either composite computes \(F\) on each summand, \(F(e)=0\). All divisions by \(h\) took place before the outer arrows, whose target is supported on \(h=0\). A finite sum of composites factors through the direct sum of their intermediate modules, where the same argument applies. The two bracketings of a strictly associative operation give an element of the intersection and therefore vanish. ∎

**Consequence (vacuum obstruction).** Suppose the left action of the vacuum is the normalised principal-part map. Insert two vacua followed by any state, with simple poles in the successive separations \(s,v\). The first residue returns the vacuum with multiplier \(1/v\), and the second returns the state. Strict associativity would make this triple operation zero by the proposition. A nonzero ordinary object on this carrier therefore cannot have both the specified vacuum and a strictly associative binary operation.

For a cochain complex \(A\), the differential raises degree by one, and \(H^q(A)\) consists of degree-\(q\) cycles modulo boundaries. Take complexes of right algebraic differential modules with quasi-coherent underlying modules. Suppose the multiplication is associative up to a degree-\(-1\) homotopy of ternary operations on the fully localised source with unshifted small-diagonal target. Suppose also that the left action of a closed degree-zero vacuum is homotopic to principal parts. External tensor over the field, localisation and diagonal direct image are exact in the required variables. Thus the two bracketings induce equal maps on cohomology, and the induced left vacuum action is principal parts. The ordinary obstruction in each degree gives \(H^q(A)=0\) for every \(q\), hence \(A\simeq0\). An associative algebra on configuration complexes requires a choice of coefficient at each configuration and a multiplication on those coefficients. [Associativity in the bar complex](05-bar-and-coherence.md#ch05-one-differential-encodes-all-associativity-homotopies)

## Factorisation across a collision {#factorization-algebra}

At two positions the residue uses a meromorphic input. To *restrict* a section to the diagonal, we first have to know which sections extend there. With regular functions on \(X^2\), \(f(z)g(w)\) extends and has value \(f(w)g(w)\) on the diagonal. On a coordinate chart \(1/(z-w)\) is also regular on the distinct open and has no such value. Both are legitimate separated inputs. The distinction is the sheaf \(\mathcal O_{X^2}\) of sections admitted across the collision. For general fields we must supply its analogue \(B_{\{1,2\}}\) and the identifications before and after the collision.

::: {.definition #ch04-definition-factorization-algebra}
**Definition (factorisation algebra).** In the classical algebraic formulation, a factorisation algebra consists of quasi-coherent sheaves \(B_I\) on \(X^I\) with two kinds of identifications. For a surjection \(\pi:J\twoheadrightarrow I\), ordinary sheaf pullback \(\Delta_\pi^*\) restricts \(B_J\) to the repeated positions. The first identification is
\[
\nu_\pi:\Delta_\pi^*B_J\xrightarrow{\sim}B_I
\tag{4.7}
\]
For the second, view \(X^J\) as the product of the spaces \(X^{J_i}\) of positions in the blocks. On the open where different blocks stay apart, the factorisation isomorphism is
\[
c_\pi:
\left.\boxtimes_{i\in I}B_{J_i}\right|_{U_\pi}
\xrightarrow{\sim}
\left.B_J\right|_{U_\pi}.
\tag{4.8}
\]
The diagonal identifications compose under successive collapses. The open identifications compose under refinements of a partition. Restriction along a diagonal inside the blocks must commute with forming the separated product. The \(B_I\) have no nonzero local sections supported on the union of collision diagonals. A unit is a global section \(1\in B_{\{1\}}\). For each local singleton section \(b\), the separated product of \(1\) with \(b\) must extend locally to \(B_{\{1,2\}}\) and restrict to \(b\) on the diagonal. These are the ordinary sheaf conditions of *Chiral Algebras*, §§3.4.2–3.4.4.
:::

Test the compatibility at the partial collision \((x,x,y)\), with \(x\ne y\). For functions the separated section is \(f(z_1,z_2)g(z_3)\). Form it on \(U_{12|3}\) and then set \(z_1=z_2=x\). Alternatively evaluate \(f\) at \((x,x)\) first and multiply by \(g(y)\). Both operations give \(f(x,x)g(y)\). The constant function \(1\) satisfies the unit condition.

For general sections compare the maps on the open \(x\ne y\), the inverse image of \(U_{12|3}\) under \((x,y)\mapsto(x,x,y)\). One route pulls back \(c_{12|3}\) to this open and then applies \(\nu_{12|3}\). The other applies the diagonal identification to the first block and then the separated product to the two singleton coefficients. Compatibility makes these maps equal.

A separated section can be restricted further to a total collision only if it extends. The kernel of restriction from \(B_{\{1,2\}}\) to its localisation consists of sections supported on the diagonal. The axiom makes this kernel zero. On the open, (4.8) identifies the two-point sheaf with the external product of the singleton sheaves. A separated section has a diagonal value by (4.7) precisely when it lies in the image of \(B_{\{1,2\}}\) in this localisation. For complexes of sheaves the corresponding restrictions use derived pullbacks, and the identifications must be coherent equivalences.

The tuples \((x,y)\), \((x,x,y)\) and \((y,x)\) correspond to the same finite subset when \(x\ne y\). The diagonal and relabelling identifications explain why one often describes the compatible family as a sheaf on the **Ran space** of \(X\). At the level of points, this is the set of finite nonempty subsets of \(X\). Repeating a label leaves the subset unchanged. The maps \(\Delta_\pi\) express exactly those repetitions. One may use the compatible family \((B_I,\nu_\pi)\) without treating the Ran space as an ordinary finite-dimensional variety.

::: {.theorem #ch04-theorem-classical-factorization-and-chiral-algebras}
**Theorem (classical factorisation and chiral algebras).** On \(X\) the category of unital factorisation algebras, with maps preserving the two identifications and the unit, is equivalent to the category of unital Beilinson–Drinfeld chiral algebras. The factorisation sheaves have canonical left differential-module structures. The corresponding right differential module on \(X\) is \(\omega_X\otimes B_{\{1\}}\), with tensor product over \(\mathcal O_X\).
:::

Start with a factorisation algebra and put \(A=\omega_X\otimes B_{\{1\}}\). For a pair of inputs, (4.8) identifies their separated coefficients with \(B_{\{1,2\}}\). Apply the principal-part operation to the two densities, tensored with the identity on this sheaf. On the supported output (4.7) identifies the diagonal coefficient with \(B_{\{1\}}\). The composite is the chiral bracket (4.3) on \(A\).

Conversely, given a chiral bracket on \(A\), we must recover the sheaf on every configuration. On two labels let \(j\) include the distinct pairs and \(\Delta\) the diagonal. The Chevalley–Cousin complex has the localised product \(j_*j^*(A\boxtimes A)\) for the partition \(1|2\) in degree \(-2\), and \(\Delta_*A\) for \(12\) in degree \(-1\). Its differential is the bracket. Each block contributes a shifted copy \(A[1]\) in degree \(-1\), so exchanging two block factors introduces a minus sign. More generally, for a partition into \(r\) blocks, localise the product in the differences between block positions and take its direct image along the partition diagonal. This is the term in degree \(-r\). Its differential brackets two blocks and leaves the others in place. Two mergers among three blocks give the three signed terms of Jacobi. Disjoint mergers cancel in opposite orders. Thus the differential squares to zero.

Concentration in one degree also uses the unit. On two labels the bracket with a vacuum input is the principal-part quotient, which surjects onto the diagonal term. In all arities Beilinson–Drinfeld's acyclicity lemma gives vanishing outside degree \(-|I|\). In the left-module convention the surviving kernel is \(B_I\). The diagonal and separated identifications come from (3.4.11.3)–(3.4.11.5) of *Chiral Algebras*. The canonical connection, equivalence and inverse construction are Proposition 3.4.7, Theorem 3.4.9 and §§3.4.8–3.4.12, in particular Lemma 3.4.12. [The two-point reconstruction from a realised vacuum](13-geometric-reconstruction.md#ch13-the-realized-vacuum-on-every-configuration)

## Which collisions can a cut in a word separate? {#ordered-cut-geometry}

Write three points in order as \((x,y,x)\) with \(x\ne y\). The partition \(13|2\) separates the two positions. Neither \(1|23\) nor \(12|3\) does. If the labels form a word, a cut must keep their order, so it imposes a separation condition on a different open set.

::: {.example #ch04-parallel-line-heights title="Moving two parallel Wilson lines"}
Place two straight Wilson lines along the positive \(s\)-direction in \(\mathbb R_s\times\mathbb R_t\times X\). The line at \((t_i,z_i)\) consists of the points \((s,t_i,z_i)\) for \(s\in\mathbb R\). Its height \(t_i\) is a transverse coordinate in the topological plane, and \(z_i\in X\) is its spectral position. For this motion take a smooth Hausdorff second-countable complex curve \(X\) with its analytic topology. Fix both spectral positions and start the lines at heights \(-h,h\), with \(h>0\). Move each height linearly to the initial height of the other. Halfway through, the two heights agree. If \(z_1\ne z_2\), the lines are still disjoint. If \(z_1=z_2\), *every* continuous reversal of their heights at these fixed marks passes through an intersection. The sign of \(t_2-t_1\) at the common mark can therefore distinguish two preparations even when the distance between the lines is forgotten. [Reduction and the choice of measurements](01-physical-questions.md#reduction-must-retain-the-measurements)
:::

The positions on the curve can vary while the labels retain their order \(1,\ldots,n\). An order-preserving surjection collects consecutive labels into each fibre. For instance, the surjection \(12|3\) repeats the first position by the closed diagonal \(d:X^2\hookrightarrow X^3\), \(d(x,y)=(x,x,y)\). What should a coefficient on \(X^3\) give on the repeated word? For complexes of right differential modules the *extraordinary pullback* \(d^!\) is right adjoint to direct image \(d_*\). If the coefficient is the direct image of \(N\) on the diagonal, Kashiwara's equivalence gives \(d^!d_*N\simeq N\). For the ordered construction take \(X\) separated and of finite type, and the underlying modules quasi-coherent. A word coefficient system specifies complexes \(M_n\) on \(X^n\) and coherent identifications along these repetitions, in particular \(d^!M_3\simeq M_2\). To repeat a position three times, first send \(x\) to \((x,x)\), then repeat either coordinate. Both composites send \(x\) to \((x,x,x)\), and the two composite pullback identifications must agree coherently.

For \((x,y,x)\) with \(x\ne y\), the labels at \(x\) are separated by the label at \(y\). No order-preserving surjection collapses the outside labels while leaving the middle one in place.

**Definition (consecutive cut).** For \(0<p<n\), the cut after the \(p\)-th input separates the blocks \(\{1,\ldots,p\}\) and \(\{p+1,\ldots,n\}\). Every point in the first block must be distinct from every point in the second. Thus its open set is
\[
U_{p,n-p}=X^n\setminus\bigcup_{i\le p<j}\Delta_{ij}.
\tag{4.9}
\]
Collisions within either block are allowed. These are the opens used by the consecutive-cut tensor product in Chapter 5.

One way to realise the cut is to put the \(i\)-th line at \(t_i=\epsilon a_i\) with fixed \(a_1<\cdots<a_n\). For each \(\epsilon>0\) all the lines are disjoint. Let \(\epsilon\) tend to zero from above with the \(z_i\) fixed, retaining their order of approach. At the endpoint every line of the first block stays apart from every line of the second precisely on \(U_{p,n-p}\). This statement about positions takes no limit of a quantum product. Even in this increasing chart the open for the grouping \(13|2\) is \(\{z_1\ne z_2,\ z_3\ne z_2\}\). It contains \((x,y,x)\). At that tuple the outside pair reaches one mark while the middle line reaches the other. Keeping only consecutive assemblies discards this preparation.

For instance, at \((x,x,y,y)\) with \(x\ne y\) the middle cut separates the two \(x\)-inputs from the two \(y\)-inputs. We can form the two pair products independently. Interchange the middle labels to obtain \((x,y,x,y)\). The first cut puts \(x\) on both sides, the last puts \(y\) on both sides, and the middle cut puts both values on both sides. The same grouping by position is now \(13|24\). To transport the original composition to this order requires an exchange of the middle inputs. A rule for products along a word supplies only its consecutive cuts. [An exchange tested on three fields](05-bar-and-coherence.md#ch05-from-support-to-fields)

In arity three, the two consecutive cuts give
\[
U_{1,2}=X^3\setminus(\Delta_{12}\cup\Delta_{13}),
\qquad
U_{2,1}=X^3\setminus(\Delta_{13}\cup\Delta_{23}).
\]
Their common failure locus, as a closed set, is
\[
\begin{aligned}
Z_3
&=X^3\setminus(U_{1,2}\cup U_{2,1})\\
&=(\Delta_{12}\cup\Delta_{13})
\cap(\Delta_{13}\cup\Delta_{23})
=\Delta_{13}.
\end{aligned}
\tag{4.10}
\]
If \(x_1=x_3\), that equality crosses both cuts. Conversely, suppose both cuts fail and \(x_1\ne x_3\). The first cut can then fail only at \(x_1=x_2\), and the second only at \(x_2=x_3\), contradicting \(x_1\ne x_3\). In (4.10) the middle coordinate \(x_2\) is unrestricted. A coefficient that vanishes on both opens can therefore be nonzero at \((x,y,x)\) even when \(x\ne y\). Whether it survives there depends on the coefficient. [The support theorem and two different supports](05-bar-and-coherence.md#ch05-the-support-remembers-which-cuts-were-allowed)

At \((x,y,x)\) the coincident labels \(1,3\) occur in that order. The ordering \(1,3,2\) preserves their order and makes their collision consecutive. This is the overlap used to form the full ordered collision atlas. Take one chart \(X^I\) for each total order on \(I\). Glue two charts wherever their orders agree within each cluster of coincident labels. At two distinct points the two charts agree, but both ordered decompositions \(1|2\) and \(2|1\) are available for forming products. A fixed increasing word allows only the first cut.

The consecutive-cut rule on a fixed word makes this choice of assembly. To recover the charts themselves, return to the analytic curve in the experiment with two moving lines. For \(n\ge2\) labelled lines, form their space of transverse positions
\[
 E_n=\{(t,z)\in\mathbb R^n\times X^n:
             z_i=z_j\ \Longrightarrow\ t_i\ne t_j\quad(i\ne j)\}.
\]
In each fibre over a fixed \(z\), identify two height vectors if one can be moved to the other along a path in that fibre. Denote the quotient with its quotient topology by \(D_n(X)\) and the projection by \(q:E_n\to D_n(X)\).

::: {.proposition #ch04-height-quotient title="Order charts from transverse positions"}
There is a chart \(X^n\) of \(D_n(X)\) for every total order \(\sigma\) on the labels. If \(i<_{\sigma}j\) means that \(i\) precedes \(j\), two charts identify their position coordinates on the open
\[
 U_{\sigma\tau}=X^n\setminus
      \bigcup_{i<_{\sigma}j,\ j<_{\tau}i}\Delta_{ij}.
\]
The map \(q\) is a locally trivial topological \(\mathbb R^n\)-bundle and a weak homotopy equivalence. It commutes with relabelling.
:::

::: {.proof #ch04-proof-height-quotient}
Fix \(z\) and divide its labels into blocks \(B\) of equal spectral position. Within each block a path of disjoint lines preserves the strict order of the heights. Conversely, straight interpolation between any two vectors with those orders preserves every required inequality. Each component is convex. Every choice of orders within the blocks extends to a total order, so precisely \(\prod_B |B|!\) points of the quotient lie over \(z\).

To see what a neighbourhood of such a point contains, choose an extending order \(\sigma\). Its chart has saturated inverse image
\[
 V_\sigma=\bigcap_{i<_{\sigma}j}
      \bigl(\{z_i\ne z_j\}\cup\{t_i<t_j\}\bigr)\subset E_n .
\]
This set is open. Its coordinate projection onto \(X^n\) is an open surjection, and its fibres are exactly the selected components. Thus it gives the asserted chart in the quotient topology. Two choices give the same component precisely on \(U_{\sigma\tau}\). For instance \(U_{123,132}=\{z_2\ne z_3\}\). On this overlap the two charts describe the very same labelled tuple. To act on a coefficient by permuting its input slots takes a further map. Relabelling carries each defining inequality to the inequality for the relabelled pair, so it commutes with \(q\). Over each metrisable chart \(V_\sigma\) is open in the trivial height bundle and has nonempty convex fibres. The convex-fibre lemma of Petersen and Tosteson makes this an \(\mathbb R^n\)-bundle. Their arrangement theorem gives the affine-line case. [Petersen and Tosteson, *Factorization statistics and bug-eyed configuration spaces*, §2.3.1, Theorem 3.3.5 and Lemma 3.3.6](https://arxiv.org/pdf/2004.06024v3#page=14)

On a finite intersection of charts, choose constant heights increasing in the first chart order. Wherever marks agree on the intersection, all its orders agree on those labels. Straight interpolation to the chosen heights retracts the inverse image onto a section of \(q\). The Čech nerve of a cover records its charts, their pairwise overlaps and all higher intersections. On these two nerves \(q\) is a homotopy equivalence on each term. The open-cover theorem identifies the homotopy colimit of each nerve with its covered space up to weak equivalence. Hence \(q\) induces isomorphisms on homotopy groups and a bijection on path components. This open-cover argument applies also to the non-Hausdorff quotient. [Dugger and Isaksen, *Topological hypercovers and \(\mathbb A^1\)-realizations*, Theorem 1.1 and Corollary 2.3](https://arxiv.org/abs/math/0111287)
:::

For a smooth separated complex algebraic curve the same charts and overlaps give the analytification of the ordered collision scheme. A quantum coefficient on the space of lines would still need comparison maps on these intersections and compatible extensions at coincident marks. [The affine-line order charts of Alfonsi, Kim and Young, §4.1](https://arxiv.org/pdf/2401.11917v1#page=18)

On the atlas, a surjection of label sets comes with an order on each fibre. In a chosen chart for the target labels, concatenate the ordered fibres in the order of those labels. Repeating each target position at the labels of its fibre defines a diagonal in that chart of the source labels. A coefficient system identifies the extraordinary pullback of its coefficient along this diagonal with its coefficient on the target labels, coherently under composition. The convolution sums over all ordered decompositions \(I=A\sqcup B\) on the opens where the blocks stay apart. Either bracketing of three blocks imposes separation between every pair of blocks. Together with the interchange of the blocks this gives a symmetric monoidal convolution. An algebra for it may still multiply noncommutatively.

Restrict a coalgebra on this atlas to the increasing chart. Project its coproduct onto the components for which the first block is an initial interval and the second is the remaining final interval. Iterating either way keeps the same consecutive triples of blocks, so the projected maps give a coassociative coproduct for consecutive cuts. Already at two separated points the projection discards \(2|1\). This loss of a summand is one reason the passage to a single word need not be invertible.

**Definition (consecutive-cut convolution).** Let \(F_n,G_n\) be the coefficients on words of length \(n\). Each system has a separate coefficient on the empty word, a complex over \(k\). For \(p,q\ge0\) with \(p+q=n\), let \(j_{p,q}\) include the cut open (4.9) when both blocks are nonempty. If one block is empty, \(U_{0,n}=U_{n,0}=X^n\) and the inclusion is the identity. The consecutive-cut convolution is
\[
 (F\star G)_n=\bigoplus_{p+q=n}Rj_{p,q*}j_{p,q}^*
      (F_p\boxtimes^{\mathbf L}G_q).
\]
The derived external tensor puts one coefficient on each block. Restriction keeps the blocks apart, and the algebraic differential-module direct image extends that coefficient across the excluded diagonals by localisation. For an empty block no separation is required. This gives the convolution unit \(k_\varnothing\), equal to \(k\) on the empty word and zero elsewhere. An augmented associative algebra \(A\) for this convolution has a coherent multiplication \(A\star A\to A\) and a unital algebra map \(A\to k_\varnothing\). Require the augmentation to be an equivalence on the empty word.

To express factorisation for a word, form the bar coalgebra \(BA\). Its differential uses the products of adjacent factors and their higher associativity homotopies. Its coproduct splits a word. For \(p,q>0\), project the coproduct \(BA\to BA\star BA\) to the \((p,q)\) summand and restrict to \(U_{p,q}\). Restriction of the direct image to this open recovers the original coefficient there, so the factorisation map is
\[
 (BA)_{p+q}|_{U_{p,q}}\longrightarrow
 \bigl((BA)_p\boxtimes^{\mathbf L}(BA)_q\bigr)|_{U_{p,q}},
\]
and it must be an equivalence. For instance, at \((x,x,y)\) with \(x\ne y\) the cut \(12|3\) identifies the three-letter bar coefficient with the external product of the pair coefficient at \((x,x)\) and the singleton coefficient at \(y\). In the opposite direction, the cobar construction forms an algebra from a coalgebra and uses the coproduct in its differential. The augmentation ideal and the coaugmentation coideal vanish on the empty word in the connected case. Each factor in a reduced convolution therefore requires at least one label. More than \(n\) such factors give zero in arity \(n\). Thus the bar–cobar filtration is finite in each arity for both coefficient categories, with their respective convolutions. [Connected bar–cobar duality](05-bar-and-coherence.md#ch05-ordered-cuts-give-a-finite-geometric-bar-construction)

A chiral Lie algebra on \(X\) gives a Lie object on the Ran space supported on its singleton configurations. On two labels its chains again have a separated term and a term where the labels have merged. The chiral Chevalley chains of Francis and Gaitsgory take shifted symmetric powers for the tensor product on disjoint blocks. Their differential brackets two factors. Their coproduct splits the factors between two blocks and is cocommutative for that tensor product. Because the Lie input is supported on the singleton copy of \(X\), the coproduct gives a factorisation equivalence on each separating open. [Francis–Gaitsgory, *Chiral Koszul duality*, §§2.4.5–2.4.7 and Theorem 5.2.1](12-chiral-quantum-groups.md#ref-ch12-cq3)

Restrict this coalgebra on the finite-set diagram to order-preserving surjections and project its coproduct onto consecutive cuts. At the isolated empty word adjoin \(k\) with its scalar coproduct, counit and coaugmentation. A cut with one empty block then uses the unit identification. Connected associative cobar gives an associative chiral algebra of configuration complexes. Comparing it with the original fields requires a map respecting substitutions, translation and the vacuum at an occupied point. To reverse the passage to words one would have to extend the entire bar coalgebra to all finite-set surjections, with a compatible cocommutative coproduct and factorisation on disjoint opens. The open \(U_{13|2}\) separates the outside pair from the middle point at \((x,y,x)\), and the diagonal map for that partition identifies labels 1 and 3. Even where symmetry relates the two coproduct components at distinct points, extending across the partial collision still requires its own map. [Chapter 12](12-chiral-quantum-groups.md#ch12-associative-products-on-configurations)

What happens to the possible coefficient at \((x,y,x)\) if a change of order acts on that coefficient itself? Let \(F\) be a complex on the word chart \(X^n\) whose restriction to every nontrivial cut open \(U_p=U_{p,n-p}\) vanishes. For a connected coaugmented coalgebra of word coefficients, the positive cut cobar has this property when each cut coproduct is a factorisation equivalence on its separating open. Restriction to opens has its ordinary meaning for sheaves and is the open inverse image for complexes of right differential modules with quasi-coherent underlying modules. At three points interchange the last two slots by \(s_2\). On
\[
 W= \{z_2\ne z_3\}\cap s_2^{-1}U_{2,1}
   =\{z_2\ne z_3,\ z_1\ne z_2\}
\]
the reordered tuple lies in \(U_{2,1}\). Its first block consists of the original labels \(1,3\). In particular \(s_2(x,y,x)=(x,x,y)\). If \(F|_W\simeq(s_2^*F)|_W\), then \(F|_W=0\). For the dualising cut coalgebra on the algebraic curve, the empty coefficient is \(k\) and the \(n\)-point coefficient is the dualising right module \(\omega_{X^n}[n]\). Its positive cobar coefficient has nonzero extraordinary fibre at \((x,y,x)\). The middle exchange on the whole unequal-position open would force this fibre to vanish. [The dualising coalgebra and its support](05-bar-and-coherence.md#ch05-the-support-remembers-which-cuts-were-allowed)

::: {.proposition #ch04-witness-opens title="Transport of cut vanishing"}
Let \(n\ge2\) and suppose that \(F|_{U_p}\simeq0\) for all \(1\le p<n\). Assume that the coefficients admit functorial restriction to opens and pullback by permutations, and that restrictions to a finite open cover jointly detect the zero object. For each admitted adjacent transposition \(s_i\), suppose that \(F\simeq s_i^*F\) on its specified open domain \(O_i\subseteq\{z_i\ne z_{i+1}\}\). Then \(F\) vanishes on the union of the opens where those exchanges lead to a separated consecutive cut. If every adjacent exchange acts on its entire unequal-position open, \(F\) vanishes off the small diagonal.
:::

::: {.proof #ch04-proof-witness-opens}
Fix a sequence of moves \(\mathbf i=(i_1,\ldots,i_m)\) and a final cut \(p\). Let \(g_0=1\) and \(g_j=s_{i_j}g_{j-1}\), so \(g_jz\) is the tuple after \(j\) exchanges. The calculation is defined on the open
\[
 W(\mathbf i,p)=g_m^{-1}U_p\ \cap\
      \bigcap_{j=1}^{m} g_{j-1}^{-1}O_{i_j}.
\]
Pulling the \(j\)-th equivalence back by \(g_{j-1}\) identifies consecutive restrictions on this open. Their composite identifies \(F|_W\) with the pullback of \(F|_{U_p}=0\). For fixed domains \(O_i\), all the intersections use permutation translates from one finite list. Only finitely many different witness opens occur. Finite open descent gives vanishing on their union. If permissions vary with a preparation, the same path argument uses its actual domains at each step and gives vanishing on each such open and on each finite union.

Under the full hypothesis, pick any tuple with two or more spectral values. Move all occurrences of one value to the left, exchanging each only with adjacent letters of a different value. The final word admits a cut after its last occurrence of that value. The initial tuple therefore belongs to one of the opens just constructed. These opens cover the complement of the small diagonal. This proves the support assertion for unbounded complexes as well, without testing their extraordinary fibres at individual points. ∎
:::

The number of exchanges needed depends on which cut is sought. In a word \(w\) with at least two different marks, choose a nonempty proper subset \(A\) of its distinct values for the left block. Every labelled pair \(i<j\) with \(w_i\notin A\) and \(w_j\in A\) must reverse. Moving each \(A\)-letter left past adjacent letters outside \(A\) crosses exactly those pairs, once each. Thus the least number of unrestricted adjacent exchanges exposing a cut is the minimum of this count over \(A\). For \(b\) occurrences in \(A\), the costs for \(A\) and its complement add to \(b(n-b)\). The cheaper orientation costs at most \(\lfloor n^2/8\rfloor\). For two marks with multiplicities \(\lfloor n/2\rfloor,\lceil n/2\rceil\), passing from one sorted order to its reverse realises each integer between zero and the product of the multiplicities as an inversion count. The halfway count rounded down attains the bound.

If an exchange is forbidden at the gap after slot \(j\), the labels in the first \(j\) slots stay in that prefix. For a proposed set \(A\) with \(b\) occurrences, the prefix must already contain exactly \(\min(j,b)\) occurrences from \(A\). This condition at every forbidden gap is also sufficient when the remaining adjacent exchanges are reversible and available for every unequal pair. Between successive forbidden gaps, move the \(A\)-letters to the left. The prefix counts put each of the \(b\) letters on the required side, and the procedure crosses each inverted pair exactly once. If there are also static permissions on pairs of original labels, each inverted pair must be permitted to pass. The same procedure then works, so minimising the count over the feasible \(A\)'s gives the exact restricted distance. If no such \(A\) exists, no permitted sequence exposes a cut.

The word \(xyxy\) illustrates this restriction. Exchanging its middle two letters gives \(xx|yy\). If only the two outer transpositions are available, the first two slots always contain one \(x\) and one \(y\), as do the last two. Every cut then has a mark on both sides. For a physical exchange on ordered tensor states, transport to \(F\) requires an equivalence on \(F\) over the same domain. At \((x,y,x)\) the last two probes have spectral difference \(y-x\) in the first-minus-second convention. Their exchange on tensor states does not construct the equivalence on \(F\). Independence of the path of exchanges requires coherence, and fusing the two probes at \(x\) requires a collision operation. [Exchange of ordered Yangian probes](12-chiral-quantum-groups.md#ch12-ordered-yangian)

For a fixed order of three inputs the cuts also enter the differential. Take closed degree-zero letters \(a,b,c\) in the augmentation ideal. The first binary merger of the bar word \([a|b|c]\) gives \([ab|c]-[a|bc]\). Erasing the left separator first thus contributes \(+[(ab)c]\) after both mergers. Erasing the right one first contributes \(-[a(bc)]\). Their sum is the associator, with the order of the inputs fixed. On the unshifted inputs the [length-three bar equation](05-bar-and-coherence.md#eq-ch05-associator-homotopy) gives a specified degree-\(-1\) operation \(m_3\) with \(d\,m_3(a,b,c)=(ab)c-a(bc)\). Equation (4.10) locates the configurations where neither cut separates the inputs. How much of a coefficient there can we recover from nearby separated fields?

::: figure fig-ordered-cut-support

## The open locus cannot determine every extension {#collision-supported-data}

Consider a sheaf \(F\) on a complex disc about \(0\). Adding a copy of \(\mathbb C\) supported at \(0\) leaves every stalk on the punctured disc unchanged. There the inclusion \(F\to F\oplus\mathbb C_{\{0\}}\) is an isomorphism, whereas its cokernel at the centre is \(\mathbb C_{\{0\}}\). More generally restriction \(j^*\) to an open set kills every sheaf or differential module supported on its complement. A kernel or cokernel at a collision can therefore disappear on restriction. This example concerns ordinary sheaves. For a classical factorisation algebra the axiom on \(B_I\) excludes a nonzero local section supported on a collision diagonal, and the diagonal and unit identifications must also hold. For a word algebra the cut condition bounds the support of its positive-arity coefficient by the common failure locus. [Sections supported on a collision](05-bar-and-coherence.md#ch05-the-support-remembers-which-cuts-were-allowed)

Suppose now that the stalk at the collision has also been specified. A section near the collision restricts to the punctured neighbourhood. Which classes there can occur as restrictions? To describe the target of this map, take complexes of sheaves in the usual topology on complex configurations and begin with two points. Their separation can wind around zero before the points meet.

### The normal link of a collision {#ch04-normal-link}

For two points on the complex line, hold their common position fixed and move their difference around zero. The punctured disc of differences retracts onto a circle. Choose a point on this circle and let \(E\) be the fibre there of a locally constant family of complex vector spaces. Transport once around the positive loop gives the monodromy \(C:E\to E\). The circle has one vertex and one oriented edge. A vector \(v\) at the vertex returns as \(Cv\), so the cellular cochains are
\[
 E\xrightarrow{\,C-1\,}E
\]
in degrees \(0,1\). The cohomology in degree zero is \(\ker(C-1)\), the vectors unchanged by the loop. In degree one it is \(E/(C-1)E\). For a one-dimensional coefficient both groups have dimension one when \(C=1\) and both vanish when \(C=-1\).

Let \(j\) include the punctured disc and let \(L\) be this local system. The canonical map \(j_!L\to Rj_*L\) compares extension by zero with derived direct image. At the centre its source stalk is zero, while its target stalk consists of the cochains of the punctured disc with coefficients in \(L\). To measure their difference, recall that for a map \(f:P\to Q\) of cochain complexes the **cone** has degree-\(n\) term \(Q^n\oplus P^{n+1}\) and differential \((q,p)\mapsto(d_Qq+f(p),-d_Pp)\). Its cohomology vanishes exactly when \(f\) induces an isomorphism in each degree. Here the stalk map starts at zero, so its cone is the circle complex just computed. With more labels, the neighbourhood contains all the ways the points in each cluster can separate.

**Definition (normal link complex).** For \(n\) distinct labelled points write \(j:\operatorname{Conf}_n(\mathbb C)\hookrightarrow\mathbb C^n\). Let \(L\) be a finite-rank complex local system in degree zero, that is, a family of vector spaces with invertible parallel transport along paths. At a boundary point \(x\), a transverse slice fixes the locations of the clusters and varies the differences inside them. The **normal link complex** \(K_x\) is the cochain complex, considered up to maps inducing cohomology isomorphisms, of the separated part of a sufficiently small transverse neighbourhood with coefficients in \(L\). Its cohomology comprises closed cochains modulo exact ones. In sheaf notation,
\[
 K_x=(Rj_*L)_x
     \simeq\bigl(\operatorname{Cone}(j_!L\longrightarrow Rj_*L)\bigr)_x .
\]
Here \(Rj_*L\) takes sections and their higher cohomology on the part of each neighbourhood lying in the open. Its stalk is obtained by shrinking the neighbourhood to \(x\). Extension by zero \(j_!L\) has zero stalk there. The cone measures the difference of these two extensions, so its stalk at \(x\) is \(K_x\). Complexes use cohomological degrees. A shift \([r]\) moves degree \(a\) to \(a-r\). [Complexes, shifts and homotopies](05-bar-and-coherence.md#cohomology-and-parameters)

For the two-point normal link just computed, only the complex difference varies. Take the two parallel Wilson lines again, this time varying both the height difference \(t=t_2-t_1\) and the spectral difference \(\zeta=z_2-z_1=x+iy\) in a coordinate disc. Fix the centre of the pair. On a sufficiently small sphere
\[
 t^2+|\zeta|^2=r^2,\qquad r>0 ,
\]
the lines remain disjoint everywhere. On its equator the spectral difference makes a full turn. At either pole the spectral positions agree, and the sign of \(t\) records the order. What remains of this sphere after the height components are collapsed?

::: {.proposition #ch04-outward-linking-class title="The two-chart linking class"}
In the linear normal slice the quotient is \(D=\mathbb C_+\cup_{\mathbb C^\times}\mathbb C_-\), with origins for \(t>0\) (order \(12\)) and \(t<0\) (order \(21\)). Write \(r_\pm\) for restriction to the common punctured chart. For the constant sheaf of a commutative ring \(\Lambda\) in the analytic topology,
\[
 R\Gamma(D;\Lambda)\simeq\Lambda\oplus\Lambda[-2].
\]
Here \(\Lambda[-2]\) places \(\Lambda\) in cohomological degree two. For \(\Lambda=\mathbb Z\) and chart difference \(r_+-r_-\), positive winding on the overlap gives the integral class \(\eta_{\rm out}\) of period \(+1\) on the outward sphere in the orientation \(dt\wedge dx\wedge dy\).
:::

::: {.proof #ch04-proof-linking-class}
Over \(\zeta\ne0\) the height fibre is connected. At zero it splits into the two half-lines. Thus each origin has a disc neighbourhood, and their common part is punctured. Derived Mayer–Vietoris identifies the complex of global sections with the homotopy fibre of
\[
 R\Gamma(\mathbb C_+;\Lambda)\oplus R\Gamma(\mathbb C_-;\Lambda)
       \xrightarrow{\,r_+-r_-\,}R\Gamma(\mathbb C^\times;\Lambda).
\]
Each chart contracts to a point. The overlap retracts to its circle, whose cellular cochains have one copy of \(\Lambda\) in each of degrees zero and one and zero differential. The map on constants is \((a,b)\mapsto a-b\). Its kernel supplies degree zero, and the connecting map carries the winding generator from degree one of the overlap to degree two of \(D\). The constants and this class split the complex as displayed. Discs instead of affine lines give the same local calculation.

To fix the sign, restrict the quotient map \(q\) to the displacement sphere and use integral winding with real representative \(\alpha=d\arg\zeta/(2\pi)\). A smooth weight \(\chi(t)\) equal to zero near the south pole and one near the north pole gives lifts \((1-\chi)\alpha\) on the plus chart and \(-\chi\alpha\) on the minus chart. Each extends across its own pole. Their difference is \(\alpha\), and their common derivative represents the connecting class. The northern hemisphere has the positive complex equator as its oriented boundary. Stokes' formula on the two hemispheres therefore gives \(\int_{S^2_{\rm out}}q^*\eta_{\rm out}=\oint_{\rm equator}\alpha=1\). Interchanging the labels sends \((t,\zeta)\) to \((-t,-\zeta)\), the antipodal map of degree \(-1\). ∎
:::

In a single order chart the connecting class restricts to zero. The quotient has the weak homotopy type of the linking sphere. Every continuous map from \(D\) to a Hausdorff space identifies its two origins, since any neighbourhoods of the two origins intersect. Such a map factors through \(\mathbb C\), so an ordinary homotopy equivalence from \(D\) to the sphere is impossible. The calculation uses Betti cochains with constant coefficients. For a connected coalgebra whose two ordered coproduct components identify their targets with the same unsuspended coefficient \(V\), the term \(V[-2]\) already occurs at *distinct* spectral points. There the cobar differential sends \(v\) to \((v,v)\), leaving the difference between the two decomposition channels. [The binary cobar](05-bar-and-coherence.md#ch05-cobar-reverses-the-construction)

Hold two lines at equal height and fix the centre of their spectral positions. Write their spectral difference as \(s=z_2-z_1\). On the punctured disc prescribe two scalar coefficients, \(1/s\) and \(1/s^2\), and retain only the polar part of each. In the formal disc the regular functions form the ring \(R=\mathbb C[[s]]\), and inverting \(s\) gives the field \(K=\mathbb C((s))\) of Laurent series. The two readings are therefore the classes \([s^{-1}]\) and \([s^{-2}]\) in \(Q=K/R\). Can the two polar parts give a joint class at the collision?

For a second preparation put marks \(1,2\) in one disc and marks \(3,4\) in a disjoint disc. Fix the centre of each pair. The cut \(12\mid34\) stays separated even when the marks within each pair meet. Give the first pair a simple pole \(1/u\) in \(u=z_2-z_1\) and the second a simple pole \(1/v\) in \(v=z_4-z_3\), using a local coordinate in each disc. A Laurent coefficient can now detect a pole in both variables. With the coordinates ordered as \(u,v\), define the residue of \(h\,du\wedge dv\) to be the coefficient of \(u^{-1}v^{-1}\) in \(h\).

The principal parts have cohomological degree one. Indeed, for a Noetherian commutative ring \(B\) and an equation \(f\), let \(V(f)\) be its zero set and \(B_f=B[1/f]\) the ring on its complement. The derived sections \(R\Gamma_{V(f)}(B)\) with support on \(V(f)\) are represented by the localisation map
\[
 C_f(B)=[\,B\longrightarrow B_f\,]
\]
in degrees zero and one. Its cohomology is denoted by \(H^i_{(f)}(B)\). The parameter \(s\) cuts out a simple Cartier divisor on the formal disc. Its ideal is generated by \(s\), a non-zero-divisor. For \(B=R\) and \(f=s\), the localisation map is injective with cokernel \(Q\). To take the cup product of classes with two prescribed supports, tensor the two localisation complexes in the given order. Their terms are flat, so this computes the derived tensor product. The resulting Čech complex computes sections supported on the intersection of the zero sets (Stacks Project, *Local cohomology*, Lemma 47.9.1).

::: {.proposition #ch04-supported-transverse-product title="Cup products on coincident and transverse divisors"}
The cup product of any two classes in \(H^1_{(s)}(R)\) is zero. For the two independent separations take \(A=\mathbb C[[u,v]]\) and order the divisors \(u=0\), \(v=0\). The product of \([1/u]\in H^1_{(u)}(A)\) with \([1/v]\in H^1_{(v)}(A)\) has residue \(+1\) at their intersection. Reversing the two factors gives residue \(-1\) with the target orientation held fixed. [A repeated divisor and two transverse divisors](reference.html#s-products-on-repeated-and-transverse-supports)
:::

::: {.proof #ch04-proof-supported-transverse-product}
For the repeated divisor, \(C_s(R)\otimes_R C_s(R)\) has the three terms
\[
 R\longrightarrow K\oplus K\longrightarrow K,\qquad
 a\longmapsto(a,a),\qquad (b,c)\longmapsto c-b .
\]
The last map is surjective. In particular the top cochain \(s^{-3}\) obtained from the two prescribed poles is the boundary of \((0,s^{-3})\). The closed cochains in the middle are the pairs \((b,b)\). Modulo the images of regular \(a\), they give \(Q\) in degree one.

This surviving group comes from resolving the principal parts before tensoring. A flat resolution of \(Q\) is \(R\to K\) in degrees \(-1,0\), augmented by \(K\to Q\). Tensor it with \(Q\). Every principal part is killed by a power of \(s\), so inverting \(s\) gives \(K\otimes_R Q=0\). The resulting complex is \(Q\to0\). Its degree zero gives \(Q\otimes_R Q=0\), and its degree \(-1\) gives the first derived tensor group \(\operatorname{Tor}_1^R(Q,Q)=Q\). Each support complex is \(Q[-1]\), so the two shifts place this last group in degree one of the supported tensor. Thus \(H^2_{(s)}(R)=0\) even though the derived tensor still contains \(Q\) in degree one.

For the two independent separations the ordered tensor \(C_u(A)\otimes_A C_v(A)\) is
\[
 A\longrightarrow A_u\oplus A_v\longrightarrow A_{uv},
 \qquad a\longmapsto(a,a),\qquad (b,c)\longmapsto c-b .
\]
Here \(A_{uv}=A[1/(uv)]\). The minus sign on \(b\) comes from applying the second differential past a first factor of degree one. The product in the order \(u,v\) is represented in top degree by
\[
 [1/(uv)]\ \in\ H^2_{(u,v)}(A)=A_{uv}/(A_u+A_v).
\]
Adding a regular series to \(1/u\) changes its product with \(1/v\) by an element of \(A_v\). Changing the second representative gives an element of \(A_u\). Neither single localisation contains a monomial with both exponents negative. The residue therefore descends to the quotient and reads \(+1\) on this class. To compare the reverse product in the same ordered complex one interchanges two factors of degree one. The tensor symmetry contributes \((-1)^{1\cdot1}=-1\). ∎
:::

To compose two attachments one must specify maps on states. On a free rank-one \(R\)-module choose the basis state \(1\) and the covector that reads its coefficient. Take as attaching map multiplication by \(s\) or by \(s/(1+s)\). Away from \(s=0\) the inverse readings are \(s^{-1}\) and \(s^{-1}+1\), with the same principal part. Apply a further inverse \(s^{-1}\) to each result. The outputs \(s^{-2}\) and \(s^{-2}+s^{-1}\) differ by a simple pole. Thus a regular term that the individual reading discarded contributes to the composite. [Precision for a composite of marked inverses](05-bar-and-coherence.md#ch05-composing-marked-inverses)

A distribution supported at coincidence restricts to zero on the punctured normal neighbourhood. Adding such a contact term to an extension leaves its restriction there unchanged. The [two-chart linking class](#ch04-outward-linking-class) fixes an oriented period on separated configurations. A continuum coupling also requires a prescription for the contact term, an attaching map at collision in the chosen line frames, and a prepared state and covector on which to evaluate that map. [From support to fields](05-bar-and-coherence.md#ch05-from-support-to-fields)

::: {.example #ch04-free-order-sign title="The sign for two lifted states"}
A coefficient can give the meridian a weight, including a sign. In a cochain description of the two-chart cover, join the two orders by an interval. Orient this edge from \(21\) to \(12\) and let \(q_{12}\) increase from zero to one along it. Use the complex difference \(u=z_1-z_2=-\zeta\). In this convention the de Rham class is \(\varepsilon=[dq_{12}\wedge d\log u]\). On the unit displacement sphere represent \(q_{12}\) by the northern weight \(\chi(t)\). Away from its poles put \(\zeta=\sqrt{1-t^2}\,e^{i\theta}\). The radial term of \(d\log u=d\log\zeta\) drops out of the wedge with \(d\chi\). The sphere has outward orientation \(-dt\wedge d\theta\) there. Hence
\[
 \int_{S^2_{\rm out}}\frac{q^*\varepsilon}{2\pi i}
   =-\int_{-1}^{1}\chi'(t)\,dt=-1.
\]
It is the direction of the order edge that fixes this sign. Multiplication of the spectral difference by \(-1\) leaves its winding unchanged.

For a free coefficient over \(\mathbb C\), take a commuting field generator \(x_0\) of degree zero and an anticommuting generator \(p_0\) of degree one. Let \(T\) denote infinitesimal translation and \(p_1=Tp_0\) its value on \(p_0\). At level \(\kappa\ne0\) the internal differential satisfies \(d_\kappa x_0=\kappa p_1\), \(d_\kappa p_0=0\). Use the state functional that takes the constant term of a polynomial in the generators and their translates. Its two-field defect is its value on the ordered product minus the product of its one-field values. On these linear generators the mixed Wick contraction in either slot order is \(dq_{12}/u\), with zero contraction for like generators. At a single position \(z\), combine the internal differential with translation to give \(d_\kappa+dz(\partial_z+T)\). The state
\[
 \widetilde\xi=p_0+\kappa^{-1}dz\,x_0
\]
is closed. The translation of \(p_0\) contributes \(dz\,p_1\), and the differential of the correction contributes \(-dz\,p_1\). The two unlifted \(p_0\)'s have zero defect. With a lift at each point the two mixed contractions give
\[
 -\kappa^{-1}\frac{dq_{12}}{u}\wedge(dz_1-dz_2)
       =-\kappa^{-1}dq_{12}\wedge d\log u .
\]
Here forms stand on the left and moving an odd contraction past a one-form contributes a minus sign. Dividing by \(2\pi i\) and integrating gives \(+\kappa^{-1}\) on the outward sphere. The level and the choice of lifted inputs both enter this reading.
:::

::: {.example #ch04-wilson-displacement-flux title="Source flux for two framed Wilson lines"}
Which form measures this sphere in a gauge theory? Take flat rational four-dimensional Chern–Simons theory on \(\mathbb R_s\times\mathbb R_t\times\mathbb C\), with holomorphic form \(dz\), trivial background, fixed plane framing and the decaying propagator. Work formally in the coupling \(\hbar\). Both complete parallel lines point along increasing \(s\). Fix the external colour states, require gauge transformations to fix the ends, and trivialise at spectral infinity. The propagator is written in displacements from the second insertion to the first. Put \(l=s_1-s_2\), \(Y=t_1-t_2\), \(u=z_1-z_2=a+ib\) and \(r^2=Y^2+a^2+b^2\). With the inverse invariant form on the colour algebra and the coupling stripped off, the two-form is
\[
 P=\frac{l\,dY\wedge d\bar u+Y\,d\bar u\wedge dl+
                  2\bar u\,dl\wedge dY}{2\pi(l^2+r^2)^2}.
\]
Its restriction at \(l=0,\ dl=0\) vanishes. To read the source flux, use the three-form \(i\,du\wedge P/(2\pi)\). Contract with \(\partial_l\) first and integrate over the whole longitudinal fibre in the increasing \(l\)-direction. [Costello, Witten and Yamazaki, *Gauge Theory and Integrability, I*, §4, (4.4)–(4.14)](https://arxiv.org/pdf/1709.09993v2#page=32)

For \(r>0\), the longitudinal integral of \((l^2+r^2)^{-2}\) is \(\pi/(2r^3)\). The resulting two-form on the displacements is
\[
 \tau=\frac{Y\,da\wedge db-a\,dY\wedge db+b\,dY\wedge da}{4\pi r^3}
                  +\frac{i}{4\pi}d\!\left(\frac{dY}{r}\right).
\]
The first numerator is contraction of the oriented volume \(dY\wedge da\wedge db\) with the radial vector. On a sphere of fixed \(r\) this term integrates to \(+1\) and the exact term restricts to zero. Set \(v=Y/r\) and \(\phi=\arg u\). Primitives on the chart retaining \(Y>0\) at \(u=0\) and on the chart retaining \(Y<0\) are respectively
\[
 A_+=\frac{1-v}{4\pi}d\phi+\frac{i}{4\pi}\frac{dY}{r},
 \qquad
 A_-=-\frac{1+v}{4\pi}d\phi+\frac{i}{4\pi}\frac{dY}{r}.
\]
Each angular prefactor cancels the singularity at its retained pole. Their difference \(d\phi/(2\pi)\) gives the positive meridian. For these first-minus-second displacements \(Y>0\) means order \(21\). The conversion from \((t,\Re\zeta,\Im\zeta)\) to \((Y,a,b)\) reverses all three coordinates and interchanges the charts. Each period above uses the outward orientation in its own coordinates. On the *same* oriented sphere the pulled-back flux has the opposite sign.

There is a second preparation in the same theory. Take the complete \(s\)- and \(t\)-axes for the two lines, oriented in their increasing directions, at fixed \(u\ne0\). With plane orientation \(ds\wedge dt\) their projected intersection has sign \(+1\). Write \(\Omega=\sum_b \rho_1(e_b)\otimes\rho_2(e^b)\), where \(e_b,e^b\) are dual bases for the invariant form and \(\rho_1,\rho_2\) are the two colour representations. The one-gluon contraction in the original tensor order is \(\hbar\Omega\) times the integral of \(\bar u/[\pi(s^2+t^2+|u|^2)^2]\) over the parameter plane. On the disc of radius \(R\), the radial integral is \(2\bar u\int_0^R r\,dr/(r^2+|u|^2)^2=R^2/[u(R^2+|u|^2)]\). It tends to \(1/u\) as \(R\to\infty\) at fixed \(u\ne0\). This radius cuts off pairs of insertions in the chosen gauge. The full positive crossing therefore gives \(\hbar\Omega/u\) at first order. Multiplying by \(du/(2\pi i)\) gives the overlap period \(\hbar\Omega\), since \(du/(2\pi i u)\) differs from \(d\phi/(2\pi)\) by an exact radial form. For the parallel preparation the tangent contraction itself is zero. Its nonzero sphere period came from integrating the three-form along \(l\).

For the one-dimensional abelian colour algebra choose a generator of norm one and ordinary charges \(p,q\) coupling to the field at the mark without spectral derivatives. Fix the end frames and divide the Gaussian two-line expectation by the two individual line expectations at the same regulator. Wick contraction exponentiates the mixed term. The parallel and positively crossed scalar readings are \(1\) and \(\exp(\hbar pq/u)\) as formal series in \(\hbar\). The first-order differential \(\hbar pq\,du/u\) has residue \(\hbar pq\). Dividing it by \(2\pi i\) gives period \(\hbar pq\) on a positive meridian. The logarithmic derivative of the scalar crossing is \(-\hbar pq\,du/u^2\) and has zero residue. At \(pq\ne0\) two connection forms regular in the given collision frames cannot have this double pole as their difference. Extending the separated line operators to collision coefficients requires the endpoint states, contact operations and comparisons with successive fusions in the chosen theory. [Boundary insertions and the physical cap](11-states-and-lines.md#ch11-boundary-insertions-and-the-physical-cap)
:::

For spectral insertions on the curve alone, fix the height difference to zero and keep only \(\zeta\ne0\) in the normal slice. The meridian then belongs to the punctured disc itself. With local coefficients its cochains carry the monodromy \(C\) of the pair.

Suppose two disjoint pairs collide. Rotate the two points of each pair once positively around their common centre, leaving the other pair apart. These two loops, the full twists of the pairs, act on the same fibre. The cochains of the two scale circles use the two commuting circle differentials. Can each twist fix a nonzero vector while the link vanishes? Give the common fibre the basis \(e_1,e_2\). Let the first twist act by \(\operatorname{diag}(1,2)\) and the second by \(\operatorname{diag}(2,1)\). On the first line the second circle differential is the identity. On the second line the first differential is the identity. On either line the tensor product of the two circle complexes is thus acyclic. In a larger fibre one must test the generalised fixed vectors for *all* the twists together.

**Theorem (simultaneous cluster twists).** Let \(L\) be a finite-rank complex local system in degree zero on the distinct configurations, and let \(S_1,\ldots,S_b\) be the nontrivial blocks of coincident points at \(x\). A positive full twist rotates all points of a block once about their common centre with the other blocks apart. Choose local base paths so that the twists act on one fibre \(E\), and denote their actions by \(C_i\). Then
\[
 K_x\not\simeq0\quad\Longleftrightarrow\quad
 \bigcap_{i=1}^b\ker\bigl((C_i-1)^{\dim E}\bigr)\ne0 .
\]
Conjugating the local representation does not change the criterion. The twists commute with each other and with the angular monodromies in this local product, even when the angular monodromies fail to commute among themselves.

*Proof.* In a cluster of size \(r\) translate its first point to zero, choose the difference of the first two as scale, and divide all the other differences by that scale. Up to homotopy the separated normal directions are \(S^1\times Y_r\), where \(Y_r\) parametrises \(r-2\) ordered points of \(\mathbb C\setminus\{0,1\}\). Write \(Y_2=\mathrm{pt}\). The scale circle acts by the full twist. Disjoint discs give a product of these spaces for the different blocks. Decompose \(E\) into simultaneous generalised eigenspaces of the central twists. Any summand on which some \(C_i-1\) is invertible has a contractible circle complex. On the common generalised unit summand \(E_1\), the angular cochains have Euler characteristic
\[
 \dim(E_1)\prod_i(-1)^{|S_i|-2}(|S_i|-2)! .
\]
Forgetting the moving points one at a time gives punctured-line fibres with Euler characteristics \(-1,-2,\ldots,-(r-2)\), which proves the formula. It is nonzero when \(E_1\ne0\), so some angular cohomology survives. Appending a scale circle forms the two-term complex of \(C_i-1\) acting on these angular cochains. If this new complex were acyclic, \(C_i-1\) would act invertibly on their cohomology. It is nilpotent there, and a nilpotent map cannot be invertible on a nonzero space. Each remaining twist commutes with the ones already used and is still unipotent on the common summand. The same argument adds all the scale circles. ∎

In the two-line example take the colliding pairs to be \(12\) and \(34\), with all the other pair monodromies trivial. The common generalised unit space is zero, so the link at the double collision vanishes. Testing each divisor separately would retain one line on each and give the wrong answer at their intersection.

At one full collision of size \(n\ge3\), the scale circle and the shape space \(Y_n\) can also determine the ranks. Let \(C\) be the scale monodromy, \(V_0=\ker(C-1)\) and \(V_1=\operatorname{coker}(C-1)\), with their induced angular actions. Add a marked point at infinity to the \(n\) ordered points on the line. Modulo projective changes of coordinate, these \(n+1\) distinct marks give \(M_{0,n+1}\). Fixing \(0,1,\infty\) identifies it with \(Y_n\). In the stable compactification \(\overline M_{0,n+1}\) each boundary divisor splits the marks into two sets with at least two marks on either side of the node. This includes degenerations at infinity. Suppose the monodromy around *every* such divisor has no eigenvalue \(1\) on either \(V_0\) or \(V_1\). With \(m=n-2\), the link then has cohomology only in degrees \(m,m+1\), of dimension \(m!\dim\ker(C-1)\) in each.

The radial circle has cohomology \(V_0,V_1\) in degrees zero and one. Take either space as angular coefficient \(V\). At a point of the angular boundary, the normal circles have commuting monodromies. The hypothesis makes a circle differential invertible, so the boundary complex contracts. It follows that the map from compactly supported to ordinary cohomology \(H_c^*(Y_n;V)\to H^*(Y_n;V)\) is an isomorphism. Forgetting the \(m\) moving points one at a time bounds ordinary cohomology above degree \(m\), also for the dual coefficient \(V^\vee\). Since \(Y_n\) has real dimension \(2m\), Poincaré duality gives \(H_c^q(Y_n;V)=0\) for \(q<m\). Only angular degree \(m\) remains, of dimension \(m!\dim V\) by the Euler characteristic. Filter the link cochains by angular degree. Both radial cohomology rows are concentrated in the same angular degree \(m\), so no further differential can join them. They give total degrees \(m,m+1\). The ranks are equal because the kernel and cokernel of \(C-1:E\to E\) have the same dimension.

For \(n=3\) take a single unipotent Jordan block \(C\) of size \(d\ge2\) and angular monodromies \(2I,3I\) about the two finite punctures, with \(I\) the identity. The multiplier at infinity is \(I/6\). The generalised unit eigenspace has dimension \(d\), but the kernel of \(C-1\) has dimension one. The first space gives the survival criterion. Under the angular hypothesis it is the kernel that gives the multiplicity. Both link groups have dimension one for every \(d\).

### Two ordered points on the sphere {#ch04-sphere-binary-collision}

For a colliding pair in the plane, translating the common point transports its circle of normal directions without a choice of frame. On a sphere the normal plane at a collision moves with that point. Let the curve now be \(C=\mathbb P^1(\mathbb C)\simeq S^2\), with diagonal \(i:C\hookrightarrow C^2\) and complementary open inclusion \(j:U=C^2\setminus i(C)\hookrightarrow C^2\). The first projection \(p:U\to C\) is a locally trivial bundle with contractible fibre \(S^2\setminus\{x\}\) over \(x\), hence a homotopy equivalence. At \((x,x)\), the difference \((v_1,v_2)\mapsto v_2-v_1\) identifies the normal plane with \(T_xC\). Its unit circles form the oriented bundle \(q:E=S(TC)\to C\).

Here the point \(x\) ranges over the sphere and the unit vector \((v_2-v_1)/|v_2-v_1|\) ranges over a circle in \(T_xC\). In the [two-line linking calculation](#ch04-outward-linking-class) the collision centre was fixed and \(t_2-t_1\) varied together with \(\zeta\) on a single sphere of displacements. Its equator was the circle of spectral differences at equal height. In the present family there is a spectral direction circle over *each* collision centre. Comparing those circles requires the transition between tangent frames on \(C\).

Take first a locally constant coefficient \(L\) on \(C\), locally equivalent to a bounded complex of finite-dimensional vector spaces. Such a coefficient is called perfect. It can record the homotopies between transports as well as their action on cohomology. The open coefficient is \(p^*L\). On a small punctured normal neighbourhood the radial coordinate contracts, leaving just the unit circle with coefficient \(q^*L\). Thus the complex of nearby sections along the diagonal is
\[
 \mathcal B(L)=i^*Rj_*p^*L\simeq Rq_*q^*L.
\]
In particular, \(p^*L=j^*(L\boxtimes\mathbb C)\) is a separated two-point input. On the normal circle bundle the first projection is \(q\), and the second is homotopic to \(q\) along the short normal geodesic. Thus two perfect inputs \(A,B\) give \(\mathcal B(A\otimes B)\).

**Definition (attaching map).** Let \(P\) be a constructible complex that is locally constant on the diagonal and on its complement. Write \(W=i^*P\) for its diagonal restriction. Since \(p\) is a homotopy equivalence, choose \(L\) on \(C\) with \(p^*L=j^*P\). Restriction from a tubular neighbourhood of the diagonal to its punctured part gives the attaching map
\[
 W=i^*P\longrightarrow i^*Rj_*j^*P=\mathcal B(L).
\]
The localisation triangle \(i^!P\to i^*P\to i^*Rj_*j^*P\) identifies the costalk \(i^!P\) with the homotopy fibre of this arrow, its cone shifted by \([-1]\). The costalk records classes with support on the diagonal. Even when both the diagonal restriction and the complex of nearby sections are prescribed, the arrow between them can vary.

Both strata are simply connected. A loop in the base detects no ordinary monodromy. Nevertheless the oriented tangent frames on the two hemispheres differ along the equator by a rotation of winding number two. Thus the Euler number of \(TC\) is \(2\). To keep track of its sign on cochains, take the round sphere. In colatitude \(s\), longitude \(\varphi\) and positive tangent angle \(\psi\), choose the normalised area form and angular connection
\[
 \omega=\frac{\sin s}{4\pi}\,ds\wedge d\varphi,\qquad
 \vartheta=\frac{d\psi+\cos s\,d\varphi}{2\pi}.
\]
The area integral and the positive fibre integral are both one. Differentiation gives \(d\vartheta=-2q^*\omega\) as an equality of forms. The total space is \(E\simeq\mathbb RP^3\), and \(\gamma=\vartheta\wedge q^*\omega\) has integral one on \(E\).

Let \(\theta\) be the degree-one class on a circle represented by the restriction of \(\vartheta\). How does this class vary over the sphere? Orient the equator as the boundary of the northern hemisphere and take the southern horizontal frame minus the northern one. With this convention the positive generator of \(\pi_2(C)\) acts on the fibre cohomology of \(Rq_*\mathbb C\) by a degree-minus-one map \(T\). The coefficient of \(q^*\omega\) in \(d\vartheta\) gives \(T\theta=-2\) times the constant class, and \(T1=0\). The same curvature identity gives a primitive for \(q^*\omega\).

What does pulling back to the circle bundle do to a coefficient \(L\) with cohomology only in degrees \(a<b\)? Its two cohomology sheaves are constant on the sphere. The truncation triangle gives a connecting map
\[
 H^b(L)[-b]\longrightarrow H^a(L)[1-a].
\]
This map, the Postnikov extension class, records how the two sheaves are joined in \(L\). The shift difference is \(b-a+1\), so its matrix entries belong to the cohomology of the base in that degree. On the sphere it can survive only if \(b=a+1\), in which case each matrix entry is a multiple of \([\omega]\). Since \(q^*\omega=-\tfrac12 d\vartheta\), the pulled-back extension admits a splitting. Splitting amounts to choosing a primitive for the pulled-back class.

With three fibre degrees, splitting the first extension can leave a further obstruction. Give \(e_0,e_1,e_2\) degrees \(0,1,2\) and zero internal differential. For \(c=0,1\), let \(N_ce_2=e_1\), \(N_ce_1=ce_0\), \(N_ce_0=0\). On forms with these coefficients, \(\omega N_c\) raises form degree by two and lowers fibre degree by one. Thus \(D=d+\omega N_c\) has total degree one. Its square is zero since \(d\omega=0\) and a four-form on the sphere vanishes. This flat superconnection defines a perfect local system \(L_c\), with the same three ordinary cohomology sheaves for both values of \(c\).

On \(\mathcal B(L_c)\) the degree-minus-one transport for the positive sphere generator is the sum \(N_c\otimes1+1\otimes T\), with the graded tensor sign. Thus \(e_1\otimes\theta\) goes to \(ce_0\otimes\theta+2e_1\otimes1\). The coefficient \(+2\) comes from moving \(T\) past the degree-one vector \(e_1\) and using \(T\theta=-2\). The other basis vector \(e_2\otimes1\) goes to \(e_1\otimes1\). In these ordered bases the matrix from degree two to degree one is
\[
 (e_1\otimes\theta,e_2\otimes1)
 \longrightarrow (e_0\otimes\theta,e_1\otimes1),
 \qquad
 M_c=\begin{pmatrix}c&0\\2&1\end{pmatrix}.
\]
For \(c=0\) the two columns of \(M_c\) span the same line. For \(c=1\) its determinant is one. Transport on the family of normal circles thus distinguishes the coefficients. To see the obstruction on \(E\), pull the superconnection back along \(q\). The lift \(e_1+\tfrac c2\vartheta e_0\) is closed because \(d\vartheta=-2q^*\omega\). The differential of \(e_2\) is \(q^*\omega\,e_1\), which the derivative of \(\tfrac12\vartheta e_1\) cancels in form degree two. A further term comes from differentiating \(e_1\) past the one-form \(\vartheta\),
\[
 D\bigl(e_2+\tfrac12\vartheta e_1\bigr)=-\tfrac c2\,\gamma e_0 .
\]
Since \(\int_E\gamma=1\), the obstruction to lifting \(e_2\) is nonzero exactly when \(c\ne0\). The ordinary cohomology of \(E\simeq\mathbb RP^3\) over \(\mathbb C\) lies in degrees zero and three. In the filtration by form degree the only differential left after these lifts sends total degree two to degree three by \(-\tfrac c2[\gamma]e_0\). Thus the dimensions of the global cohomology of \(\mathcal B(L_c)\), in degrees zero through five, are \((1,1,1,1,1,1)\) for \(c=0\) and \((1,1,0,0,1,1)\) for \(c=1\).

Even identical open and diagonal restrictions can have different attachments. Fix the constant open coefficient and \(W=\mathbb C[-3]\). By derived adjunction a map \(W\to Rq_*\mathbb C\) up to homotopy is a class in \(H^3(E;\mathbb C)\). The zero class and \([\gamma]\) both restrict to zero on each direction circle. On global sections the degree-three map sends the shifted constant generator to the chosen class, so it has rank zero or one, respectively. The long exact sequence of the homotopy fibre then gives dimensions \((1,1,1,1)\) and \((1,0,0,1)\) in degrees \(1,3,4,5\). An all-arity unital factorisation algebra on this geometry still requires compatible multiplications and a vacuum insertion. [Higher transport at the sphere collision](#atlas-c-sphere-binary-higher-transport)

### Four charged rays and their possible attachments {#ch04-gaussian-collision}

Does knowing the entire separated amplitude determine the attachment at a collision? Return to the Heisenberg boundary of Gaussian abelian Chern–Simons theory. Write \(k=\kappa\) for its nonzero complex level. A Wilson ray carries a specified charge to a boundary insertion. For two rays a current contour reads each charge, and the Gaussian contraction gives a power of the separation. Use the same planar Cauchy propagator and radial transverse regularisation for several rays. Keep the parallel-copy framing, subtract the self-contractions and divide out the outgoing mutual contraction factor.

Let \(z_a\) be the boundary position of the ray of charge \(\alpha_a\). Fix a branch in a separated chamber and work on finite oscillator polynomials. Send in oscillator-free states and extract the coefficient of the oscillator-free outgoing vector of charge \(\sum_a\alpha_a\). The outgoing functional takes value one on this vector and zero on positive oscillator grades. For this preparation the model gives the separated amplitude
\[
 F_{\boldsymbol\alpha}(z)=\prod_{a<b}(z_a-z_b)^{\alpha_a\alpha_b/k}.
\]
Each ordered pair \(a<b\) contributes one Gaussian contraction to the logarithm. In the boundary calculation a current intertwiner inserts a charge and changes the charge sector. Commuting its annihilation part past the creation part of the next intertwiner gives the same pair factor. Continue the amplitude along a common path from the chosen chamber with the individual coordinate frames fixed. Its branches span a rank-one local system. A positive full twist of a block \(S\) winds each internal difference once. The multiplier of the operation is therefore
\[
 \exp\!\left(\frac{2\pi i}{k}\sum_{\{a,b\}\subset S}\alpha_a\alpha_b\right).
\]
For this rank-one system the link criterion is \(\sum_{\{a,b\}\subset S}\alpha_a\alpha_b/k\in\mathbb Z\) for each nontrivial block \(S\) of the collision. For a pair this recovers the full-turn phase of the normalised two-ray amplitude. The frames are held fixed during continuation. A rotation of an individual frame has its own conformal phase. The outgoing projection makes sense also at nonzero total charge. [Two charged rays](03-local-fields.md#ch03-charged-current-contour)

Take four charges \(1,1,1,1\) at level \(2\), so the outgoing charge is \(4\). For a block of \(r\) rays the exponent in units of \(2\pi i\) is \(\binom r2/2\). At \(r=2,3,4\) this gives \(1/2,3/2,3\) and phases \(-1,-1,+1\). Every proper collision contains a block of size two or three, including each block in a two-pair collision. Its \(-1\) phase kills the corresponding link. For the full four-point collision the scale phase is \(+1\), so both degrees of the radial circle survive.

To count the shapes, fix three ordered marks at \(0,1,\infty\) on the projective line. The two remaining marks determine a point of \(Y_4=M_{0,5}\). At each stable boundary divisor, the side of the partition omitting infinity contains two or three of the four rays. Its monodromy is therefore \(-1\), including at divisors at infinity. Its circle cochains contract. Compactly supported and ordinary angular cohomology agree. Forgetting one moving point at a time bounds the degree above by two, and duality bounds it below by two. The two punctured-line fibres have Euler characteristics \(-1,-2\), giving two classes in degree two. Combining them with the two radial degrees gives the full link \(K\),
\[
 \dim H^2K=\dim H^3K=2,\qquad H^aK=0\quad(a\ne2,3).
\]
More generally, let the level be an integer \(\ell\ge2\) and give every ray charge one. The first full collision with nonzero link occurs at the least \(n\ge2\) for which \(\ell\) divides \(\binom n2\). Before that arity every nontrivial block has nonintegral exponent and its scale circle contracts the link. At the first such \(n\), every proper boundary block still has nonintegral exponent. The same angular calculation on \(M_{0,n+1}\) therefore gives ranks \((n-2)!\) in degrees \(n-2,n-1\).

Which lines in \(V=H^2K\) can be the image of an attaching map? Fix the labelled transverse slice \(X=\mathbb C^3\). Let \(i\) include its origin and \(j\) the open of distinct positions, with the rank-one Gaussian local system \(L\) just computed. Use the middle perverse convention. On a smooth stratum of complex dimension \(d\), the restriction of a perverse complex has no cohomology above \(-d\) and its extraordinary restriction has none below \(-d\). Thus on the smooth open threefold \(L[3]\) is in ordinary degree \(-3\). Perverse sheaves form an abelian category, so we can take a quotient by a subobject supported at the origin.

::: {.theorem title="A projective line of four-ray attachments"}
For the four charge-one rays at level two on this fixed slice, each line \(W\subset V\) occurs as the attaching image of a perverse quotient of \(j_!L[3]\). The stalk and costalk dimensions are the same for every such quotient. Distinct lines give distinct isomorphism classes parametrised by \(\mathbb P(V)\cong\mathbb P^1\).
:::

*Proof.* Write \(V'=H^3K\). The complement of the distinct open is the zero set of the product of the pair differences. Thus \(j\) is an affine open inclusion, and perverse exactness makes extension by zero \(P_!=j_!L[3]\) perverse on the slice. The intermediate extension \(j_{!*}L[3]\) is the image of \(P_!\to Rj_*L[3]\) in the perverse category. It has no nonzero subobject or quotient supported on the boundary. The links at proper collisions vanish, so the kernel of the map onto the intermediate extension is supported at the origin. The localisation triangle gives \(i^!P_!\simeq K[2]\). Its degree-zero group \(H^0(K[2])=V\) gives the maximal point-supported subobject \(i_*V\). Hence there is an exact sequence
\[
 0\longrightarrow i_*V\longrightarrow P_!
 \longrightarrow j_{!*}L[3]\longrightarrow0 .
\]
For each line \(W\subset V\), form the quotient \(P_W=P_!/(i_*W)\) in the perverse category. Its ordinary stalk is \(i^*P_W\simeq W[1]\). The costalk \(i^!P_W\) measures local cohomology supported at the origin. Since \(i^!P_!\simeq K[2]\), the costalk sequence gives \(H^0 i^!P_W=V/W\) and \(H^1 i^!P_W=V'\), with all other groups zero.

The stalk therefore has one class in degree \(-1\), and the costalk has ranks one and two in degrees zero and one, for every line. The quotients agree off the origin. On \(H^{-1}\) the attaching map \(i^*P_W\to K[3]\) has image \(W\subset V\), the kernel of the boundary map \(V\to H^0i^!P_W=V/W\). The quotient map is the counit \(j_!j^*P_W\to P_W\). An isomorphism between two quotients acts on their separated rank-one local system by a scalar. By naturality of the counit, that scalar must carry the kernel \(i_*W\) in \(P_!\) to the other embedded kernel. A scalar fixes each line, so the quotients for distinct lines cannot be isomorphic. ∎

An oriented Hall coefficient on an extension correspondence would have to reproduce these attaching morphisms on the labelled slice and respect the maps at the other collisions. [Critical coefficients and orientation](15-hall-and-compact.md#ch15-critical-coefficients-and-orientation)

The four charges are identical. What changes if their labels may be permuted? Fix the positive elementary half-braid to act by \(+i\), with every individual coordinate frame fixed. On the labelled open use the connection \(d-\tfrac12d\log\Delta\), where \(\Delta=\prod_{a<b}(z_a-z_b)\). Permutations act trivially on the coordinate fibre of the underlying line. This specifies the lift of relabelling. On the unordered open, a positive half exchange changes the argument of \(\Delta\) by \(\pi\), giving the stated continuation of a horizontal section. At the origin of the centred normal slice relabelling fixes the base point and acts on \(V=H^2K\) by \(S_4\), the permutation group of the four rays.

The scale monodromy is trivial and the angular coefficient has cohomology only in degree two. Thus \(V\) identifies equivariantly with the compactly supported angular cohomology in degree two on \(M_{0,5}\). The trace of a permutation is its compactly supported Lefschetz number on this space of shapes. A transposition has no fixed shape, since an affine map fixing the two unswapped points fixes every point. A three-cycle has two fixed shapes, the two orderings of an equilateral triple about the fourth mark. A simultaneous dilation by \(a\) multiplies a horizontal section by \(a^3\). At either fixed shape \(a\) is a primitive cube root of unity, so each weight is one and the trace is \(2\). An operator of order dividing three is diagonalisable over \(\mathbb C\), and two cube roots of unity with sum \(2\) must both be \(1\). Thus every three-cycle acts as the identity. They generate the alternating subgroup \(A_4\). On the two-dimensional \(V\) a transposition has trace \(0\), so its two eigenspaces give
\[
 V\simeq{\bf1}\oplus\operatorname{sgn}.
\]
Naturality of \(P_!\to P_W\) says that the permutation action descends to the quotient exactly when it preserves the kernel \(i_*W\). A transposition has eigenvalues \(+1\) and \(-1\) on the two summands of \(V\). A line spanned by a vector with nonzero components in both summands changes under that transposition. Thus only the trivial line and the sign line in \(V\) survive from the labelled \(\mathbb P^1\). On the open set the half-braid acts by \(i\). At the collision the subgroup fixing the point, its stabiliser, acts on \(H^{-1}i^*P_W=W\) by \(+1\) or \(-1\).

To require ordinary inverse image from the coarse variety, let \(\pi:X\to X/S_4\) be the finite quotient of the centred slice. Write \(\bar U\) for the unordered distinct open, \(\bar j\) for its inclusion and \(\bar L\) for the line with the prescribed half-braid on \(\bar U\). A point stabiliser consists of the permutations fixing that point. For an equivariant complex \(P\), the stalk of \(R\pi_*P\) at \(\pi(x)\) is the sum of the stalks over one orbit. An invariant tuple is determined by its entry at \(x\), which must be fixed by the stabiliser. Since taking invariants over \(\mathbb C\) is exact, the counit \(\pi^*(R\pi_*P)^{S_4}\to P\) at \(x\) includes those invariants into the stalk.

The stabilisers are trivial on the distinct open, and the stalks at proper collisions vanish. At the origin the test is \(W^{S_4}\to W\), so precisely the trivial line satisfies the coarse inverse-image condition. In fact \(P_{\bf1}\simeq\pi^*\bar j_{!*}\bar L[3]\). Finite pushforward followed by invariants preserves the perverse image of extension by zero in direct image. Applied to the canonical sequence it retains exactly \(V^{S_4}={\bf1}\) in the kernel, identifying the intermediate extension downstairs. Within the displayed quotient family, equivariance requires every permutation to preserve \(W\) as a subspace. Coarse pullback requires it to fix each vector of \(W\). The Gaussian coefficient alone imposes no such pullback condition on a physical collision.

Which attachment does the outgoing charge-four Wick functional give? Use the finite field-number complex of compact smooth spacetime tests, with the rays vertical above their supports. Near a collision the Gaussian amplitude contains powers of the separations as well as an angular phase. To separate them, resolve the collision diagonals by real oriented blow-up. The boundary records the directions of approach. In each cluster chart choose a positive defining radius \(r_S\) for each cluster \(S\), measured relative to its parent for a proper cluster. Divide the Wick evaluation on the interior by \(\prod_S r_S^{\binom{|S|}{2}/2}\). Its value on the unit test is a scalar \(\Phi\) that extends smoothly to the face with its nonzero angular branch.

On a test \(x\) the divided evaluation is \(\Phi\lambda(x)\), where the translated Gaussian functional is normalised by \(\lambda(1)=1\). Thus \(G\mapsto G(1)\lambda\) projects a test functional \(G\) onto this line. The Gaussian differential annihilates the unit, and Cauchy translation fixes the unit and transports \(\lambda\). Evaluation at the unit therefore commutes with these operations. Including the phase connection \(-d\log\Phi\) in the dual differential makes the projection a map of complexes.

Choose smooth position forms with unrestricted boundary values on the blow-up. Each small corner meets the distinct-position interior in a contractible set, so derived direct image from the interior extends the line over the corner. Composing with proper blow-down to the centred slice gives the split summand \(P=Rj_*L[3]\), where \(j\) includes the distinct positions. At the origin \(i\), write \(K=i^*Rj_*L\) as above. The attaching map is
\[
 i^*P=K[3]\xrightarrow{\;1_{K[3]}\;}K[3]=i^*Rj_*j^*P .
\]
{#eq-ch04-absolute-wick-attachment}
Its homotopy fibre is zero, so \(i^!P=0\). Its image in degree \(-1\) is all of \(V\), whereas each line quotient \(P_W\) has attaching image \(W\).

Compactness concerns the supports of the spacetime tests. The boundary condition on the position forms is a separate choice. Requiring their pullback to every position boundary face to vanish gives the relative extension \(j_!L[3]\) of the same line. In a collar with boundary coordinate \(r\), the function \(r\) restricts to zero. Its differential \(dr\) is nonzero as a covector at \(r=0\), yet its pullback to the face vanishes.

The full charge-four state space contains the nonzero descendant \(J_{-1}|4\rangle\). The outgoing oscillator-free coefficient of this state is zero. On the compact-test complex the projector acts on a different input. It evaluates a functional at the unit test. The full compact Batalin–Vilkovisky complex still requires a comparison on cochains with prescribed normal and point supports. It must act on coincident distributional inputs, respect iterated collisions, and preserve both the scalar unit at the empty configuration and insertion of the local vacuum at an occupied point. [The absolute Wick line at a four-ray collision](#s-four-ray-absolute-wick-line)

### An irregular collision can detect a hidden extension {#ch04-irregular-collision}

The circle calculation used continuation around a closed loop. At an irregular singularity a horizontal solution may also grow or decay exponentially as it approaches the collision. Two connections with identical loop transport can then give different algebraic cohomology there. For three points put \(x=z_1-z_3\), \(y=z_2-z_3\). Off the three collision lines \(xy(x-y)=0\), the slope \(u=x/y\) takes values on the projective line with \(0,1,\infty\) removed. On that curve take the rank-two connection with parameter \(a\in\mathbb C\) whose horizontal columns have components \(y_1,y_2\) satisfying
\[
dy_1=a y_2\,du,\qquad dy_2=-2u^{-3}y_2\,du .
\]
Pull this connection back to the complement of the collision lines by the slope map and call the result \(M_a\). Its diagonal exponential factors are \(1\) and \(e^{1/u^2}\). A horizontal column has second component proportional to \(e^{1/u^2}\). For second component \(e^{1/u^2}\), the first is a primitive of \(a e^{1/u^2}du\). Its Laurent series at zero has no \(u^{-1}du\) coefficient, and the form is regular at \(u=1\). Its periods vanish, so the ordinary analytic monodromy is trivial for every \(a\). At \(a=0\) the connection splits. Does it admit an algebraic splitting for other \(a\)?

Let \(j\) include the complement of the collision lines and \(i\) their common origin. The cone \(C_a=\operatorname{Cone}(j_!M_a\to j_*M_a)\) compares the two algebraic holonomic extensions. Use the de Rham normalisation in which the constant connection on the plane gives \(\mathbb C[2]\).

Separate the common scale \(x\) from the shape \(r=y/x=1/u\). The open is \(\mathbb G_m\times(\mathbb A^1\setminus\{0,1\})\). On the shape curve a section \((p,q)\) of the dual connection has entries in \(\mathbb C[r,r^{-1},(r-1)^{-1}]\). Since \(du=-r^{-2}dr\), the off-diagonal entry of the original horizontal equation is \(-a/r^2\) in the \(r\)-coordinate. Transposing its matrix gives the connection term in the dual de Rham differential. With primes denoting \(r\)-derivatives, this differential is
\[
 (p,q)\longmapsto \bigl(p',\,q'+2rq-a p/r^2\bigr)\,dr .
\]
The second coordinate alone has differential \(q\mapsto(Tq)\,dr\) with \(Tq=q'+2rq\). The quotient, with coordinate \(p\), has the ordinary derivative. To lift its constant section \(1\) horizontally, start with \((1,0)\). Its differential is \((0,-a/r^2)\,dr\). Changing the lift by a section of the second coordinate changes the result by \((Tq)\,dr\). Thus the connecting image of \(1\) is \(-a[r^{-2}dr]=-2a[dr]\), since \(T(-1/r)=r^{-2}-2\). If \(Tq=1\), a finite pole of \(q\) would give a higher pole in \(q'\), and a nonzero polynomial \(q\) would give a polynomial of positive degree in \(Tq\). Hence \([dr]\ne0\). The class obstructs a horizontal algebraic lift exactly when \(a\ne0\).

In the exponential summand, subtracting \(Tq\,dr\) reduces every pole of order at least two and every positive polynomial power. In a relation among the remaining forms \(dr,dr/r,dr/(r-1)\), a preimage \(q\) could have no finite pole, since its derivative would have a pole of order at least two. A polynomial preimage could yield only a polynomial, and a nonzero one would give positive degree. This proves independence as well as spanning in degree one. The same argument gives \(\ker T=0\). The trivial quotient contributes one constant in degree zero and two logarithms in degree one. At \(a=0\) the connecting image of the constant vanishes, so the constant and all three exponential classes survive. At \(a\ne0\) that image has rank one. The angular dimensions are therefore \((1,5)\) and \((0,4)\), respectively.

The scale factor contributes \(1,dx/x\), so the ordinary de Rham dimensions of the dual on the open in degrees \(0,1,2\) are \((1,6,5)\) and \((0,4,4)\). To obtain the costalk at the origin, apply \(i^!\) to the triangle defining \(C_a\). Since \(i^!j_*M_a=0\), duality gives \(i^!C_a\simeq(i^*j_*M_a^\vee)^\vee[1]\). Scalar dilation leaves the angular coordinate fixed and extends to a contraction of the plane to the origin. For this equivariant algebraic coefficient, contraction identifies \(i^*j_*M_a^\vee\) with the global unshifted de Rham complex of the dual on the open, shifted by \([2]\). The contraction applies because the pullback from the angular curve is equivariant under dilation. [Drinfeld–Gaitsgory, *Compact generation of the category of D-modules on the stack of G-bundles on a curve*, Proposition 5.3.2](https://arxiv.org/pdf/1112.2402#page=42)

Thus ordinary degree \(m\) is dual to costalk degree \(1-m\). In degrees \(k=-1,0,1\), the dimensions of \(H^k(i^!C_a)\) are
\[
 (5,6,1)\quad(a=0),\qquad (4,4,0)\quad(a\ne0).
\]
These dimensions distinguish the split connection from the nonsplit ones. To obtain a signed Stokes multiplier, fix the first horizontal column \(s_1=(1,0)^{\mathsf t}\), and fix the lower component \(e^{1/u^2}\) of the second column. For \(r=1/u\to+i\infty\) or \(-i\infty\) this component decays. In each direction normalise the upper component to tend to zero. Call the resulting columns \(s_{2,+}\) and \(s_{2,-}\). Compare them along the upward contour \(\gamma:r=\delta+it\) with \(0<\delta<1\), from \(t=-\infty\) to \(+\infty\). For these marks the difference is
\[
 s_{2,+}-s_{2,-}=2i\sqrt{\pi}\,a\,s_1 .
\]
Indeed \(dy_1=-a e^{r^2}dr/r^2\). The endpoint values of \(e^{r^2}/r\) vanish along this contour. Thus the identity \(d(e^{r^2}/r)=2e^{r^2}dr-e^{r^2}dr/r^2\) replaces the integral of \(e^{r^2}dr/r^2\) by twice that of \(e^{r^2}dr\). The rapid-decay period of the dual extension class is therefore \(-2a\int_\gamma e^{r^2}\,dr=-2i\sqrt{\pi}\,a\). The column normalised at \(+i\infty\) minus the one normalised at \(-i\infty\) has upper component equal to the negative of this period. Changing a graded frame rescales the multiplier, while the costalk dimensions stay fixed.

### Three flags at a four-point collision {#ch04-three-flags-four-points}

For three points the dimension of the total costalk distinguished the two connections. With four points we can compare the maps *into* the costalk from different sequences of collisions. Translate \(z_1\) to zero and write \(s=z_2-z_1,\ x=z_3-z_1,\ y=z_4-z_1\) on the transverse space \(X=\mathbb A^3\). On the distinct-point open \(j:U\hookrightarrow X\) use the shape coordinates \(r=x/s,\ t=y/s\). Pull back the original angular connection \(N_a\) of the three-point example by \(r\), and tensor it with the connection \(d-J\,d\log(t-r)\) on a two-dimensional space \(W\), where \(J^2=0\ne J\). A positive turn of \(t-r\) has monodromy \(\exp(2\pi iJ)=1+2\pi iJ\). Let \(M\) be the resulting coefficient and \(C=\operatorname{Cone}(j_!M\to j_*M)\) its extension cone.

On the line \(L=\{x=y=s\}\) labels \(2,3,4\) coincide. Its origin \(i\) is the total collision. Off the origin put \(u=r-1\), \(w=t-r\). The three normal divisors are \(u=0\) for the pair \(2,3\), \(w=0\) for \(3,4\), and \(u+w=t-1=0\) for \(2,4\). A flag specifies the divisor reached first and the subsequent collision along \(L\). Compare first the flags through \(u=0\) and \(w=0\). For ordinary restrictions use the dual coefficient. Fix the horizontal frame of \(N_a^\vee\) by its value at the regular point \(r=1\) and transport \(W^\vee\) in the same positive real chamber for both flags.

The two orders already differ on one logarithmic form. When \(u\) is small compared with \(w\), the form \(\beta=d\log(1+u/w)\) is regular at \(u/w=0\), so its logarithmic residue is zero. In the opposite order \(w/u\) tends to zero. The identity
\[
 d\log(1+u/w)=d\log(u/w)+d\log(1+w/u)
\]
leaves \(d\log(u/w)\), since the second term has zero residue in that chart. The factor \(1+u/w\) is the equation \(t-1=u+w\) of the third divisor divided by \(w\).

To see whether this difference survives with coefficients, take \(w\) as scale and \(u/w\) as coordinate on the line with punctures at \(0,-1,\infty\). Put \(q=d\log w\), \(\alpha=d\log(u/w)\) and \(H=(N_a^\vee)_{r=1}\). In the chosen horizontal frame the scale complex of the dual coefficient is \(W^\vee\to qW^\vee\), with \(v\mapsto qJ^{\mathsf t}v\) from degree zero to degree one. Tensor it with \(H\) and the angular classes \(1,\alpha,\beta\), with \(\alpha\wedge\beta=0\), to obtain the simultaneous normal complex \(P\). Each iterated normal complex has one angular logarithm. Use the labelled forms \(p=d\log u\), \(q=d\log w\) to identify the two targets with a common complex \(T\), replacing the angular factor by the exterior algebra on \(\rho=p-q\). The ordinary restrictions \(F_u,F_w:P\to T\) act as the identity on \(H,W^\vee\). On logarithmic generators they give
\[
\begin{array}{c|ccc}
 &q&\alpha&\beta\\ \hline
 F_u&q&\rho&0\\
 F_w&q&\rho&\rho
\end{array}
\]
In the second chart the positive normal logarithm is \(d\log(w/u)=-\rho\), and \(q=d\log u+d\log(w/u)\). Thus the same table applies to wedge products in the two marked charts. Both restrictions commute with the dual differential \(d+J^{\mathsf t}q\wedge-\). Does the difference on \(\beta\) reach the cohomology of the total collision?

A punctured disc in \(L=\{x=y=s\}\) still separates the triple from the first label. On this outer link the coefficient is constant in \(s\). Its cohomology is the exterior algebra \(\Lambda(\lambda)\) on \(\lambda=d\log s\) in degree one. Indeed on \(s=\varepsilon e^{i\theta}\) the integral of \(d\log s\) over a positive turn is \(2\pi i\). This factor is common to both flags.

Let \(A\) be the unshifted algebraic de Rham complex of the dual coefficient on the shape surface \(r,t\notin\{0,1\},\ t\ne r\). Ordinary restriction goes from \(A\) to the simultaneous germ by \(S:A\to P\), then to the chosen iterated germ by \(F_j:P\to T\). Include the outer link as the first tensor factor. Scalar contraction and duality as in the three-point calculation, now with \(\mathrm{DR}(\mathcal O_X)=\mathbb C[3]\), identify \(i^!C\) with \((\Lambda(\lambda)\otimes A)^\vee[-2]\). On the collision line the restriction to its punctured part dualises to the map from extension by zero back to the coefficient on the line. The connecting map of this localisation triangle at the origin is the same for both flags. Consequently the two boundary maps into the shifted costalk are
\[
 D_j=(1\otimes F_jS)^\vee[-1]:
 (\Lambda(\lambda)\otimes T)^\vee[-1]\longrightarrow
 (\Lambda(\lambda)\otimes A)^\vee[-1]\simeq i^!C[1],
 \qquad j=u,w .
\]
An ordinary class of degree \(m\) is dual to degree \(1-m\) in this target. Choose \(v\notin J^{\mathsf t}W^\vee\) with \(J^{\mathsf t}v\ne0\). In the dual angular frame put \(e=(1,-a/r)\), \(f=(0,1)\). For either coefficient \(g=e,f\) the top-degree form \(g(r)v\,q\wedge d\log(t-1)\) on the shape surface is closed. Its restriction to the simultaneous germ uses the value \(g(1)\) in the horizontal frame. Since \(t-1=u+w=w(1+u/w)\), its logarithmic factor is \(q\wedge(q+\beta)=q\wedge\beta\). The first row sends it to zero. The second gives \(q\wedge\rho\) with coefficient \(g(1)v\). This class survives because \(v\) has nonzero image in \(W^\vee/J^{\mathsf t}W^\vee\). Multiplication by \(\lambda\) raises the ordinary degree by one and detects the difference one degree lower after duality.

To compute the ranks on the whole costalk, use finite representatives for \(A\). On the \(r\)-curve the pole reduction of the three-point calculation gives \(e\) in degree zero. Degree one has basis \(f\,dr\) and the forms \(e\,d\log(r-c),f\,d\log(r-c)\) for \(c=0,1\). The differential of \(e\) is \(-2af\,dr\). For the moving point \(t\), partial fractions leave \(1\) and the three logarithms \(\zeta_0=d\log t,\ \zeta_1=d\log(t-1),\ q=d\log(t-r)\). Tensor the two complexes with \(W^\vee\) and add \(J^{\mathsf t}q\wedge-\) to the differential, using \(q\wedge\zeta_c=d\log(r-c)\wedge(\zeta_c-q)\). The logarithms give the ordinary relative cohomology of the thrice-punctured affine line. Filtering \(W^\vee\) by \(\ker J^{\mathsf t}\) reduces the comparison with the full de Rham complex to that untwisted calculation on the two associated graded pieces.

On these representatives \(S\) keeps \(q\), sends \(\zeta_1\) to \(q+\beta\) and sends \(g\,d\log(r-1)\) to \(g(1)(q+\alpha)\) for \(g=e,f\). It sends \(e\) to \(e(1)\) and kills \(f\,dr,\ e\,d\log r,\ f\,d\log r,\ \zeta_0\), whose radial constant terms vanish. In degrees \(0,1,2\) the global angular cohomology has dimensions \((1,8,23)\) for \(a=0\) and \((0,4,20)\) for \(a\ne0\). To see the rank count, first omit \(J^{\mathsf t}q\wedge-\) and take one copy of the angular coefficient. The dimensions are \((1,8,15)\) and \((0,4,12)\), from the \(r\)-curve and the three relative logarithms. In the two-step filtration of \(W^\vee\) the connecting maps are exterior multiplication by \(q\). They have ranks \(1,7\) in the split case and \(0,4\) otherwise. Indeed \(q\) takes each base degree-one class to its own \(q\)-component. When \(e\) is horizontal, \(e\zeta_0,e\zeta_1\) give two further independent residues by the wedge identity above.

For the restrictions, put \(h=J^{\mathsf t}v\). At \(a=0\) the degree-one image of \(S\) is spanned by \(e(1)h\alpha,\ f(1)h\alpha,\ e(1)h\beta,\ e(1)vq\). At \(a\ne0\) only the first two survive. In degree two the two values \(e(1),f(1)\) multiply the radial class of \(v q\) wedged with either \(\alpha\) or \(\beta\). Thus the two rows for \(F_u,F_w\) give all the individual and joint ranks. Each angular class also occurs tensored with \(\lambda\). After shifted duality the entries below are in degrees \(1,0,-1,-2\). The last three columns give ranks on cohomology.

| Parameter | \(H^\bullet(i^!C[1])\) dimensions | Each of \(D_u,D_w\) | Sum of the images | Rank of \(D_w-D_u\) |
| --- | --- | --- | --- | --- |
| \(a=0\) | \((1,9,31,23)\) | \((1,4,5,2)\) | \((1,5,8,4)\) | \((0,1,3,2)\) |
| \(a\ne0\) | \((0,4,24,20)\) | \((0,2,4,2)\) | \((0,2,6,4)\) | \((0,0,2,2)\) |

At \(a\ne0\) in degree \(-1\), each image has dimension four and their sum has dimension six. Their intersection therefore has dimension two in a costalk group of dimension \(24\). Which part of that costalk do they span together?

On angular one-forms the pair of restrictions sends \(x\alpha+y\beta\) to \((x\rho,(x+y)\rho)\). A left inverse keeps the first coefficient and subtracts it from the second, recovering \(x,y\). In degree zero it takes the constant from the first component. Both maps retain the same radial complex, so this left inverse commutes with the radial differential. After duality the two images together span the image of the localisation boundary from \(L\), a proper subspace of the cohomology at the origin in both rows.

What happens when labels 2 and 4 meet first? Their collision is \(t=1\), or \(u+w=0\). Keep \(w\) as the scale and use \(\xi=(u+w)/w\) at this third puncture. Then \(u=w(\xi-1)\). On its punctured normal disc, \(\alpha=d\log(1-\xi)\) has a holomorphic primitive, while \(\beta=d\log\xi\) represents the positive class \(\eta\). The third restriction \(F_c\) uses the same coefficient and radial complex as \(F_u,F_w\), with exterior angular generator \(\eta\). On cohomology it sends \([p]=[d\log u]\) and \([q]=[d\log w]\) to the same class \([q]\). Consequently
\[
 F_c[q\wedge p]=0,\qquad F_c\bigl[q\wedge d\log(t-1)\bigr]=[q\wedge\eta] .
\]
The last class pairs to \((2\pi i)^2\) with the product of the positive \(w\)- and \(\xi\)-circles, in that order. With the coefficient \(v\) above it survives modulo \(J^{\mathsf t}W^\vee\).

The exceptional line is the projective line of normal directions, with coordinate \(u/w\). Take positive meridians about \(0,\infty,-1\) in that order, assigning scalar residue \(1\) to the logarithmic differential of a positive local parameter. The residues on \((\alpha,\beta)\) are \((1,0),(-1,-1),(0,1)\). At infinity the positive parameter is \(w/u\), with logarithmic differential \(-\rho\) in the table. The three rows sum to zero on angular one-forms, and each restriction takes the constant \(1\) to \(1\). Any two rows recover the two angular coefficients and retain the radial complex. Hence any two boundary images span the same image from \(L\).

For the third boundary alone, \(F_c\) kills \(\alpha\) and keeps \(\beta\) as \(\eta\). Applied to the global degree-one images above, it retains \(e(1)h\eta,e(1)vq\) in the split case and kills both \(\alpha\) classes when \(a\ne0\). In degree two \(e(1)\) and \(f(1)\) multiply \(\bar v\,q\wedge\eta\), with \(\bar v\) the class of \(v\) modulo \(J^{\mathsf t}W^\vee\). These two fibre values specify local horizontal germs at the regular point \(r=1\). Thus the third angular image has dimensions \((1,2,2)\) at \(a=0\) and \((0,0,2)\) at \(a\ne0\).

An angular image with dimensions \((x,y,z)\) occurs once with \(1\) and again one degree higher with \(\lambda\). Its four dimensions are \((x,x+y,y+z,z)\). After shifted duality the third image, in degrees \(1,0,-1,-2\), has ranks \((1,3,4,2)\) at \(a=0\) and \((0,0,2,2)\) otherwise. A comparison with independently defined sectorial specialisation remains open. It would have to identify the sectors and their Stokes filtrations with the marked fibres used for these three algebraic restrictions.

With the same horizontal frame and labelled logarithms, \(D_u\) and \(D_w\) induce different maps on cohomology. No chain homotopy can relate them with those identifications. For two bracketings on a common three-input domain, their difference can instead be a boundary in the complex of maps. A map exhibiting that boundary must lower degree by one. Its differential has to account for the differential of the output and for those of the individual inputs. [The three-letter bar equation](05-bar-and-coherence.md#eq-ch05-associator-homotopy)
