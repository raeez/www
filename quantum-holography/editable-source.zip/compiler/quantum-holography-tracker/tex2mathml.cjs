// Render TeX to MathML at build time with Temml (vendor/temml.cjs, MIT licence).
// Reads a JSON list of {tex, display} on standard input and writes a JSON list of
// {html} or {error} in the same order. The page itself carries no renderer.
'use strict';
const temml = require('./vendor/temml.cjs');

// Spacing as TeX sets it, where the browser's MathML would not: an operator inside a subscript, superscript or limit
// takes no added space (TeX's script style), and a sign directly after an opening bracket or directly before a closing
// one is unary. Only lspace and rspace attributes are added, to <mo> elements that have none; nothing else changes.
const SCRIPTED = new Set(['msub', 'msup', 'msubsup', 'munder', 'mover', 'munderover', 'mmultiscripts']);
const OPENERS = new Set(['(', '[', '{', '\u27e8', '\u2308', '\u230a']);
const CLOSERS = new Set([')', ']', '}', '\u27e9', '\u2309', '\u230b']);
const SIGNS = new Set(['+', '\u2212', '\u00b1', '\u2213']);
function parse(html) {
  const root = { name: '#root', children: [] };
  const stack = [root];
  const re = /<\/?[a-zA-Z][^>]*>|[^<]+/g;
  let m;
  while ((m = re.exec(html))) {
    const t = m[0];
    const top = stack[stack.length - 1];
    if (t[0] !== '<') { top.children.push({ text: t }); continue; }
    if (t[1] === '/') { stack.pop(); top.close = t; continue; }
    const name = /^<([a-zA-Z][\w-]*)/.exec(t)[1];
    const node = { name, open: t, children: [] };
    top.children.push(node);
    if (!t.endsWith('/>')) stack.push(node);
  }
  return root;
}
function text(node) { return node.text !== undefined ? node.text : node.children.map(text).join(''); }
function setSpace(node) {
  if (/\slspace=|\srspace=/.test(node.open)) return;
  node.open = node.open.replace(/^<mo\b/, '<mo lspace="0em" rspace="0em"');
}
function walk(node, inScript) {
  if (node.text !== undefined || node.name === 'annotation') return;
  const elems = node.children.filter(c => c.text === undefined);
  elems.forEach((child, i) => {
    if (child.name === 'mo') {
      const t = text(child).trim();
      if (inScript) setSpace(child);
      else if (SIGNS.has(t)) {
        const prev = elems[i - 1], next = elems[i + 1];
        const prevOpen = prev && prev.name === 'mo' && OPENERS.has(text(prev).trim()) && !/form="postfix"/.test(prev.open);
        const nextClose = next && next.name === 'mo' && CLOSERS.has(text(next).trim()) && !/form="prefix"/.test(next.open);
        if (prevOpen || nextClose) setSpace(child);
      }
    }
    walk(child, inScript || (SCRIPTED.has(node.name) && i >= 1));
  });
}
function serialise(node) {
  if (node.text !== undefined) return node.text;
  const inner = node.children.map(serialise).join('');
  return node.name === '#root' ? inner : node.open + inner + (node.close || '');
}
function tighten(html) {
  const tree = parse(html);
  walk(tree, false);
  return serialise(tree);
}

let input = '';
process.stdin.setEncoding('utf8');
process.stdin.on('data', chunk => { input += chunk; });
process.stdin.on('end', () => {
  const items = JSON.parse(input);
  const out = items.map(({ tex, display }) => {
    try {
      return { html: tighten(temml.renderToString(tex, { displayMode: Boolean(display), annotate: true,
                                                         throwOnError: true, trust: false })) };
    } catch (error) {
      return { error: String(error && error.message ? error.message : error) };
    }
  });
  process.stdout.write(JSON.stringify(out));
});
